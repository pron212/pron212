import os
from dotenv import load_dotenv
from os import environ
import redis

import sqlalchemy

load_dotenv()

def init_connection_engine():
    db_config = {
        # [START cloud_sql_mysql_sqlalchemy_limit]
        # Pool size is the maximum number of permanent connections to keep.
        "pool_size": 5,
        # Temporarily exceeds the set pool_size if no connections are
        # available.
        "max_overflow": 2,
        # The total number of concurrent connections for your application
        # will be a total of pool_size and max_overflow.
        # [END cloud_sql_mysql_sqlalchemy_limit]
        # [START cloud_sql_mysql_sqlalchemy_backoff]
        # SQLAlchemy automatically uses delays between failed
        # connection attempts, but provides no arguments for configuration.
        # [END cloud_sql_mysql_sqlalchemy_backoff]
        # [START cloud_sql_mysql_sqlalchemy_timeout]
        # 'pool_timeout' is the maximum number of seconds to wait when
        # retrieving a new connection from the pool. After the specified
        # amount of time, an exception will be thrown.
        "pool_timeout": 30,  # 30 seconds
        # [END cloud_sql_mysql_sqlalchemy_timeout]
        # [START cloud_sql_mysql_sqlalchemy_lifetime]
        # 'pool_recycle' is the maximum number of seconds
        # a connection can persist. Connections that live longer than
        # the specified amount of time will be reestablished
        "pool_recycle": 1800,  # 30 minutes
        # [END cloud_sql_mysql_sqlalchemy_lifetime]
        "pool_pre_ping": True,
        # tests connections for liveness upon each checkout.

    }

    # if os.environ.get("ENV_SETTINGS") == "local":
    return init_tcp_connection_engine(db_config)
    # elif os.environ.get("ENV_SETTINGS") in ["gcp", "production", "beta", "dev"]:
    #     return init_unix_connection_engine(db_config)
    # else:
    #     return None


def init_tcp_connection_engine(db_config):
    # [START cloud_sql_mysql_sqlalchemy_create_tcp]
    # Remember - storing secrets in plaintext is potentially unsafe.
    # Consider using something like
    # https://cloud.google.com/secret-manager/docs/overview
    # to help keep secrets secret.
    db_user = os.environ["dbusername"]
    db_pass = os.environ["dbpassword"]
    db_name = os.environ["dbname"]
    db_host = os.environ["dbhost"]
    db_port = os.environ["port"]

    pool = sqlalchemy.create_engine(
        # Equivalent URL:
        # mysql+pymysql://<db_user>:<db_pass>@<db_host>:<db_port>/<db_name>
        sqlalchemy.engine.url.URL(
            drivername="mysql+pymysql",
            username=db_user,  # e.g. "my-database-user"
            password=db_pass,  # e.g. "my-database-password"
            host=db_host,  # e.g. "127.0.0.1"
            port=db_port,  # e.g. 3306
            database=db_name,  # e.g. "my-database-name"
        ),
        **db_config
    )
    # [END cloud_sql_mysql_sqlalchemy_create_tcp]

    return pool


def init_unix_connection_engine(db_config):
    # [START cloud_sql_mysql_sqlalchemy_create_socket]
    # Remember - storing secrets in plaintext is potentially unsafe.
    # Consider using something like
    # https://cloud.google.com/secret-manager/docs/overview
    # to help keep secrets secret.
    db_user = os.environ["dbusername"]
    db_pass = os.environ["dbpassword"]
    db_name = os.environ["dbname"]
    db_socket_dir = os.environ.get("SOCKET_PATH", "/cloudsql")
    cloud_sql_connection_name = os.environ["CLOUD_SQL_CONNECTION_NAME"]

    pool = sqlalchemy.create_engine(
        # Equivalent URL:
        # mysql+pymysql://<db_user>:<db_pass>@/<db_name>?unix_socket=<socket_path>/<cloud_sql_instance_name>
        sqlalchemy.engine.url.URL(
            drivername="mysql+pymysql",
            username=db_user,  # e.g. "my-database-user"
            password=db_pass,  # e.g. "my-database-password"
            database=db_name,  # e.g. "my-database-name"
            query={
                "unix_socket": "{}/{}".format(
                    db_socket_dir,
                    cloud_sql_connection_name  # e.g. "/cloudsql"
                )  # i.e "<PROJECT-NAME>:<INSTANCE-REGION>:<INSTANCE-NAME>"
            },
        ),
        **db_config
    )
    # [END cloud_sql_mysql_sqlalchemy_create_socket]

    return pool

def init_redis_pool():
    redis_host = os.environ.get("REDIS_HOST", "localhost")
    redis_port = int(os.environ.get("REDIS_PORT", 6379))
    redis_pass = os.environ.get("REDIS_PASSWORD")
    pool = redis.ConnectionPool(
        host=redis_host,
        port=redis_port,
        password=redis_pass,
        db=0)
    return pool

redis_client = redis.Redis(connection_pool=init_redis_pool())