show_project_query="""SELECT  wp.projectID, wp.timestamp, wp.title, wp.location, wp.description, wp.userID, wp.masts, wp.lidars, wp.in_progress, wp.published, wp.status, wp.shared, wp.shared_user, COUNT(a.anlysID) as analysis
FROM windvista_project wp left join analysis a on wp.projectID=a.projectID where wp.userID=:userID and wp.status='active' GROUP BY  wp.projectID;"""

# show_project_old="SELECT wp.*,count(a.anlysID) as analysis FROM windvista_project wp LEFT JOIN analysis a ON wp.projectID=a.projectID where wp.userID=:userID and wp.status='active' GROUP BY wp.projectID;"
show_analysis_query="SELECT * FROM analysis WHERE projectID=:project_id and status='active';"
windoscope_download_results_query="SELECT windoscope_download FROM processed_systems_unreg WHERE prsID=:prsID;"
user_id="SELECT userid FROM usertable WHERE useremail=:useremail;"
archive_project="SELECT * FROM windvista_project WHERE projectID=:project_id;"
ltt_download_results_query="SELECT ltt_download FROM processed_systems_unreg WHERE prsID=:process_id;"
shear_download_resultss_query="SELECT shear_download FROM processed_systems_unreg WHERE prsID=:process_id;"
processed_system_unreg="""INSERT INTO processed_systems_unreg (anlysID,timestamp,systemType, title,sourcefrom,txtKey,txturl,filename, process_status,user, comb_shear,Target_height, 
Anemo_name,ltt_process_status,ltt_imp_adj, ltt_depth_analysis,windoscope_download,shear_download,ltt_download,windoscope_process,winddata,tempraw_status, cbox_data, shear_feather, Direction_name, measure_feather, final_feather) 
VALUES (:new_analysis_id, :processed_systems_timpestamp,:processed_systems_systemType, :processed_systems_title, :processed_systems_sourcefrom, 
:processed_systems_txtKey, :processed_systems_txturl, :processed_systems_filename, :processed_systems_process_status, :processed_systems_user, :processed_systems_comb_shear, :processed_systems_Target_height, :processed_systems_Anemo_name, :processed_systems_ltt_process_status, 
:processed_systems_ltt_imp_adj, :processed_systems_ltt_depth_analysis, :processed_systems_windoscope_download, :processed_systems_shear_download, :processed_systems_ltt_download, 
:processed_systems_windoscope_process, :processed_systems_winddata, :processed_systems_tempraw_status, :processed_systems_cbox_data, :shear_feather, :Direction_name, :measure_feather, :final_feather);"""
all_ltt_files="SELECT * FROM ltt_reference_files WHERE anlysID=:analysis_id;"
user_id_username_query="SELECT userid FROM usertable WHERE useremail=:user;" 
insert_user_query="INSERT INTO usertable (useremail) VALUES (:user);"
recent_system_name_query="SELECT name from recent_system WHERE name=:user;"
insert_recent_system_query="INSERT INTO recent_system (name, timestamp, prsID) VALUES (:user, :timestamp, :process_id);"
insert_recent_system_query2="INSERT INTO processed_systems_unreg SET shear_session='1' WHERE prsID=:process_id;"
insert_recent_system_query_windexgraph="INSERT INTO recent_system (name, timestamp, prsID_windexgraph,windexgraph_session) VALUES (:user, :timestamp, :process_id, 1);"
insert_recent_system_query_prsID_ltt="INSERT INTO recent_system (name, timestamp, prsID_ltt) VALUES (:user, :timestamp, :process_id);"
insert_recent_system_query_prsID_ltt2="INSERT INTO processed_systems_unreg SET ltt_session='1' WHERE prsID=:process_id;"
ltt_ref_files_query="SELECT ltt_ref_filename_feather FROM ltt_reference_files WHERE anlysID=:analysis_id;"
return_mast_liader_query="SELECT masts,lidars FROM windvista_project WHERE title=:title;"
ltt_imp_adj_query="SELECT ltt_imp_adj FROM processed_systems_unreg WHERE prsID=:process_id;"
windexgraph_session_query="SELECT windexgraph_session FROM recent_system WHERE prsID=:process_id;"
shear_session_query="SELECT shear_session FROM processed_systems_unreg WHERE prsID=:process_id;"
ltt_session_query="SELECT ltt_session FROM processed_systems_unreg WHERE prsID=:process_id;"
db_windoscope_query="SELECT filename, timestamp, windoscope_download FROM processed_systems_unreg where prsID=:process_id;"
db_ltt_query="SELECT filename, timestamp, ltt_download FROM processed_systems_unreg WHERE prsID=:process_id;"
db_shear_query="SELECT filename, timestamp, shear_download, shear_skip FROM processed_systems_unreg WHERE prsID=:process_id;"
shear_analysis_query="SELECT shear_feather,selected_combination FROM processed_systems_unreg WHERE prsID=:process_id ;"
show_analysis_archived_query="SELECT * FROM analysis WHERE projectID=:project_id AND status='archived';"
show_system_analysis_id_query="SELECT timestamp FROM analysis WHERE anlysID=:anlysID;"
show_system_lidars_query="SELECT prsID, title, systemType FROM processed_systems_unreg WHERE systemType='lidars' AND anlysID=:anlysID;"
show_system_masts_query="SELECT prsID, title, systemType FROM processed_systems_unreg WHERE systemType='masts' AND anlysID=:anlysID;"
show_system_analysis_query="SELECT * FROM analysis WHERE anlysID=:anlysID;"
update_recent_system_query="UPDATE recent_system SET timestamp=:timestamp, prsID=:process_id, shear_session='1' WHERE name=:user;"
update_recent_system_query2="UPDATE processed_systems_unreg SET shear_session='1' WHERE prsID=:process_id;"
update_recent_system_query_windexgraph="UPDATE recent_system SET timestamp=:timestamp, prsID_windexgraph=:process_id, windexgraph_session='1' WHERE name=:user;"
update_recent_system_query_prsID_ltt="UPDATE recent_system SET timestamp=:timestamp, prsID_ltt=:process_id WHERE name=:user;"
update_recent_system_query_prsID_ltt2="UPDATE processed_systems_unreg SET ltt_session='1' WHERE prsID=:process_id;"
select_proc_sys_unreg_query="SELECT * FROM processed_systems_unreg WHERE anlysID=:anlysID;"
insert_ltt_ref_files_query="INSERT INTO ltt_reference_files (anlysID, username, timestamp, ltt_ref_uploaded_key, ltt_ref_filename, ltt_ref_filename_feather, feather_process) VALUES (:new_analysis_id, :ltt_username, :timestamp, :ltt_ref_uploaded_key_new, :ltt_ref_filename_new, :ltt_ref_filename_feather_new, :feather_process);"
select_ltt_ref_file_query="SELECT * FROM ltt_reference_files WHERE anlysID=:anlysID;"
duplicate_analysis_insert_query="INSERT INTO analysis (anlysID, projectID, title, description, userID, masts, lidars,timestamp,analysis_duplicate) VALUES (:new_analysis_id, :projectid, :title, :description, :userID, :masts, :lidars, :timestamp, :anlysID);"
select_max_analysis_id_query="select max(anlysID) from analysis;"
select_analys_query="SELECT * FROM analysis WHERE anlysID=:anlysID;"
archive_analysis_query="UPDATE analysis SET status='archived', archived_timestamp=:timestamp WHERE anlysID=:anlysID;"
insert_new_analysis_query="INSERT INTO analysis(projectID, title, description, userID, masts, lidars, timestamp) VALUES (:project_id , :title, :description, :userid , :masts1 , :lidars1, :timestamp);"
select_title_new_analysis_query="SELECT title FROM analysis WHERE userID=:userid AND projectID=:project_id;"
select_windvista_project_query="SELECT * FROM windvista_project WHERE projectID=:projectID;"
update_windvista_project_query="UPDATE windvista_project SET status='archived', archived_timestamp=:timestamp WHERE projectID=:projectID;"
select_max_project_id_query="SELECT max(projectID) FROM windvista_project;"
insert_windvista_project_query="INSERT INTO windvista_project (timestamp,title, location, description, userID, masts,lidars) VALUES (:timestamp, :title, :location, :description, :userid, :mast, :lidar);"
select_title_windvista_project_query="SELECT title FROM windvista_project WHERE userID=:userid;"
insert_ltt_refrence_file_query="INSERT INTO ltt_reference_files (anlysID, username, timestamp, ltt_ref_uploaded_key,ltt_ref_filename_feather) VALUES (:analysis_id, :user, :timestamp, :ltt_ref_zip_object_key, :ltt_ref_file_key);"
update_ltt_refrence_file_query="UPDATE ltt_reference_files SET timestamp=:timestamp, username=:user , ltt_ref_uploaded_key=:ltt_ref_zip_object_key, ltt_ref_filename_feather=:ltt_ref_file_key WHERE anlysID=:analysis_id;"
select_processed_shear_downl_result="SELECT filename, timestamp, shear_download FROM processed_systems_unreg WHERE prsID=:process_id;"
select_processed_ltt_downl_result="SELECT filename, timestamp, ltt_download FROM processed_systems_unreg WHERE prsID=:process_id;"
select_processed_windoscope_downl_result="SELECT filename, timestamp, windoscope_download FROM processed_systems_unreg WHERE prsID=:process_id;"
select_windvista_prject_query="SELECT title,description,location,shared,userID FROM windvista_project WHERE projectID=:project_id;"
show_project_archived_query="""SELECT wp.projectID, wp.timestamp, wp.title, wp.location, wp.description, wp.userID, wp.masts, wp.lidars, wp.in_progress, wp.published, wp.status, count(a.anlysID) as analysis 
FROM windvista_project wp left join analysis a on wp.projectID=a.projectID where wp.userID=:userID and wp.status='archived' GROUP BY  wp.projectID;""" 


# a.status='archived'
select_analysis_shared_status_query="SELECT shared,userID FROM windvista_project WHERE projectID=(SELECT projectID FROM analysis WHERE anlysID=:anlysID);"
calc_combination_status_query="SELECT winddata FROM processed_systems_unreg WHERE prsID=:process_id"
calc_combination_new_query="SELECT scrap FROM processed_systems_unreg WHERE prsID=:process_id;"
calc_preload_select_prsid_query="SELECT prsID FROM processed_systems_unreg WHERE user=:user;"
calc_preload_select_max_prsid_query="SELECT max(prsID) FROM processed_systems_unreg WHERE user=:user;"
calc_preload_insert_query="INSERT INTO processed_systems_unreg (user,txtKey,txturl) VALUES (:user, :obj, :txturl);"
measurement_details_query="SELECT measure_feather FROM processed_systems_unreg WHERE prsID=:process_id;"
status_project_archive_or_not = "SELECT status FROM windvista_project WHERE projectID=:projectID;"
unarchive_analysis_query="UPDATE analysis SET status='active', archived_timestamp=:timestamp WHERE anlysID=:anlysID;"
status_archive_or_not = "SELECT status FROM analysis WHERE anlysID=:anlysID;"
remove_update_windvista_project_query="UPDATE windvista_project SET status='active', archived_timestamp=:timestamp WHERE projectID=:projectID;"
final_approach_query="SELECT ltt_imp_adj, shear_feather, user FROM processed_systems_unreg WHERE prsID=:process_id;"
final_approach_update_query="UPDATE processed_systems_unreg SET final_feather=:final_feather_status_key WHERE prsID=:process_id;"
final_approach_update_query2="INSERT INTO excel_summary_requirements_audit SET prsID=:process_id, final_requirements=:finalrequirements;"
final_approach_update_query3="UPDATE excel_summary_requirements_audit SET final_requirements=:finalrequirements WHERE prsID=:process_id;"
select_max_prsid_query="SELECT max(prsID) from processed_systems_unreg;"
shear_updated_time = "SELECT shear_update_time FROM processed_systems_unreg WHERE prsID=:process_id;"
ltt_updated_time = "SELECT ltt_update_time FROM processed_systems_unreg WHERE prsID=:process_id;"
check_user_email = "SELECT userid FROM usertable WHERE useremail=:user;"
all_user_project_query = "SELECT title FROM windvista_project WHERE userID=:user_id;"
update_project_query = "UPDATE windvista_project SET title=:title, location=:location, description=:description  WHERE projectID=:project_id;"
publish_analysis_query = "SELECT published FROM analysis WHERE anlysID=:analysisid;"
insert_publish_analysis ="UPDATE analysis SET published='published' WHERE anlysID=:analysisid;"
new_analysis_query = "SELECT userid FROM usertable WHERE useremail=:user;"
new_analysis_query2 = "SELECT title FROM analysis WHERE userID=:userid AND projectID=:projectid;"
insert_new_analysis = "INSERT INTO analysis(projectID, title, description, userID,masts,lidars,timestamp) VALUES (:projectid, :title, :description, :userid, :masts, :lidars, :timestamp) "
publish_analysis_processid_query = "SELECT projectID FROM analysis WHERE anlysID=:analysisid;"
publish_count_query = "SELECT published FROM windvista_project WHERE projectID=:project_id;"
update_publish_analysis_query = "UPDATE windvista_project SET published=:ini_count WHERE projectID=:project_id;"
analysis_data_new_query = "SELECT prsID,title FROM processed_systems_unreg WHERE anlysID=:analysis_id;"
analysis_data_new_query_feather = "SELECT final_feather,txtKey FROM processed_systems_unreg WHERE prsID=:process_id;"
update_meas_sys_config_postload_query="UPDATE processed_systems_unreg SET txtKey=:textkey, txturl=:texturl, timestamp=:tmsp, process_status='0', ltt_process_status='0' , windoscope_process='0', tempraw_status='0', measure_feather = NULL, windoscope_download = NULL, shear_download = NULL, ltt_download = NULL,shear_session = '0',ltt_session = '0', selected_combination = NULL, ltt_update_time = NULL, shear_update_time = NULL, final_feather = NULL, shear_feather = NULL, cbox_data = NULL, winddata = NULL, ltt_depth_analysis = NULL, ltt_imp_adj = NULL, shear_rds = NULL, measure_rds = NULL, final_rds = NULL WHERE prsID=:process_id;"
meas_sys_config_unreg_query="SELECT title FROM processed_systems_unreg WHERE user=:user AND anlysID=:anlysID;"
insert_meas_sys_config_unreg_query = "INSERT INTO processed_systems_unreg (anlysID, timestamp, systemType, title, sourcefrom, filename,user,comb_shear,Target_height,Anemo_name,Direction_name,tempraw_status,shear_skip) VALUES (:anlysID, :timestamp, :systemType, :title, :sourcefrom, :filename, :user, :comb_shear, :Target_height, :Anemo_name, :Direction_name, :tempraw_status, :shear_skip);"
meas_sys_config_unreg_query2="SELECT projectID FROM analysis WHERE anlysID=:analysisid;"
measurement_system_unreg_query_mast="UPDATE analysis SET masts=masts+1 WHERE anlysID=:analysisid;"
measurement_system_unreg_query_mast2="UPDATE windvista_project SET masts=masts+1 WHERE projectID=:projectid;"
measurement_system_query_unreg_lidar="UPDATE analysis SET lidars=lidars+1 WHERE anlysID=:analysisid;"
measurement_system_query_unreg_lidar2="UPDATE windvista_project SET lidars=lidars+1 WHERE projectID=:projectid;"
meas_sys_config_postload_txtkey_query="SELECT txtKey FROM processed_systems_unreg WHERE prsID=:process_id;"


#share project
user_group = "SELECT client_name FROM usertable WHERE useremail=:user;"
all_users = "SELECT useremail, client_name FROM usertable;"


# unshare project query
unshare_query="UPDATE windvista_project SET shared_user=NULL, shared='active' WHERE projectID=:project_id;"

# 
insert_shared = "UPDATE windvista_project SET shared_user=:user_id, shared=:status WHERE projectID=:project_id;"
insert_shared2 = "UPDATE windvista_project SET shared_user=:user_id, shared_timestamp=:timestamp, shared='shared' WHERE projectID=:project_id;"
shared_ids_query="SELECT shared_user FROM windvista_project WHERE projectID=:project_id;"
all_shared_project_query = "SELECT * FROM windvista_project WHERE userID=:main_user_id AND shared_user=:share_user_id;"


#Authentication queries
user_name_from_userid="SELECT useremail FROM usertable WHERE userid=:user_id;"
authentication_project="SELECT userID FROM windvista_project WHERE projectID=:project_id;"
duplicate_auth_query="SELECT shared_user FROM windvista_project WHERE projectID=:project_id;"
authentication_analysis="SELECT userID FROM windvista_project WHERE projectID=:project_id;"
authentication_analysis2="SELECT userID FROM analysis WHERE anlysID=:analysisid;"
authentication_systems="SELECT user FROM processed_systems_unreg WHERE prsID=:process_id;"
authentication_systems2="SELECT user FROM processed_systems_unreg WHERE anlysID=:analysis_id;"
authentication_systems3="SELECT anlysID FROM processed_systems_unreg WHERE prsID=:process_id;"


#Sharing queries
show_shared_projects="""SELECT  wp.projectID, wp.timestamp, wp.title, wp.location, wp.description, wp.userID, wp.masts, wp.lidars, wp.in_progress, wp.published, wp.status, wp.shared_timestamp, COUNT(a.anlysID)  as analysis
FROM windvista_project wp left join analysis a on wp.projectID=a.projectID where wp.shared_user LIKE '%:userID%' GROUP BY  wp.projectID;"""


#show_shared_projects="SELECT * from windvista_project WHERE shared_user LIKE '%:userID%';"
show_shared_analysis="SELECT * from analysis WHERE projectID IN (SELECT projectID from windvista_project WHERE shared_user LIKE '%:userID%');"
show_shared_systems="SELECT * from processed_systems_unreg WHERE anlysID IN (SELECT anlysID from analysis WHERE projectID IN (SELECT projectID from windvista_project WHERE shared_user LIKE '%:userID%'));"
all_team_members="SELECT useremail FROM usertable where client_name = (SELECT client_name FROM usertable WHERE useremail=:user) AND useremail!=:user;"


#duplicate project queries
select_row_to_duplicate="SELECT * from windvista_project WHERE projectID=:project_id;"
insert_wv_project="INSERT INTO windvista_project(timestamp, title, location, description, userID, masts, lidars, in_progress, published) VALUES (:ts, :tl, :loc, :desc, :uid, :mt, :ld, :ip, :pub);"
select_projectid_duplicate_project_query="SELECT max(projectID) from windvista_project WHERE timestamp=:ts;"
select_all_analysis_ids_duplicate_project="SELECT anlysID from analysis WHERE projectID=:prjid;"
update_project_id_duplicate_project="UPDATE analysis SET projectID=:prjid WHERE anlysID=:anlysid;"
update_userid_duplicate_project="UPDATE analysis SET userID=:user_id WHERE anlysID=:anlysid;"
update_project_duplicate="UPDATE windvista_project SET project_duplicate=:prj_duplicate WHERE projectID=:project_id;"
duplicate_analysis_for_duplicate_project="INSERT INTO analysis (anlysID, projectID, title, description, userID, masts, lidars,timestamp,analysis_duplicate, status) VALUES (:new_analysis_id, :projectid, :title, :description, :userID, :masts, :lidars, :timestamp, :anlysID, :status);"

#
insert_ltt_refrence_file1_query="INSERT INTO ltt_reference_files (anlysID, username, timestamp, ltt_ref_uploaded_key) VALUES (:analysis_id, :user, :timestamp, :ltt_ref_zip_object_key);"
update_ltt_refrence_file1_query="UPDATE ltt_reference_files SET timestamp=:timestamp, username=:user , ltt_ref_uploaded_key=:ltt_ref_zip_object_key WHERE anlysID=:analysis_id;"
ltt_ref_zipfile_query="SELECT ltt_ref_uploaded_key FROM ltt_reference_files WHERE anlysID=:analysis_id;"
update_ltt_refrence_file2_query="UPDATE ltt_reference_files SET ltt_ref_filename_feather=:ltt_ref_file_key WHERE anlysID=:analysis_id;"


#final download file queries
final_download_file_query="SELECT txtKey, windoscope_download, shear_download, ltt_download, anlysID FROM processed_systems_unreg WHERE prsID=:processid;"
final_download_file_query2="SELECT ltt_ref_uploaded_key FROM ltt_reference_files WHERE anlysID=:analysis_id;"
final_download_file_query3="SELECT filename FROM processed_systems_unreg WHERE prsID=:processid"
final_download_status_query="SELECT winddata, shear_feather, ltt_imp_adj FROM processed_systems_unreg WHERE prsID=:process_id;"
final_download_status_query1="SELECT shear_report_status, ltt_report_status, final_report_status FROM processed_systems_unreg WHERE prsID=:process_id;"
final_download_status_query2="SELECT final_report_download FROM final_report_audit WHERE prsID=:process_id;"
final_download_status_query3="SELECT excel_summary_download FROM summary_excel_audit WHERE prsID=:process_id;"


#summary_excel_report 
summary_excel_report_query="UPDATE analysis SET excel_summary_status='REQUEST MADE' WHERE anlysID=:analysis_id;"
summary_excel_report_query2="SELECT excel_summary_download FROM excel_summary_audit WHERE anlysID=:analysis_id;"
summary_excel_report_query3="INSERT INTO excel_summary_audit SET anlysID=:analysis_id, requested_by=:username, timestamp=:tsp;"
summary_excel_report_query4="UPDATE excel_summary_audit SET requested_by=:username, timestamp=:tsp WHERE anlysID=:analysis_id;"
summary_excel_report_query5="SELECT report_ID FROM excel_summary_audit WHERE anlysID=:analysisid;"
summary_excel_report_query6="SELECT prsID FROM processed_systems_unreg WHERE anlysID=:analysis_id;"
summary_excel_report_query7="UPDATE excel_summary_requirements_audit SET report_ID=:report_id WHERE prsID=:process_id;"
summary_excel_report_query8="SELECT * FROM excel_summary_requirements_audit WHERE prsID=:process_id;"
summary_excel_report_query9="INSERT INTO excel_summary_requirements_audit SET prsID=:process_id, report_ID=:report_id;"
summary_excel_report_query10="SELECT title FROM analysis WHERE anlysID=:analysis_id;"
summary_excel_report_query11="SELECT title, windoscope_download, shear_download, ltt_download FROM processed_systems_unreg WHERE prsID=:process_id;"


#shear_report
shear_report_status_query="UPDATE processed_systems_unreg SET shear_report_status='REQUEST MADE' WHERE prsID=:process_id;"
shear_report_status_query2="SELECT shear_report_download From shear_report_audit where prsID=:process_id;"
shear_report_status_query3="INSERT INTO shear_report_audit SET prsID=:process_id, requested_by=:requested_user, timestamp=:requested_time;"
shear_report_status_query4="UPDATE shear_report_audit SET requested_by=:username, timestamp=:timestamp WHERE prsID=:process_id;"


#final_report 
final_report_query="UPDATE processed_systems_unreg SET final_report_status='REQUEST MADE' WHERE prsID=:process_id;"
final_report_query2="SELECT final_report_download FROM final_report_audit WHERE prsID=:process_id;"
final_report_query3="INSERT INTO final_report_audit SET prsID=:process_id, requested_by=:username, timestamp=:tsp;"
final_report_query4="UPDATE final_report_audit SET requested_by=:username, timestamp=:tsp WHERE prsID=:process_id;"
final_report_query5="SELECT filename FROM processed_systems_unreg WHERE prsID=:process_id;"


#windoscope_report 
windowscope_report_query="UPDATE processed_systems_unreg SET windoscope_report_status='REQUEST MADE' WHERE prsID=:process_id;"
windoscope_report_query2="SELECT windoscope_report_download FROM windoscope_report_audit WHERE prsID=:process_id;"
windowscope_report_query3="INSERT INTO windoscope_report_audit SET prsID=:process_id, requested_by=:username, timestamp=:tsp;"
windowscope_report_query4="UPDATE windoscope_report_audit SET requested_by=:username, timestamp=:tsp WHERE prsID=:process_id;"
windowscope_report_query5="SELECT filename FROM processed_systems_unreg WHERE prsID=:process_id;"


#shear_report
shear_report_status_query="UPDATE processed_systems_unreg SET shear_report_status='REQUEST MADE' WHERE prsID=:process_id;"
shear_report_status_query2="SELECT shear_report_download From shear_report_audit WHERE prsID=:process_id;"
shear_report_status_query3="INSERT INTO shear_report_audit SET prsID=:process_id, requested_by=:requested_user, timestamp=:requested_time;"
shear_report_status_query4="UPDATE shear_report_audit SET requested_by=:username, timestamp=:timestamp WHERE prsID=:process_id;"
shear_report_query5="SELECT filename FROM processed_systems_unreg WHERE prsID=:process_id;"


# ltt report query
ltt_report_status_query="UPDATE processed_systems_unreg SET ltt_report_status='REQUEST MADE' WHERE prsID=:process_id;"
ltt_report_status_query2="SELECT ltt_report_download FROM ltt_report_audit WHERE prsID=:process_id;"
ltt_report_status_query3="INSERT INTO ltt_report_audit SET prsID=:process_id, requested_by=:username, timestamp=:tsp;"
ltt_report_status_query4="UPDATE ltt_report_audit SET requested_by=:username, timestamp=:tsp WHERE prsID=:process_id;"
ltt_report_status_query5="SELECT filename FROM processed_systems_unreg WHERE prsID=:process_id;"


#analysis_report 
analysis_report_query="UPDATE analysis SET analysis_report_status='REQUEST MADE' WHERE anlysID=:analysis_id;"
analysis_report_query2="SELECT analysis_report_download FROM analysis_report_audit where anlysID=:analysis_id;"
analysis_report_query3="INSERT INTO analysis_report_audit SET anlysID=:analysis_id, requested_by=:username, timestamp=:tsp;"
analysis_report_query4="UPDATE analysis_report_audit SET requested_by=:username, timestamp=:tsp WHERE anlysID=:analysis_id;"
analysis_report_query5="SELECT title FROM analysis WHERE anlysID=:analysis_id;"


#status queries for new reports
db_ltt_download_results_query="SELECT ltt_report_status FROM processed_systems_unreg WHERE prsID=:process_id;"
ltt_report_download_s3_status_query="SELECT ltt_report_download FROM ltt_report_audit WHERE prsID=:process_id;"

db_shear_download_results_query="SELECT shear_report_status FROM processed_systems_unreg WHERE prsID=:process_id;"
shear_report_download_s3_status_query="SELECT shear_report_status From processed_systems_unreg WHERE prsID=:process_id;"
db_analysis_download_results_query="SELECT analysis_report_status FROM analysis WHERE anlysID=:analysis_id;"
analysis_report_download_s3_status_query="SELECT analysis_report_download FROM analysis_report_audit WHERE anlysID=:analysis_id;"

db_shear_download_results_query="SELECT shear_report_status FROM processed_systems_unreg WHERE prsID=:process_id;"
shear_report_download_s3_status_query="SELECT shear_report_download From shear_report_audit WHERE prsID=:process_id;"

db_windoscope_results_query="SELECT windoscope_report_status FROM processed_systems_unreg WHERE prsID=:process_id;"
windoscope_report_download_s3_status_query="SELECT windoscope_report_download From windoscope_report_audit WHERE prsID=:process_id;"

Excel_summary_Cron_status_query="SELECT shear_report_status, ltt_report_status, final_report_status, windoscope_report_status FROM processed_systems_unreg WHERE anlysID=:analysis_id;"
Excel_summary_Cron_status_query2="SELECT excel_summary_status FROM analysis WHERE anlysID=:analysis_id;"
Excel_summary_Cron_status_query3="SELECT windoscope_download FROM processed_systems_unreg WHERE anlysID=:analysis_id;"
Excel_summary_S3_status_query="SELECT excel_summary_download FROM excel_summary_audit WHERE anlysID=:analysis_id;"


#Resetting all the status back to idle (meas_sys_config_postload)
meas_sys_config_postload_report_query="UPDATE analysis SET analysis_report_status='IDLE', excel_summary_status='IDLE' WHERE anlysID=(SELECT anlysID FROM processed_systems_unreg WHERE prsID=:process_id);"
meas_sys_config_postload_report_query2="UPDATE excel_summary_audit SET excel_summary_download=NULL WHERE anlysID=(SELECT anlysID FROM processed_systems_unreg WHERE prsID=:process_id);"
meas_sys_config_postload_report_query3="UPDATE analysis_report_audit SET analysis_report_download=NULL WHERE anlysID=(SELECT anlysID FROM processed_systems_unreg WHERE prsID=:process_id);"
meas_sys_config_postload_report_query4="UPDATE processed_systems_unreg SET shear_report_status='IDLE', ltt_report_status='IDLE', final_report_status='IDLE', windoscope_report_status='IDLE' WHERE prsID=:process_id;"
meas_sys_config_postload_report_query5="UPDATE final_report_audit SET final_report_download=NULL WHERE prsID=:process_id;"
meas_sys_config_postload_report_query6="UPDATE ltt_report_audit SET ltt_report_download=NULL WHERE prsID=:process_id;"
meas_sys_config_postload_report_query7="UPDATE shear_report_audit SET shear_report_download=NULL WHERE prsID=:process_id;"
meas_sys_config_postload_report_query8="UPDATE windoscope_report_audit SET windoscope_report_download=NULL WHERE prsID=:process_id;"


#generate_tab_file_preload_query
generate_tab_file_preload_query="SELECT * FROM processed_systems_unreg WHERE prsID=:processid;"


#download_text_file_query
download_text_file_query="SELECT txtKey, filename FROM processed_systems_unreg WHERE prsID=:processid;"


#mail send on shared project title query
select_project_name_query="SELECT title FROM windvista_project WHERE projectID=:project_id;"


#mail receiver first name query
receiver_first_name_query="SELECT first_name FROM usertable WHERE useremail=:receiver_mail;"


#mail sender first name query
sender_first_name_query="SELECT first_name FROM usertable WHERE useremail=:email;"