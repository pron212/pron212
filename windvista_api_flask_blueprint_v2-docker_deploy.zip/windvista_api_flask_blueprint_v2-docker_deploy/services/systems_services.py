# -*- coding: utf-8 -*-

from unicodedata import name
from flask import request
import requests
import os
import shutil
from sqlalchemy import text
from db.queries import *
from routes import *
import pyarrow.feather as feather
from janitor import clean_names
import random
import pandas as pd
import pyshorteners
import datetime
import zipfile
import json
import tempfile
import re
import csv
from os import environ
import humanize
from itertools import chain
import zipfile

s3R = boto3.resource(
    's3', 
    aws_access_key_id=environ.get("AWS_ACCESS_KEY_ID") , 
    aws_secret_access_key=environ.get("AWS_SECRET_ACCESS_KEY"), 
    region_name="us-east-1"
    )


##############################
##
## PROCESS-ID LTT FUNCTION
##
##############################


def prsid_ltt(user, timestamp, process_id):
        
    with db.connect() as conn:
        is_user = conn.execute(text(recent_system_name_query), user=user).fetchone()
        
        if is_user is None:
            conn.execute(text(insert_recent_system_query_prsID_ltt),user=user, timestamp=timestamp, process_id=process_id)
            conn.close()
        
        else:
            conn.execute(text(update_recent_system_query_prsID_ltt), user=user, timestamp=timestamp, process_id=process_id)
            conn.close()

    return "successfully done", 200


#####################################
##
## LTT REF UPLOADED BINARY FUNCTION
##
#####################################


def ltt_ref_uploaded_binary(user, timestamp, analysis_id, files):

        print(files)
        files = files['files']
        random_number = random.randint(1,100)
        
        feather_file = f"ltt_ref_filename{random_number}.feather"

        df = pd.DataFrame([file for file in files])
        feather.write_feather(df, feather_file)
        
        feather_filename = os.path.join(feather_file)

        ltt_ref_zip_object_key = f"{user}/lttref/{analysis_id}/ltt_ref_uploaded.zip"
        ltt_ref_feather_key = f"{user}/lttref/{analysis_id}/ltt_ref_filename.feather"
        
        # for feather file upload
        response = s3.generate_presigned_post('windvista-dev',ltt_ref_feather_key,Fields=None,Conditions=None,ExpiresIn=3600)

        # Demonstrate how another Python program can use the presigned URL to upload a file
        with open(feather_filename, 'rb') as f:
            files = {'file': (feather_filename, f)}
            http_response = requests.post(response['url'], data=response['fields'], files=files)

        with db.connect() as conn:
            results = conn.execute(text(all_ltt_files),analysis_id=analysis_id).fetchone()
            if results is not None:
                conn.execute(text(update_ltt_refrence_file_query), timestamp=timestamp, user=user , ltt_ref_zip_object_key=ltt_ref_zip_object_key, ltt_ref_file_key=ltt_ref_feather_key, analysis_id=analysis_id)
            else:
                conn.execute(text(insert_ltt_refrence_file_query), analysis_id=analysis_id, user=user, timestamp=timestamp, ltt_ref_zip_object_key=ltt_ref_zip_object_key, ltt_ref_file_key=ltt_ref_feather_key)
        
        os.remove(feather_filename)
        
        return "successfully done", 200


#########################################
##
## LTT REF UPLOADED BINARY URL FUNCTION
##
#########################################


def ltt_ref_uploaded_binary_url(user,token,api_need,primary_key,filename,mode):

    if mode.lower() == "celery":
        ltt_ref_zip_object_key = f"{user}/temp/{token}/{api_need}/{primary_key}/{filename}"
    
    else:
        ltt_ref_zip_object_key = f"{user}/{api_need}/{primary_key}/{filename}"
    response = s3.generate_presigned_post(environ.get("AWS_S3_BUCKET"),ltt_ref_zip_object_key,Fields=None,Conditions=None,ExpiresIn=300)
    print(response)
    
    return {"url":f"{response['url']}","url_fields":{"key":f"{response['fields']['key']}",
    "AWSAccessKeyId":f"{response['fields']['AWSAccessKeyId']}","policy":f"{response['fields']['policy']}",
    "signature":f"{response['fields']['signature']}"}}, 200    




####################################
##
## LTT REF FILE UPLOADED FUNCTION
##
####################################


def ltt_ref_file_upload(user, timestamp, analysis_id, data):
        
    random_number = random.randint(1,100)
    local_file_name = f"ltt_downloadfile{random_number}.zip"
    dir_name = f"feather{random_number}"
    os.mkdir(dir_name)

    # if file is already present delete it
    if(os.path.isfile(local_file_name)):
        os.remove(local_file_name)

    # writing a local file
    with open(local_file_name, "wb") as f:
        f.write(data)
    
    ltt_ref_zip_object_key = f"{user}/lttref/{analysis_id}/ltt_ref_uploaded.zip"
    
    # for zip file upload
    response = s3.generate_presigned_post(environ.get("AWS_S3_BUCKET"),ltt_ref_zip_object_key,Fields=None,Conditions=None,ExpiresIn=3600)

    # Demonstrate how another Python program can use the presigned URL to upload a file
    with open(local_file_name, 'rb') as f:
        files = {'file': (local_file_name, f)}
        http_response = requests.post(response['url'], data=response['fields'], files=files)
    
    with db.connect() as conn:
        results = conn.execute(text(all_ltt_files),analysis_id=analysis_id).fetchone()
        
        if results is not None:
            conn.execute(text(update_ltt_refrence_file1_query), timestamp=timestamp, user=user , ltt_ref_zip_object_key=ltt_ref_zip_object_key,analysis_id=analysis_id)
        
        else:
            conn.execute(text(insert_ltt_refrence_file1_query), analysis_id=analysis_id, user=user, timestamp=timestamp, ltt_ref_zip_object_key=ltt_ref_zip_object_key)
    
    os.remove(local_file_name)
    shutil.rmtree(dir_name)

    return "File Uploaded successfully", 200


####################################
##
## LTT REF FILE POSTLOAD FUNCTION
##
####################################


# def  ltt_ref_file_postload(user, analysis_id):
        
#     random_number = random.randint(1,100)
#     local_file_name = f"ltt_downloadfile{random_number}.zip"
#     dir_name = f"feather{random_number}"
#     os.mkdir(dir_name)

#     # if file is already present delete it
#     if(os.path.isfile(local_file_name)):
#         os.remove(local_file_name)

#     with db.connect() as conn:
#         result = conn.execute(text(ltt_ref_zipfile_query), analysis_id=analysis_id).fetchone()
#         conn.close()
        
#         if result is None:
#             return {"message": "Given analysis id does not exists"},404
#         for row in result:
#             ltt_ref_zipfile = row

#     s3.download_file(environ.get("AWS_S3_BUCKET"), ltt_ref_zipfile, local_file_name)
    
#     # extracting zip file
#     with zipfile.ZipFile(local_file_name, 'r') as zip_ref:
#         zip_ref.extractall(dir_name)
    
#     files = []
    
#     for file in os.listdir(dir_name):
#         if file.endswith(".txt"):
#             files.append(file)

#     ltt_ref_feather_key = f"{user}/lttref/{analysis_id}/ltt_ref_filename.json"

#     # for feather file upload
#     response = s3.generate_presigned_post(environ.get("AWS_S3_BUCKET"),ltt_ref_feather_key,Fields=None,Conditions=None,ExpiresIn=3600)

#     with db.connect() as conn:
#         conn.execute(text(update_ltt_refrence_file2_query), ltt_ref_file_key=ltt_ref_feather_key, analysis_id=analysis_id)
    
#     os.remove(local_file_name)
#     shutil.rmtree(dir_name)

#     return {"url":f"{response['url']}","url_fields":{"key":f"{response['fields']['key']}",
#     "AWSAccessKeyId":f"{response['fields']['AWSAccessKeyId']}","policy":f"{response['fields']['policy']}",
#     "signature":f"{response['fields']['signature']}"},"files":files}, 200


#########################################
##
## LTT DOWNLOAD RESULT FUNCTION
##
#########################################


def ltt_download_result(process_id):

    # global variable scope
    ltt_download_link = None
    file_name = None
    timestamp = None
    ltt_download = None

    with db.connect() as conn:
        results = conn.execute(text(ltt_download_results_query),process_id=process_id).fetchone()
        conn.close()
        
        if results is not None:
            for link in results:
                ltt_download_link = link
        else:
            return {"message": "The given process id does not exists"},404


    # filename for download
    with db.connect() as conn:
        names = conn.execute(text(select_processed_ltt_downl_result), process_id=process_id)
        conn.close()
        
        for name in names:
            file_name = name[0]
            timestamp = name[1]
            ltt_download = name[2]
        
    if ltt_download == "NA":
        return {"message": "ltt_download_file is not present"},404   

    foo = ''.join(file_name.split())
    systemName = foo[:-4]
    
    first_time = timestamp
    give_time = first_time

    if len(give_time)>7:
        give_time = int(first_time[:-3])    
    systemTime = datetime.datetime.fromtimestamp(give_time).strftime('%Y-%m-%d-%H-%M-%S')

    if ltt_download_link == None:
        return {"message": "ltt_download_file is not present"},404   

    else:
        new_file_download_name = f"{systemName}-LTT-{systemTime}-Plots-tables.zip"
        url = s3.generate_presigned_url(
        ClientMethod='get_object', 
        ExpiresIn=300,
        Params={
            'Bucket': environ.get("AWS_S3_BUCKET"), 
            'Key': ltt_download_link,
            'ResponseContentDisposition': 'attachment;filename={}'.format(new_file_download_name),
            'ResponseContentType': 'application/zip'
            }
        )

        short = pyshorteners.Shortener()
        download_url = short.tinyurl.short(url)

        return download_url,200


##########################
##
## LTT ANALYSIS FUNCTION
##
#########################


def ltt_analysis(process_id):

    # global variable
    ltt_imp_adj = None
    
    with db.connect() as conn:
        result = conn.execute(text(ltt_imp_adj_query), process_id=process_id).fetchone()
        
        if result is None:
            return {"message": "In Processing"},200
        
        for row in result:
            if row is None:
                return {'status':10, "message": "In Processing"},200
            ltt_imp_adj = row

    data = ltt_imp_adj.strip("%")

    return data,200


#####################################
##
## DB LTT REF FILE STATUS FUNCTION
##
#####################################


def db_ltt_ref_file_status(analysis_id):

    try:
    
        if analysis_id is None:
            return {"message": "Invalid Url"},200
    
        # global variable 
        random_number = random.randint(1,111)
        feather_filename = f"name{random_number}.feather"

        with db.connect() as conn:
            result = conn.execute(text(ltt_ref_files_query), analysis_id=analysis_id).fetchone()
            conn.close()
    
            if result is None:
                return {"message": "Given analysis id does not exists"},404
    
            for row in result:
                ltt_ref_filename_feather = row

        if ltt_ref_filename_feather == "NA":
            return {"filenames": "No Files Uploaded"}
        
        print(ltt_ref_filename_feather)

        s3.download_file(environ.get("AWS_S3_BUCKET"), ltt_ref_filename_feather, feather_filename)
        result = feather.read_feather(feather_filename)
        os.remove(feather_filename)
        
        df = result
        json_convert = df.to_json(orient = 'records')

        raw_data = json.loads(json_convert)
        data = []
        json_data = json.dumps(raw_data)
        load_data = json.loads(json_data)

        try:
            for i in load_data:
                data.append(i['None'])
        
        except Exception as e:
            print(e)
            if KeyError:
                try:
                    for i in load_data:
                        data.append(i['0'])

                except Exception as e:
                    print(e)
                    if KeyError:
                        for i in load_data:
                            data.append(i['.'])       
    
    except:
        return {"message": "Exception Occured!"}, 200

    return {'filenames':data},200


##########################################
##
## DB LTT DOWNLOAD RESULT STATUS FUNCTION
##
##########################################


def db_ltt_download_result_status(process_id):

    newtable_session = None
    file_name = None
    time_stamp = None
    ltt_download = None

    # get windex_graph from recent file
    with db.connect() as conn:
        result = conn.execute(text(ltt_session_query), process_id=process_id).fetchone()
        ltt_updatedtime = conn.execute(text(ltt_updated_time), process_id=process_id).fetchone()
        conn.close()
        
        if result is None:
            newtable_session = 0
            update_status = 0
        
        else:
            newtable_session = result[0]
        
        if ltt_updatedtime is None:
            ltt_updatedtime = 0
        
        else:
            ltt_updatedtime = ltt_updatedtime[0]

    # filename for download
    with db.connect() as conn:
        names = conn.execute(text(db_ltt_query), process_id=process_id).fetchall()
        conn.close()
        
        if(len(names) == 0):
            return {"message": "the given process id does not exists"},404

        if names is None:
            return {"message": "the given process id does not exists"},404
        
        else:
            for name in names:
                file_name = name[0]
                timestamp = name[1]
                ltt_download  = name[2]
        
    if ltt_download  == None or ltt_download == "NA":
        error_data = {
            "status":"No Data Available",
            "session_status": newtable_session
        }
        return error_data,200

    first_time = timestamp
    give_time = first_time

    if len(give_time)>7:
        give_time = int(first_time[:-3])    
    systemTime = datetime.datetime.fromtimestamp(give_time).strftime('%Y-%m-%d')
    
    if ltt_download == None:
        error_data = {
            "status":"No Data Available",
            "session_status": newtable_session
        }
        return error_data,200

    try:
        systemName = file_name[:file_name.index("xported") + len("xported")]
    except:
        systemName = file_name[:-4]
    
    systemName = re.sub(r"(_|-)+", " ", systemName).title().replace(" ", "-")
    filename = f"{systemName}-LTT-Outputs_{systemTime}"
    filename = f"{filename}.zip"

    data = {
        "status":"Results Ready for Downloading",
        "filename":filename,
        "session_status":newtable_session,
        "Updated_time": ltt_updatedtime
    }

    return data,200


############################
##
## SHEAR ANALYSIS FUNCTION
##
###########################


def shear_analysis(process_id): 

    temp = tempfile.NamedTemporaryFile()

    try:
        File_Loc = None
        selected_comb = None
        d = None
    
        try:
            with db.connect() as conn:
                d = conn.execute(text(shear_analysis_query), process_id=process_id).fetchone()
            File_Loc = d[0]
            selected_comb = d[1]
           
        except Exception as e:
            File_Loc = None

        if File_Loc is None:
            return {"message": "In Processing"}, 200
    
        if File_Loc in 'NA':
            return {"status" : 10, "message": "In processing"}, 200
           
        s3 = boto3.resource('s3')
        s3.Bucket(environ.get("AWS_S3_BUCKET")).download_file(File_Loc, temp.name)

        data = pd.read_feather(temp.name)
        shear_analysis = pd.DataFrame(data)
        print(shear_analysis)

        if 'Combinations' in shear_analysis.columns:
            if selected_comb is None:
                shear_analysis = shear_analysis.loc[shear_analysis['Combinations'] == shear_analysis["Combinations"].unique()[0]]
            else:
                shear_analysis = shear_analysis.loc[shear_analysis['Combinations'] == selected_comb]
        
        shear_analysis = shear_analysis.filter(['Height','Prediction'], axis=1)
        shear_analysis.rename(columns = {'Height':'height','Prediction':'result'}, inplace = True)
    
    finally:
        temp.close()

    return shear_analysis.to_dict(orient="records"), 200


####################################
##
## SHEAR DOWNLOAD RESULTS FUNCTION
##
####################################


def shear_download_results(process_id):

    shear_download_link = None
    file_name = None
    timestamp = None
    shear_download = None

    with db.connect() as conn:
        results = conn.execute(text(shear_download_resultss_query),process_id=process_id).fetchone()
        conn.close()
        
        if results is not None:
            for link in results:
                shear_download_link = link
        else:
            return {"message": "The given process id does not exists"},404

    # filename for download
    with db.connect() as conn:
        names = conn.execute(text(select_processed_shear_downl_result), process_id=process_id)
        conn.close()
        
        for name in names:
            file_name = name[0]
            timestamp = name[1]
            shear_download  = name[2]
        
    if shear_download  == "NA":
        return {"message": "shear_download_file is not present"},404   

    foo = ''.join(file_name.split())
    systemName = foo[:-4]
    
    first_time = timestamp
    give_time = first_time

    if len(give_time)>7:
        give_time = int(first_time[:-3])    
    systemTime = datetime.datetime.fromtimestamp(give_time).strftime('%Y-%m-%d-%H-%M-%S')

    if shear_download_link == None:
        return {"message": "shear_download_file is not present"},404

    else:
        new_file_download_name =  new_file_download_name = f"{systemName}-Shear-{systemTime}-Plots-tables.zip"
        url = s3.generate_presigned_url(
        ClientMethod='get_object', 
        ExpiresIn=300,
        Params={
            'Bucket': environ.get("AWS_S3_BUCKET"), 
            'Key': shear_download_link,
            'ResponseContentDisposition': 'attachment;filename={}'.format(new_file_download_name),
            'ResponseContentType': 'application/zip',
            }
        )

        short = pyshorteners.Shortener()
        download_url = short.tinyurl.short(url)

        return download_url,200


#############################################
##
## DB SHEAR DOWNLOAD RESULTS STATUS FUNCTION
##
#############################################


def db_shear_download_results_status(process_id):

    newtable_session = None
    file_name = None
    time_stamp = None
    shear_download = None

    # get windex_graph from recent file
    with db.connect() as conn:
        result = conn.execute(text(shear_session_query), process_id=process_id).fetchone()
        updatedtime = conn.execute(text(shear_updated_time),process_id=process_id).fetchone()
        conn.close()

        if updatedtime is None:
            updatedtime = 0
        else:
            updatedtime= updatedtime[0]

        if result is None:
            newtable_session = 0
            update_status = 0
        else:
            newtable_session = result[0]

    # filename for download
    with db.connect() as conn:
        names = conn.execute(text(db_shear_query), process_id=process_id).fetchall()
        #shear_skip = conn.execute(text(db_shear_query), process_id=process_id).fetchone()
        conn.close()
        
        if(len(names) == 0):
            return {"message": "the given process id does not exists"},404

        if names is None:
            return {"message": "the given process id does not exists"},404
        else:
            for name in names:
                file_name = name[0]
                timestamp = name[1]
                shear_download  = name[2]
                shear_skip = name[3]
    print(shear_skip)
    if shear_skip.lower() == "true":
        return {"message":"For rendering these results, please create a new system where the input text file contains latitude, longitude and elevation, followed by column headers: Date/Time, WD and 2 WS columns."},200

    if shear_download  == None or shear_download == "NA":
        error_data = {
            "status":"No Data Available",
            "session_status": newtable_session
        }

        return error_data,200

    
    first_time = timestamp
    give_time = first_time

    if len(give_time)>7:
        give_time = int(first_time[:-3])    
    systemTime = datetime.datetime.fromtimestamp(give_time).strftime('%Y-%m-%d')
    
    if shear_download == None:
        error_data = {
            "status":"No Data Available",
            "session_status": newtable_session
        }
        return error_data,200

    try:
        systemName = file_name[:file_name.index("xported") + len("xported")]
    
    except:
        systemName = file_name[:-4]
    
    systemName = re.sub(r"(_|-)+", " ", systemName).title().replace(" ", "-")
    filename = f"{systemName}-Shear-Outputs_{systemTime}"
    filename = f"{filename}.zip"

    
    data = {
        "status":"Results Ready for Downloading",
        "filename":filename,
        "session_status":newtable_session,
        "updated_time":updatedtime
    }

    return data, 200


#############################
##
## FINAL APPROACH FUNCTION
##
############################


def Final_Approach(process_id):

    temp = tempfile.NamedTemporaryFile()

    try:   
        
        with db.connect() as conn:
            feather_url = conn.execute(text(final_approach_query),process_id=process_id).fetchone()
            if feather_url is None:
                return {"message": "Given process id does not exists"}, 404
        
        ltt_imp_adj = feather_url[0]
        shear_feather = feather_url[1]
        user =  feather_url[2]
        
        if ltt_imp_adj=="NA" or ltt_imp_adj=="NaN %" or ltt_imp_adj is None or shear_feather=="NA" or shear_feather is None:
            return {"message": "In Processing"}, 200
        
        s3.download_file(environ.get("AWS_S3_BUCKET"), shear_feather, temp.name)
        data = feather.read_feather(temp.name)

        ltt_analysis = float(ltt_imp_adj.strip("%"))  
        
        if ltt_analysis >= 0:
            ltt_analysis_2 = (ltt_analysis / 100) + 1
        
        elif ltt_analysis < 0:
            ltt_analysis_2 = 1 - (abs(ltt_analysis) / 100)
         
        shear_analysis = pd.DataFrame(data)

        if 'Combinations' in shear_analysis.columns:
            shear_analysis = shear_analysis.loc[shear_analysis['Combinations'] == shear_analysis["Combinations"].unique()[0]]
        
        final_approach = shear_analysis
        final_approach["final"] = ((shear_analysis['Prediction']).astype(float))*ltt_analysis_2
        final_approach["final"] = final_approach["final"].apply("{:,.3f}".format)

        #final data is for response
        final_data = final_approach.filter(['Combinations','Height','final'], axis=1)
        final_data.rename(columns = {'Height':'height','Combinations':'combinations'}, inplace = True)
        
        if 'Combinations' in shear_analysis.columns:
            #combinations , height and final for storing the data
            store_data = final_approach.filter(['Combinations','Height','final'], axis=1)
            store_data.rename(columns = {'Height':'height','Combinations':'combinations'}, inplace = True)
    
        else:
            store_data = final_approach.filter(['Height','final'], axis=1)
            store_data.rename(columns = {'Height':'height'}, inplace = True)
        
        final_data = final_approach.filter(['Height','final'], axis=1)
        final_data.rename(columns = {'Height':'height'}, inplace = True)

        feather_obj = f"{user}/{process_id}/final/final_approach.feather"

        #feather file
        filename_feather = f"final_approach_{user}_{process_id}_{random.randint(1,1000)}.feather"
        feather.write_feather(store_data,filename_feather,version=1)

        csv_obj = f"{user}/{process_id}/final/final_approach.csv"
        #csv file
        filename_csv = f"final_approach_{user}_{process_id}_{random.randint(1,1000)}.csv"
        store_data.to_csv(filename_csv, index=False)

        # for feather upload
        response = s3.generate_presigned_post(environ.get("AWS_S3_BUCKET"),feather_obj,Fields=None,Conditions=None,ExpiresIn=3600)
        with open(filename_feather, 'rb') as f:
            files = {'file': (filename_feather, f)}
            http_response = requests.post(response['url'], data=response['fields'], files=files)

        # for csv upload
        response = s3.generate_presigned_post(environ.get("AWS_S3_BUCKET"),csv_obj,Fields=None,Conditions=None,ExpiresIn=3600)
        with open(filename_csv, 'rb') as f:
            files = {'file': (filename_csv, f)}
            http_response = requests.post(response['url'], data=response['fields'], files=files)    
     
        final_feather_status_key = feather_obj
        csv_key = csv_obj
    
        with db.connect() as conn:
            conn.execute(text(final_approach_update_query),final_feather_status_key=final_feather_status_key, process_id=process_id)

        with db.connect() as conn:
                check = conn.execute(text(summary_excel_report_query8), process_id=process_id).fetchone()
        
        if check is None:
            with db.connect() as conn:
                conn.execute(text(final_approach_update_query2), process_id=process_id, finalrequirements=csv_key)
        
        else:
            with db.connect() as conn:
                conn.execute(text(final_approach_update_query3), finalrequirements=csv_key, process_id=process_id)

        if os.path.exists(filename_feather):
            os.remove(filename_feather)
        
        if os.path.exists(filename_csv):
            os.remove(filename_csv)
    
    except Exception as e:
        print(e)
        return {"message": "Exception Occured!"}, 200

    finally:
        
        temp.close()
    
    return final_data.to_dict(orient="records"), 200


def atoi(text):
    return int(text) if text.isdigit() else text

def natural_keys(text):
    return [atoi(c) for c in re.split('(\d+)', text)]

def key(s):
    return tuple(map(int, re.findall(r'\d+', s)))


def AnsCD(file_location):

    with open(file_location, "r") as file:
        tsv_file = csv.reader(file, delimiter="\t")
        y = 0
        for line in tsv_file:
            y += 1
            if 'Date/Time' in line:
                break
    
    input_file = pd.read_csv(file_location, sep="\t", skiprows=y - 1, encoding='ISO-8859-1')
    windata_mean = input_file.clean_names().remove_empty()
    cols = windata_mean.columns
    cols = cols.tolist()
    ws_sensors_name = "ws"
    wd_sensors_name = "wd"
    ws_sensors = [string for string in cols if
                ws_sensors_name in string and not "vws" in string and not "sd" in string and not "ti" in string and not "min" in string and not "max" in string and not "avg" in string]
    height_list = []
    
    for sensor in ws_sensors:
        num = ''
        for c in sensor:
            if c.isdigit():
                num = num + c
        height_list.append(num)
    
    height_list = list(dict.fromkeys(height_list))
    height_list.sort(key=natural_keys, reverse=True)
    wd_sensors = [string for string in cols if wd_sensors_name in string]
    wd_sensors.sort(key=natural_keys, reverse=True)
    height = []
    
    for sensor in ws_sensors:
        num = ""
        for c in sensor:
            if c.isdigit():
                num = num + c
        height.append(int(num))
    doube_sensor = set([x for x in height if height.count(x) > 1])
    
    for item in doube_sensor:
        ws_sensors.append("ws_" + str(item) + "_mean_[m/s]")
    ws_sensors.sort(key=natural_keys, reverse=True)
    
    for i in range(len(wd_sensors)):
        wd_sensors[i] = wd_sensors[i].upper()
        wd_sensors[i] = re.sub("([\(\[]).*?([\)\]])", "\g<1>\g<2>", wd_sensors[i])
        wd_sensors[i] = wd_sensors[i].replace('[]', '[°]')

    for iz in range(len(ws_sensors)):

        if not  'mean_[m/s]' in ws_sensors[iz]:
            ws_sensors[iz] =  ws_sensors[iz].upper().replace('MEAN_[M_S]', 'mean_[m/s]')
        
        else:
            ws_sensors[iz] =  ws_sensors[iz].upper().replace('MEAN_[M/S]', 'mean_[m/s]')
    
    height_list = [int(item) for item in height_list]
    height_list.sort(reverse=True)
    wd_sensors.sort(key=key,reverse=True)
    ws_sensors.sort(key=key,reverse=True)

    return [height_list, wd_sensors, ws_sensors]


###################################
##
## SYSTEM WS WD SENSORS FUNCTION
##
###################################


def Systems_WS_WD_Sensors(name, dir_name, data):
    
    filename = data

    try:
        
        with open(filename, 'rb') as ds:
            daataa = ds.read()
        
        byteTOstr = daataa.decode('utf-8', 'ignore')
        filename2 = f'{dir_name}/Ws_Wd.txt'
        
        with open(filename2, 'w') as ds:
            ds.writelines(byteTOstr)

        data = AnsCD(filename2)

    except Exception as e:
        print(e)

    try:

        with open(filename, "r", encoding='ISO-8859-1') as file:
            tsv_file = csv.reader(file, delimiter="\t")
            y = 0
            for line in tsv_file:
                y += 1
                if 'Date/Time' in line:
                    break
        
        meta_data = pd.read_csv(filename, sep="\t", skiprows=y - 1, encoding='ISO-8859-1')
        input_data = meta_data.clean_names().remove_empty()
        
        df = pd.DataFrame(input_data)
        column = df.iloc[:,:1]
        print("\n Date_Time Data : \n\n", column)
        #print("\n\n", input_data)

        if len(column) == 0:
            return {"Status":"Invalid File", "message":"txt file dont have Date-Time column"}

        if df['date_time'].isnull().any():
            return {"Status":"Invalid File", "message":"some entries of Date-Time column is NaN"}

        if df.columns.str.contains('unnamed_').any():
            return{"Status":"Invalid File", "message":"txt file contains some unnamed columns"}

    except Exception as e:
        print(e)

    finally:

        if os.path.exists(name):
            os.remove(name)
        
        if os.path.exists(dir_name):
            shutil.rmtree(dir_name)

    print("LOL")
    print(set(data[0]))

    return {"anemo_list":list(set(data[0])), "direction_name":list(set(data[1])), "anemo_name":list(set(data[2]))}, 200


#########################################
##
## MEANS SYS CONFIG UNREG FUNCTION
##
#########################################


def meas_sys_config_unreg(comb_shear,user, anlysID, title, Anemo_name, Direction_name, timestamp, systemType, sourcefrom, filename, Target_height,shear_skip):
    
    if len(title) < 3 or len(title) > 40:
        return {"message":"Adding a new system's title the character length should always between 3 to 40."}, 200

    json_data = comb_shear.decode('utf-8', 'ignore')
    titles = None

    if not comb_shear:
        return {"message": "json file not found! "}
    pingInfoFilePath = "x.json"

    try:
        st = systemType
        if st.lower() not in ['masts','mast','lidars','lidar']:
            return {"message":"system type incorrect"},200
        
        with open(pingInfoFilePath, 'w') as f:
            f.write(json_data)
        
        with db.connect() as conn:
            titles = conn.execute(text(meas_sys_config_unreg_query), user=user, anlysID=anlysID).fetchall()
            Process_id = conn.execute(f"SELECT prsID FROM processed_systems_unreg;").fetchall()

        y = list(map(lambda v: v[0].lower(), titles))

        if title.lower() in y:
            return {"message": "Title already exist"}, 200

        else:

            prs_ids = list(map(lambda v: v[0], Process_id))
            New_Prs_Id = 1 if not (len(prs_ids)) else (max(prs_ids) + 1)
            txtkey = f"{user}/{New_Prs_Id}/shear/combination/combination.json"
            response = s3.generate_presigned_post(environ.get("AWS_S3_BUCKET"), txtkey, Fields=None, Conditions=None, ExpiresIn=3600)
            
            with open(pingInfoFilePath, 'rb') as f:
                files = {'file': (pingInfoFilePath, f)}
                http_response = requests.post(response['url'], data=response['fields'], files=files)

            Anemo_name = Anemo_name.lower().replace('mean_[°]', 'mean_u_00b0')
            Direction_name = Direction_name.lower().replace('mean_[m/s]', 'mean_m_s')
            
            with db.connect() as conn:
                conn.execute(text(insert_meas_sys_config_unreg_query), user=user,
                            anlysID=anlysID, timestamp=timestamp, systemType=systemType, title=title,
                            sourcefrom=sourcefrom, filename=filename, comb_shear=txtkey,
                            Target_height=Target_height, Anemo_name=Anemo_name, Direction_name=Direction_name,
                            tempraw_status=0,shear_skip = shear_skip)
            
            with db.connect() as conn:
                    res = conn.execute(text(meas_sys_config_unreg_query2),analysisid=anlysID).fetchone()
            
            project_id = res[0]
            
            if st.lower() in ['mast','masts']:
                with db.connect() as conn:
                    conn.execute(text(measurement_system_unreg_query_mast),analysisid=anlysID)
                    conn.execute(text(measurement_system_unreg_query_mast2),projectid=project_id)
            
            elif st.lower() in ['lidar','lidars']:
                with db.connect() as conn:
                    conn.execute(text(measurement_system_query_unreg_lidar),analysisid=anlysID)     
                    conn.execute(text(measurement_system_query_unreg_lidar2),projectid=project_id)
            
            return {"process_id": New_Prs_Id}, 200

    finally:
        print("You got Cheesed!")
        if os.path.exists(pingInfoFilePath):
            os.remove(pingInfoFilePath)


#####################
##
## LONGLAT FUNCTION
##
#####################


def LongLat(filename):

    with open(filename, 'rb') as ds:
        daataa2 = ds.read()
        
    byteTOstr2 = daataa2.decode('utf-8', 'ignore')
    with open(filename, 'w') as ds:
        ds.writelines(byteTOstr2)
    
    data1 = []
    with open(filename) as x:
        for line in x:
            if "longitude" in line.lower():
                data1.append(line.replace("\t", "").replace("\n", ""))
            if "latitude" in line.lower():
                data1.append(line.replace("\t", "").replace("\n", ""))

    lat1 = float(data1[0].split(" ")[-1])
    long1 = float(data1[1].split(" ")[-1])
    
    return [lat1, long1]


#########################################
##
## MEANS SYS CONFIG POSTLOAD FUNCTION
##
#########################################


def meas_sys_config_postload(process_id, user,timestamp):

    # temp = tempfile.NamedTemporaryFile()
    # random_number = random.randint(1,100)
    if timestamp is None:
        return {"message":"please provide timestamp"},200
    try:
        # update = None
        # filename2 = f'{process_id}lol.txt'
        # filename = f"{process_id}_meas_sys_config_unreg_postload_{random_number}.txt"
        # local_file_name = f"meas_sys_config_postload_{process_id}_{random_number}.zip"
        # dir_name = f"MeasSysConfigUnreg{random_number}_{process_id}"
        # string = updates

        # if string.lower() == "true":
        #     update = True
        
        # else:
        #     update = False    

        # request.body
        # data = request.get_data()
        # if not data:
        #     return {"message": "zip file not found!"}, 200

        # extract_filename = None
        
        # os.mkdir(dir_name)

        # writing a local file
        # with open(local_file_name, "wb") as f:
        #     f.write(data)

        # extracting zip file
        # with zipfile.ZipFile(local_file_name, 'r') as zip_ref:
        #     zip_ref.extractall(dir_name)
        
        # files = []
        # for file in os.listdir(dir_name):
        #     if file.endswith(".txt"):
        #         files.append(file)

        # tempfilename = files[0]
        # temp1 = f"{dir_name}/{tempfilename}"
        # with open(temp1, "rb") as f:
        #     data_x = f.read()
        
        # random_number = random.randint(1,111)
        # with open(filename, "wb") as f:
        #     f.write(data_x)    
        
        #text key
        txtkey = f"{user}/{process_id}/raw/raw.txt"
        #txt url
        txturl = f"https://{environ.get('AWS_S3_BUCKET')}.s3.amazonaws.com/{txtkey}"
        
        # if not update:
        #     print("ye chala false")
            # s3 = boto3.client('s3')
            # response = s3.generate_presigned_post(environ.get("AWS_S3_BUCKET"),txtkey,Fields=None,Conditions=None,ExpiresIn=3600)
            
            # with open(filename, 'rb') as f:
            #     files = {'file': (filename, f)}
            #     http_response = requests.post(response['url'], data=response['fields'], files=files)
            #     print(http_response)

        with db.connect() as conn:
            response_query = conn.execute(text(update_meas_sys_config_postload_query),textkey=txtkey,texturl=txturl,tmsp=timestamp,process_id=process_id)

        #Making status IDLE again for excel summary and analysis reports
        with db.connect() as conn:
            conn.execute(text(meas_sys_config_postload_report_query),process_id=process_id)
            try:
                conn.execute(text(meas_sys_config_postload_report_query2),process_id=process_id)
            except:
                pass
            try:
                conn.execute(text(meas_sys_config_postload_report_query3),process_id=process_id)
            except:
                pass

        # else:

        #     with db.connect() as conn:
        #         result = conn.execute(text(meas_sys_config_postload_txtkey_query),process_id=process_id).fetchone()
                
            # s3 = boto3.resource('s3')
            # s3.Bucket(environ.get("AWS_S3_BUCKET")).download_file(result[0], temp.name)

            # LatLong= LongLat(temp.name)
            # lat1 = LatLong[0]
            # long1 = LatLong[1]

            # LatLong= LongLat(temp.name)
            # lat2 = LatLong[0]
            # long2 = LatLong[1]
            
            # if lat1 == lat2 and long1 == long2:
            #     s3 = boto3.client('s3')
            #     response = s3.generate_presigned_post(environ.get("AWS_S3_BUCKET"),txtkey,Fields=None,Conditions=None,ExpiresIn=3600)
            #     with open(filename, 'rb') as f:
            #         files = {'file': (filename, f)}
            #         http_response = requests.post(response['url'], data=response['fields'], files=files)
            #         print(http_response)

                # with db.connect() as conn:
                #     response_query = conn.execute(text(update_meas_sys_config_postload_query),textkey=txtkey,texturl=txturl,tmsp=timestamp,process_id=process_id)

                # #Making status IDLE again for all reports
                # with db.connect() as conn:
                #     conn.execute(text(meas_sys_config_postload_report_query),process_id=process_id)
                    
                #     try:
                #         conn.execute(text(meas_sys_config_postload_report_query2),process_id=process_id)
                #     except:
                #         pass
                #     try:
                #         conn.execute(text(meas_sys_config_postload_report_query3),process_id=process_id)
                #     except:
                #         pass
                    
                #     conn.execute(text(meas_sys_config_postload_report_query4),process_id=process_id)
                   
                #     try:
                #         conn.execute(text(meas_sys_config_postload_report_query5),process_id=process_id)
                #     except:
                #         pass
                #     try:
                #         conn.execute(text(meas_sys_config_postload_report_query6),process_id=process_id)
                #     except:
                #         pass
                #     try:
                #         conn.execute(text(meas_sys_config_postload_report_query7),process_id=process_id)
                #     except:
                #         pass
                #     try:
                #         conn.execute(text(meas_sys_config_postload_report_query8),process_id=process_id)
                #     except:
                #         pass
            # else:
            #     return {"message":"invalid file"}    

        return "DB updated successfully",200

    except Exception as e:
        print(e)
        return {"message":"Exception occured!"}
    
    # finally:
    #     temp.close()
    #     if os.path.exists(local_file_name):
    #         os.remove(local_file_name)
    #     if os.path.exists(filename):
    #         os.remove(filename)
    #     if os.path.exists(filename2):
    #         os.remove(filename2)
    #     if os.path.exists(dir_name):
    #         shutil.rmtree(dir_name)


###########################################
##
## DB WINDOSCOPE DOWNLOAD RESULTS FUNCTION
##
###########################################


def db_windoscope_download_reslts(process_id):

    # global variable for this route
    newtable_session = None
    file_name = None
    time_stamp = None
    windoscope_download = None

    # get windex_graph from recent file
    with db.connect() as conn:
        result = conn.execute(text(windexgraph_session_query), process_id=process_id).fetchone()
        conn.close()
        if result is None:
            newtable_session = 0
        else:
            for row in result:
                newtable_session = row

    print(newtable_session)

    # filename for download
    with db.connect() as conn:
        names = conn.execute(text(db_windoscope_query), process_id=process_id).fetchall()
        conn.close()

        if(len(names) == 0):
            return {"message": "the given process id does not exists"},404

        if names is None:
            return {"message": "the given process id does not exists"},404
        else:
            for name in names:
                file_name = name[0]
                timestamp = name[1]
                windoscope_download  = name[2]
        
    if windoscope_download  == None or windoscope_download == "NA":
        error_data = {
            "status":"No Data Available",
            "session_status": newtable_session
        }
        return error_data,200
    
    first_time = timestamp
    give_time = first_time

    if len(give_time)>7:
        give_time = int(first_time[:-3])    
    systemTime = datetime.datetime.fromtimestamp(give_time).strftime('%Y-%m-%d')

    if windoscope_download == None:
        error_data = {
            "status":"No Data Available",
            "session_status": newtable_session
        }
        return error_data,200
    
    try:
        systemName = file_name[:file_name.index("xported") + len("xported")]
    except:
        systemName = file_name[:-4]
    print(systemName)

    filename = f"{systemName}-Windoscope-Outputs_{systemTime}"
    filename = re.sub(r"(_|-)+", " ", filename).title().replace(" ", "-")
    filename = f"{filename}.zip"

    data = {
        "status":"Results Ready for Downloading",
        "filename":filename,
        "session_status":newtable_session
    }

    return data,200


#########################################
##
## WINDOSCOPE DOWNLOAD RESULTS FUNCTION
##
#########################################


def windosocpe_download_results(process_id):

    # global variable scope
    windowscope_download_link = None
    file_name = None
    timestamp = None
    windowscope_download = None

    with db.connect() as conn:
        results = conn.execute(text(windoscope_download_results_query), prsID=process_id).fetchone()
        conn.close()

        if results is not None:
            for link in results:
                windowscope_download_link = link
        else:
            return {"message": "The given process id does not exists"},404

    # filename for download
    with db.connect() as conn:
        names = conn.execute(text(select_processed_windoscope_downl_result), process_id=process_id)
        conn.close()

        for name in names:
            file_name = name[0]
            timestamp = name[1]
            windoscope_download  = name[2]
        
    if windoscope_download  == "NA":
        return {"message": "windoscope_download is not present"},404  

    foo = ''.join(file_name.split())
    systemName = foo[:-4]
    
    first_time = timestamp
    give_time = first_time

    if len(give_time)>7:
        give_time = int(first_time[:-3])    
    systemTime = datetime.datetime.fromtimestamp(give_time).strftime('%Y-%m-%d-%H-%M-%S')
    
    if windowscope_download_link == None:
        return {"message": "windoscope download file is not present"},404

    else:
        new_file_download_name = f"{systemName}-Windoscope-{systemTime}-Plots-tables.zip"
        url = s3.generate_presigned_url(
        ClientMethod='get_object', 
        ExpiresIn=300,
        Params={
            'Bucket': environ.get("AWS_S3_BUCKET"), 
            'Key': windowscope_download_link,
            'ResponseContentDisposition': 'attachment;filename={}'.format(new_file_download_name),
            'ResponseContentType': 'application/zip',

            }
        )

        short = pyshorteners.Shortener()
        download_url = short.tinyurl.short(url)

        return download_url,200


################################
##
## MEASURMENT DETAILS FUNCTION
##
###############################


def measurment_details(process_id):

    try:

        # global variable
        feather_filename = None
        results = None
        temp = tempfile.NamedTemporaryFile()

        if process_id is None:
            return {'status':200,'message':"Invalid URl"}

        with db.connect() as conn:
            result = conn.execute(text(measurement_details_query),process_id=process_id).fetchone()
            if result is None:
                return {"message": "invalid process id"}, 200
            results = result[0]

        if results is None:
            return {"message": "In Processing"}, 200
        measurement_details_ref_file = results.replace(f"https://{environ.get('AWS_S3_BUCKET')}.s3.amazonaws.com/", '')
        s3.download_file(environ.get("AWS_S3_BUCKET"), measurement_details_ref_file, temp.name)

        read_result =feather.read_feather(temp.name)
    
    except Exception as e:
        print(e)
        return {'message':"An Exception Occured"},200
    
    finally:
        temp.close()

    reading_result = read_result.to_json(orient="records")
    json_result = json.loads(reading_result)

    return json_result, 200


##########################
##
## SHOW SYSTEMS FUNCTION
##
##########################


def show_systems(anlysID, email):

    # global variable
    timestamp =None 
    lidars = None
    analysis = []

    try:
        with db.connect() as conn:
            resultN = conn.execute(text(show_system_analysis_id_query), anlysID=anlysID).fetchone()[0]
            result = conn.execute(text(show_system_lidars_query), anlysID=anlysID).fetchall()
            result1 = conn.execute(text(show_system_masts_query), anlysID=anlysID).fetchall()
            result2 = conn.execute(text(show_system_analysis_query), anlysID=anlysID).fetchall()
            result3 = conn.execute(text(select_analysis_shared_status_query), anlysID=anlysID).fetchone()          
            conn.close()

            lidars = [dict(row) for row in result]
            masts = [dict(row) for row in result1]
            analysis = [dict(row) for row in result2]
            shared_status = result3[0]
            userid = result3[1]
            timestamp = resultN

    except Exception as e:
            resultN = None 
            timestamp =None 
            lidars = None
            masts = None
    
    if resultN is None:
        return {"message": "the given analysis id does not exist"}

    with db.connect() as conn:
        username = conn.execute(text(user_name_from_userid), user_id=userid).fetchone()
    username = username[0]

    if email==username:
        shared_status = "active"

    data = {
        "lidars": lidars,
        "masts": masts,
        "timestamp": timestamp,
        "analysis" : analysis,
        "shared_status": shared_status
    }

    return data,200


#########################################
##
## RECENT WINDEXGRAPH FILE FUNCTION
##
#########################################


def RecentWindexgraphFile(user, timestamp, process_id):
    
    with db.connect() as conn:
        is_user = conn.execute(text(recent_system_name_query), user=user).fetchone()
        if is_user is None:
            conn.execute(text(insert_recent_system_query_windexgraph),user=user, timestamp=timestamp, process_id=process_id)
            conn.close()
        else:
            conn.execute(text(update_recent_system_query_windexgraph), user=user, timestamp=timestamp, process_id=process_id)
            conn.close()

    return "DB updated successfully", 200


########################
##
## RECENTFILE FUNCTION
##
########################


def RecentFile(user, timestamp, process_id):

    with db.connect() as conn:
        is_user = conn.execute(text(recent_system_name_query), user=user).fetchone()
        if is_user is None:
            conn.execute(text(insert_recent_system_query),user=user, timestamp=timestamp, process_id=process_id)
            conn.close()
        else:
            conn.execute(text(update_recent_system_query), timestamp=timestamp, process_id=process_id, user=user)
            conn.close()

    return "DB updated successfully",200




###################################
##
## FINAL DOWNLOAD STATUS FUNCTION
##
###################################


def final_download_status(email, process_id):

    print(process_id)
    shear_report_status = None
    ltt_report_status = None
    final_report_status = None
    message = None
    message2 = None
    
    with db.connect() as conn:
        data = conn.execute(text(final_download_status_query), process_id=process_id).fetchone()
        data1 = conn.execute(text(final_download_status_query1), process_id=process_id).fetchone()
        data2 = conn.execute(text(final_download_status_query2), process_id=process_id).fetchone()
           
    if data is None and data1 is None and data2 is None:
        return {"message":"invalid process id"}
    
    shear_report_status = data1[0]
    ltt_report_status = data1[1]
    final_report_status = data1[2]
   
    if final_report_status == 'IDLE':
        message = "Request for Final report is now ready"

    else:
        message = "Request for Final report has already been initiated"    

    
    if data2 is None or data2[0] is None:
        message2 = "No Backup files recorded"

    else:
        message2 = "Backup available"    

    for i in data:
        print(i)

        if i == "NA" or i == None or i == "":
            return {"message":"In processing",
            "Final Report Cron Status":message,
            "Final Report s3 Status":message2,},200
    
    later_part = data[1].split("/")
    later_part = later_part[-1]
    
    if bool(list(s3R.Bucket(environ.get("AWS_S3_BUCKET")).objects.filter(Prefix=str(data[1]).replace(later_part, "shear_ts_master_analysis.rds")))):
        return {"message":"Ready for computations",
            "Final Report Cron Status":message,
            "Final Report s3 Status":message2},200
    
    else:
        return {"message":"In processing",
            "Final Report Cron Status":message,
            "Final Report s3 Status":message2},200


##################################
##
## SUMMARY EXCEL REPORT FUNCTION
##
##################################
def check_files_for_summary_excel_report(prsid):
    with db.connect() as conn:
        dhata = conn.execute(text(summary_excel_report_query11), process_id=prsid).fetchone()   
    
    title, windoscope_download, shear_download, ltt_download = dhata
    unavail_files = []
    if windoscope_download == "NA" or windoscope_download == "NULL" or windoscope_download == None:
        unavail_files.append("windoscope_download")
    if shear_download == "NA" or shear_download == "NULL" or shear_download == None:
        unavail_files.append("shear_download")
    if ltt_download == "NA" or ltt_download == "NULL" or ltt_download == None:
        unavail_files.append("ltt_download")

    unavail_files = set(unavail_files)

    required = "NaN"
    suggestion = "NaN"
    if unavail_files == {"ltt_download"}:
        required = "Download results from LTT"
        suggestion = "Please go to LTT Application and Click 'Update to WV'"

    if unavail_files == {"shear_download"}:
        required = "Download results from Shear"
        suggestion = "Please go to Shear Application and Click 'Update to WV'"

    if unavail_files == {"windoscope_download"}:
        required = "Download results from Windoscope"
        suggestion = "Please contact developer"   

    if unavail_files == {"shear_download", "windoscope_download"}:
        required = "Download results from Shear & Windoscope"
        suggestion = "Please go to Shear Application and Click 'Update to WV', Please contact developer"  
    
    if unavail_files == {"ltt_download","windoscope_download"}:
        required = "Download results from Ltt and Windoscope"
        suggestion = "Please go to Ltt Application and Click 'Update to WV', Please contact developer"  

    if unavail_files == {"ltt_download","shear_download"}:    
        required = "Download results from Ltt and Shear"
        suggestion = "Please go to Ltt & Shear Application and Click 'Update to WV'"  

    if unavail_files == {"ltt_download","shear_download","windoscope_download"}:    
        required = "Download results from Ltt, Shear and Windoscope"
        suggestion = "Please go to Ltt & Shear Application and Click 'Update to WV', Please contact developer"     

    return {title:{"required":required, "suggestions":suggestion}}

    


def summary_excel_report(email, timestamp, anlysID):

    excess_return = []
 
    random_number = random.randint(100,10000)

    with db.connect() as conn:
        conn.execute(text(summary_excel_report_query), analysis_id=anlysID)

    with db.connect() as conn:
        excel_summary_download = conn.execute(text(summary_excel_report_query2), analysis_id=anlysID).fetchone()
    
    if excel_summary_download is None:
    
        with db.connect() as conn:
            conn.execute(text(summary_excel_report_query3), analysis_id=anlysID, username=email, tsp=timestamp)
            report_ID = conn.execute(text(summary_excel_report_query5), analysisid=anlysID).fetchone()[0]
            prsids = conn.execute(text(summary_excel_report_query6), analysis_id=anlysID).fetchall()
        
        prsids = [int(i[0]) for i in prsids]    
        print(prsids)    

        for i in range(0,len(prsids)):
            excess_return.append(check_files_for_summary_excel_report(prsids[i]))
            with db.connect() as conn:
                check = conn.execute(text(summary_excel_report_query8), process_id=prsids[i]).fetchone()
            print(check)
        
            if check is None:
                with db.connect() as conn:
                    conn.execute(text(summary_excel_report_query9), process_id=prsids[i], report_id=report_ID)
        
            else:
                with db.connect() as conn:
                    conn.execute(text(summary_excel_report_query7), report_id=report_ID, process_id=prsids[i])
        
        return {"message":"request has been initiated"},200
    
    elif excel_summary_download[0] is None:
    
        with db.connect() as conn:
            conn.execute(text(summary_excel_report_query4), username=email, tsp=timestamp, analysis_id=anlysID)
            report_ID = conn.execute(text(summary_excel_report_query5), analysisid=anlysID).fetchone()[0]
            prsids = conn.execute(text(summary_excel_report_query6), analysis_id=anlysID).fetchall()
        
        prsids = [int(i[0]) for i in prsids]   
        print(prsids)  

        for i in range(0,len(prsids)):
            excess_return.append(check_files_for_summary_excel_report(prsids[i]))
            with db.connect() as conn:
                check = conn.execute(text(summary_excel_report_query8), process_id=prsids[i]).fetchone()
            print(check)
    
            if check is None:
                with db.connect() as conn:
                    conn.execute(text(summary_excel_report_query9), process_id=prsids[i], report_id=report_ID)
    
            else:
                with db.connect() as conn:
                    conn.execute(text(summary_excel_report_query7), report_id=report_ID, process_id=prsids[i])
        
        return {"message":"request has been initiated"},200

    else:
    
        try:
            with db.connect() as conn:
                conn.execute(text(summary_excel_report_query4), username=email, tsp=timestamp, analysis_id=anlysID)
        
        except Exception as e:
            print(e)
        
        with db.connect() as conn:
            prsids = conn.execute(text(summary_excel_report_query6), analysis_id=anlysID).fetchall()
        
        prsids = [int(i[0]) for i in prsids]    
        print(prsids)    

        
        for i in range(0,len(prsids)):
            excess_return.append(check_files_for_summary_excel_report(prsids[i]))

        excel_summary_download = excel_summary_download[0]


        #====================================== Excel Summary Naming Convention ======================================#


        with db.connect() as conn:
            file_title = conn.execute(text(summary_excel_report_query10), username=email, tsp=timestamp, analysis_id=anlysID).fetchone()[0]
        
        first_time = timestamp
        give_time = first_time

        if len(give_time)>7:
            give_time = int(first_time[:-3])    
        systemTime = datetime.datetime.fromtimestamp(int(give_time)).strftime('%Y-%m-%d')
        
        filename = f"{file_title}-WindVista-Excel-Summary_{systemTime}"
        filename = f"{filename}.xlsx"


        url = s3.generate_presigned_url(
                ClientMethod='get_object', 
                ExpiresIn=300,
                Params={
                    'Bucket': environ.get("AWS_S3_BUCKET"), 
                    'Key': excel_summary_download,
                    'ResponseContentDisposition': 'attachment;filename={}'.format(filename),
                    'ResponseContentType': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',

                    }
        )
        
        short = pyshorteners.Shortener()
        download_url = short.tinyurl.short(url)
        
        print(excess_return)
        try:
            for i in excess_return:
                if len(list(list(i.values())[0]["required"])) >= 4:
                    return excess_return  
        except:
            return {"url":f"{download_url}"}
        return {"url":f"{download_url}"}


##################################
##
## FINAL REPORT FUNCTION
##
##################################


def final_report(email, timestamp, process_id):

    random_number = random.randint(100,10000)

    with db.connect() as conn:
        conn.execute(text(final_report_query), process_id=process_id)

    with db.connect() as conn:
        final_report_download = conn.execute(text(final_report_query2), process_id=process_id).fetchone()
    
    if final_report_download is None:

        with db.connect() as conn:
            conn.execute(text(final_report_query3), process_id=process_id, username=email, tsp=timestamp)
        return {"message":"request has been initiated"},200

    elif final_report_download[0] is None:
        
        with db.connect() as conn:
            conn.execute(text(final_report_query4), username=email, tsp=timestamp, process_id=process_id)
        return {"message":"request has been initiated"},200

    else:
        
        try:
            with db.connect() as conn:
                conn.execute(text(final_report_query4), username=email, tsp=timestamp, process_id=process_id)
        
        except Exception as e:
            print(e)
        
        final_report_download = final_report_download[0]


        #====================================== Final Report Naming Convention ======================================#

        try:
            with db.connect() as conn:
                File_Name = conn.execute(text(final_report_query5), username=email, tsp=timestamp, process_id=process_id).fetchone()[0]
        except Exception as e:
            print(e)

        first_time = timestamp
        give_time = first_time
        print(File_Name)

        if len(give_time)>7:
            give_time = int(first_time[:-3])    
        systemTime = datetime.datetime.fromtimestamp(int(give_time)).strftime('%Y-%m-%d')
        
        try:
            systemName = File_Name[:File_Name.index("xported") + len("xported")]
        except:
            systemName = File_Name[:-4]
        print(systemName)
    
        systemName = re.sub(r"(_|-)+", " ", systemName).title().replace(" ", "-")
        filename = f"{systemName}-WindVista-Final-Report_{systemTime}"
        filename = f"{filename}.docx"
        
        print(final_report)


        url = s3.generate_presigned_url(
                ClientMethod='get_object', 
                ExpiresIn=300,
                Params={
                    'Bucket': environ.get("AWS_S3_BUCKET"), 
                    'Key': final_report_download,
                    'ResponseContentDisposition': 'attachment;filename={}'.format(filename),
                    'ResponseContentType': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',

                    }
        )
        
        short = pyshorteners.Shortener()
        download_url = short.tinyurl.short(url)

        return {"url":f"{download_url}"},200


##################################
##
## WINDSCOPE REPORT FUNCTION
##
##################################


def windoscopeReport(email, timestamp, process_id):

    print(email)
    with db.connect() as conn:
        conn.execute(text(windowscope_report_query), process_id=process_id)

    with db.connect() as conn:
        windoscope_report_download = conn.execute(text(windoscope_report_query2), process_id=process_id).fetchone()    
    
    if windoscope_report_download is None:

        with db.connect() as conn:
            conn.execute(text(windowscope_report_query3), process_id=process_id, username=email, tsp=timestamp)
        return {"message":"request has been initiated"},200

    elif windoscope_report_download[0] is None:
        
        with db.connect() as conn:
                conn.execute(text(windowscope_report_query4), username=email, tsp=timestamp, process_id=process_id)
        return {"message":"request has been initiated"},200
    
    else:
    
        try:
            with db.connect() as conn:
                conn.execute(text(windowscope_report_query4), username=email, tsp=timestamp, process_id=process_id)
    
        except Exception as e:
            print(e)
    
        windoscope_report_download=windoscope_report_download[0]
    
        print(windoscope_report_download)


        #====================================== WindowScope Report Naming Convention ======================================#


        try:
            with db.connect() as conn:
                File_Name = conn.execute(text(windowscope_report_query5), username=email, tsp=timestamp, process_id=process_id).fetchone()[0]
        except Exception as e:
            print(e)

        first_time = timestamp
        give_time = first_time
        print(File_Name)

        if len(give_time)>7:
            give_time = int(first_time[:-3])    
        systemTime = datetime.datetime.fromtimestamp(int(give_time)).strftime('%Y-%m-%d')
        
        try:
            systemName = File_Name[:File_Name.index("xported") + len("xported")]
        except:
            systemName = File_Name[:-4]
        print(systemName)
    
        systemName = re.sub(r"(_|-)+", " ", systemName).title().replace(" ", "-")
        filename = f"{systemName}-WindVista-Windoscope-Report_{systemTime}"
        filename = f"{filename}.docx"
    
    
        url = s3.generate_presigned_url(
                ClientMethod='get_object', 
                ExpiresIn=300,
                Params={
                    'Bucket': environ.get("AWS_S3_BUCKET"), 
                    'Key': windoscope_report_download,
                    'ResponseContentDisposition': 'attachment;filename={}'.format(filename),
                    'ResponseContentType': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',

                    }
        )
        
        short = pyshorteners.Shortener()
        download_url = short.tinyurl.short(url)

        return {"url":f"{download_url}"},200


##################################
##
## REQUEST SHEAR REPORT FUNCTION
##
##################################


def request_shear_report(process_id, requested_user, requested_time):

    with db.connect() as conn:
        conn.execute(text(shear_report_status_query), process_id=process_id)

    with db.connect() as conn:
        shear_report_download = conn.execute(text(shear_report_status_query2), process_id=process_id).fetchone()
        
    if shear_report_download is None:

        with db.connect() as conn:
            conn.execute(text(shear_report_status_query3), process_id=process_id, requested_user=requested_user, requested_time=requested_time)
        return {"message":"request has been initiated"},200

    elif shear_report_download[0] is None:
        
        with db.connect() as conn:
                conn.execute(text(shear_report_status_query4), process_id=process_id, username=requested_user, timestamp=requested_time)
        return {"message":"request has been initiated"},200
    
    else:
    
        try:
            with db.connect() as conn:
                conn.execute(text(shear_report_status_query4), process_id=process_id, username=requested_user, timestamp=requested_time)
    
        except Exception as e:
            print(e)
    
        shear_report_download = shear_report_download[0]


        #====================================== Request Shear Report Naming Convention ======================================#


        try:
            with db.connect() as conn:
                File_Name = conn.execute(text(shear_report_query5), username=requested_user, tsp=requested_time, process_id=process_id).fetchone()[0]
        except Exception as e:
            print(e)

        first_time = requested_time
        give_time = first_time
        print(File_Name)

        if len(give_time)>7:
            give_time = int(first_time[:-3])    
        systemTime = datetime.datetime.fromtimestamp(int(give_time)).strftime('%Y-%m-%d')
        
        try:
            systemName = File_Name[:File_Name.index("xported") + len("xported")]
        except:
            systemName = File_Name[:-4]
        print(systemName)
    
        systemName = re.sub(r"(_|-)+", " ", systemName).title().replace(" ", "-")
        filename = f"{systemName}-WindVista-Shear-Report_{systemTime}"
        filename = f"{filename}.docx"        

    
        url = s3.generate_presigned_url(
                ClientMethod='get_object', 
                ExpiresIn=300,
                Params=
                {
                    'Bucket': environ.get("AWS_S3_BUCKET"), 
                    'Key': shear_report_download,
                    'ResponseContentDisposition': 'attachment;filename={}'.format(filename),
                    'ResponseContentType': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',

                }
        )

        short = pyshorteners.Shortener()
        download_url = short.tinyurl.short(url)

        return {"url":f"{download_url}"},200


##################################
##
## LTT REPORT FUNCTION
##
##################################


def ltt_report(email, process_id, timestamp):
                
    random_number = random.randint(100,10000)

    with db.connect() as conn:
        conn.execute(text(ltt_report_status_query), process_id=process_id)

    with db.connect() as conn:
        ltt_report_download = conn.execute(text(ltt_report_status_query2), process_id=process_id).fetchone()
    
    if ltt_report_download is None:
        with db.connect() as conn:
            conn.execute(text(ltt_report_status_query3), process_id=process_id, username=email, tsp=timestamp)
        return {"message":"request has been initiated"},200

    elif ltt_report_download[0] is None:
        with db.connect() as conn:
            conn.execute(text(ltt_report_status_query4), username=email, tsp=timestamp, process_id=process_id)
        return {"message":"request has been initiated"},200

    else:

        try:
            with db.connect() as conn:
                conn.execute(text(ltt_report_status_query4), username=email, tsp=timestamp, process_id=process_id)
        
        except Exception as e:
            print(e)
        
        ltt_report_download = ltt_report_download[0]

        #====================================== Ltt Report Naming Convention ======================================#

        try:
            with db.connect() as conn:
                File_Name = conn.execute(text(ltt_report_status_query5), username=email, tsp=timestamp, process_id=process_id).fetchone()[0]
        except Exception as e:
            print(e)

        first_time = timestamp
        give_time = first_time
        print(File_Name)

        if len(give_time)>7:
            give_time = int(first_time[:-3])    
        systemTime = datetime.datetime.fromtimestamp(int(give_time)).strftime('%Y-%m-%d')
        
        try:
            systemName = File_Name[:File_Name.index("xported") + len("xported")]
        except:
            systemName = File_Name[:-4]
        print(systemName)
    
        systemName = re.sub(r"(_|-)+", " ", systemName).title().replace(" ", "-")
        filename = f"{systemName}-WindVista-LTT-Report_{systemTime}"
        filename = f"{filename}.docx"


        url = s3.generate_presigned_url(
                ClientMethod='get_object', 
                ExpiresIn=300,
                Params={
                    'Bucket': environ.get("AWS_S3_BUCKET"), 
                    'Key': ltt_report_download,
                    'ResponseContentDisposition': 'attachment;filename={}'.format(filename),
                    'ResponseContentType': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',

                    }
        )
        
        short = pyshorteners.Shortener()
        download_url = short.tinyurl.short(url)

        return {"url":f"{download_url}"},200


##################################
##
## ANALYSIS REPORT FUNCTION
##
##################################


def analysis_report(email, timestamp, analysis_id):

    random_number = random.randint(100,10000)

    with db.connect() as conn:
        conn.execute(text(analysis_report_query), analysis_id=analysis_id)

    with db.connect() as conn:
        analysis_report_download = conn.execute(text(analysis_report_query2), analysis_id=analysis_id).fetchone()
    
    if analysis_report_download is None:
        with db.connect() as conn:
            conn.execute(text(analysis_report_query3), analysis_id=analysis_id, username=email, tsp=timestamp)
        return {"message":"request has been initiated"},200

    elif analysis_report_download[0] is None:
        with db.connect() as conn:
            conn.execute(text(analysis_report_query4), username=email, tsp=timestamp, analysis_id=analysis_id)
        return {"message":"request has been initiated"},200

    else:

        try:
            with db.connect() as conn:
                conn.execute(text(analysis_report_query4), username=email, tsp=timestamp, analysis_id=analysis_id)
        
        except Exception as e:
            print(e)
        
        analysis_report_download = analysis_report_download[0]


        #====================================== Analysis Report Naming Convention ======================================#


        with db.connect() as conn:
            file_title = conn.execute(text(analysis_report_query5), username=email, tsp=timestamp, analysis_id=analysis_id).fetchone()[0]
        
        first_time = timestamp
        give_time = first_time

        if len(give_time)>7:
            give_time = int(first_time[:-3])    
        systemTime = datetime.datetime.fromtimestamp(int(give_time)).strftime('%Y-%m-%d')
        
        filename = f"{file_title}-WindVista-Collated-Report_{systemTime}"
        filename = f"{filename}.docx"


        url = s3.generate_presigned_url(
                ClientMethod='get_object', 
                ExpiresIn=300,
                Params={
                    'Bucket': environ.get("AWS_S3_BUCKET"), 
                    'Key': analysis_report_download,
                    'ResponseContentDisposition': 'attachment;filename={}'.format(filename),
                    'ResponseContentType': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',

                    }
        )
        
        short = pyshorteners.Shortener()
        download_url = short.tinyurl.short(url)

        return {"url":f"{download_url}"},200


####################################
##
## DB LTT DOWNLOAD RESULTS FUNCTION
##
####################################


def db_ltt_download_results(process_id):
   
    with db.connect() as conn:
        status = conn.execute(text(db_ltt_download_results_query), process_id=process_id).fetchone()[0]
        
    if status == "IDLE":
        return "Request for LTT report is now ready",200
   
    return "Request for LTT report has already been initiated",200


###########################################
##
## LTT REPORT DOWNLOAD S3 STATUS FUNCTION
##
###########################################


def ltt_report_download_s3_status(process_id):
    
    try:
        with db.connect() as conn:
            ltt_report_download = conn.execute(text(ltt_report_download_s3_status_query), process_id=process_id).fetchone()[0]
    except:
        return "No Backup files recorded",200
    
    if ltt_report_download is None:
        return "No Backup files recorded",200

    if ltt_report_download[0] is None:
        return "No Backup files recorded",200

    return "Backup available",200    


####################################
##
## SHOW SYSTEM CRON STATUS FUNCTION
##
####################################


def show_system_cron_status(analid):

    with db.connect() as conn:
        status = conn.execute(text(db_analysis_download_results_query), analysis_id=analid).fetchone()[0]
        
    if status == "IDLE":
        return "Request for system report is now ready",200
   
    return "Request for system report has already been initiated",200


########################################################
##
## ANALYSIS REPORT DOWNLOAD S3 STATUS STATUS FUNCTION
##
########################################################


def analysis_report_download_s3_status(analid):
    
    try:
        with db.connect() as conn:
            analysis_report_download = conn.execute(text(analysis_report_download_s3_status_query), analysis_id=analid).fetchone()[0]
    except:
        return "No Backup files recorded",200
    
    if analysis_report_download is None:
        return "No Backup files recorded",200

    if analysis_report_download[0] is None:
        return "No Backup files recorded",200

    return "Backup available",200        


######################################
##
## DB SHEAR DOWNLOAD RESULTS FUNCTION
##
######################################


def db_shear_download_results(process_id):

    with db.connect() as conn:
        status = conn.execute(text(db_shear_download_results_query), process_id=process_id).fetchone()[0]

    if status == "IDLE":
        return "Request for Shear report is now ready",200

    return "Request for Shear report has already been initiated",200


#############################################
##
## SHEAR REPORT DOWNLOAD S3 STATUS FUNCTION
##
#############################################


def shear_report_download_s3_status(process_id):

    try:
        with db.connect() as conn:
            shear_report_download = conn.execute(text(shear_report_download_s3_status_query), process_id=process_id).fetchone()[0]
    
    except:
        return "No Backup files recorded",200
    
    if shear_report_download is None:
        return "No Backup files recorded",200
    
    if shear_report_download[0] is None:
        return "No Backup files recorded",200

    return "Backup available",200


####################################
##
## DB WINDOSCOPE RESULTS FUNCTION
##
####################################


def db_windoscope_results(process_id):

    with db.connect() as conn:
        status = conn.execute(text(db_windoscope_results_query), process_id=process_id).fetchone()[0]

    if status == "IDLE":
        return "Request for Windoscope report is now ready",200

    return "Request for Windoscope report has already been initiated",200


##################################################
##
## WINDOSCOPE REPORT DOWNLOAD S3 STATUS FUNCTION
##
##################################################


def windoscope_report_download_s3_status(process_id):

    try:
        with db.connect() as conn:
            windoscope_report_download = conn.execute(text(windoscope_report_download_s3_status_query), process_id=process_id).fetchone()[0]
    except:
        return "No Backup files recorded",200
    
    if windoscope_report_download is None:
        return "No Backup files recorded",200

    if windoscope_report_download[0] is None:
        return "No Backup files recorded",200

    return "Backup available",200


######################################
##
## EXCEL SUMMARY CRON STATUS FUNCTION
##
######################################


def Excel_summary_Cron_status(analysid):

    with db.connect() as conn:
        data = conn.execute(text(Excel_summary_Cron_status_query), analysis_id=analysid).fetchall()
        excel_summary_status = conn.execute(text(Excel_summary_Cron_status_query2), analysis_id=analysid).fetchone()[0]
        windscope_download_status = conn.execute(text(Excel_summary_Cron_status_query3),analysis_id=analysid).fetchall()

    flag = False

    '''
    for i in data:
        for j in i:
            if j != "COMPLETED":
                flag = True
                break
    '''
    
    if excel_summary_status != 'IDLE':
        flag = True

    if windscope_download_status != None:
        windscope_download_status = [i[0] for i in windscope_download_status]
        #print(windscope_download_status) 
        if 'NA' in windscope_download_status or 'NULL' in windscope_download_status or None in windscope_download_status or '' in windscope_download_status:
            return "Request for Excel Summary has already been initiated",200

    if flag is False:
        return "Request for Excel Summary is now ready",200
    return "Request for Excel Summary has already been initiated",200


####################################
##
## EXCEL SUMMARY S3 STATUS FUNCTION
##
####################################


def Excel_summary_S3_status(analysid):
    
    try:
        with db.connect() as conn:
            excel_summary_download = conn.execute(text(Excel_summary_S3_status_query), analysis_id=analysid).fetchone()[0]
        print(excel_summary_download)
    except:
        return "No Backup files recorded",200

    if excel_summary_download is None:
        return "No Backup files recorded",200

    if excel_summary_download[0] is None:
        return "No Backup files recorded",200

    return "Backup available",200





#################################
##
## FINAL DOWNLOAD FILE UTILITY FUNCTION
##
#################################


# Utility function to final download API #
def download_final_files(**args):

    if "folder_tag" in args:
        
        # Folder 1 Files #
        if args['folder_tag'] == "Folder 1":

            path = os.path.join(args['main_folder'], args['folder_name'], args['input_text_folder_name'], args['input_text_file_name'])
            # Input File #
            s3.download_file('windvista-dev', args['input_text_file'], path)

            #climate file #
            if args['climate_data_File'] != "NA" and args['climate_data_File'] != "":
                path = os.path.join(args['main_folder'], args['folder_name'], args['climate_file_folder_name'])
                s3.download_file('windvista-dev', args['climate_data_File'], args['climate_data_file_name'])
                with zipfile.ZipFile(args['climate_data_file_name'], 'r') as zip_ref:
                    zip_ref.extractall(path)
            
            if os.path.exists(args['climate_data_file_name']):
                os.remove(args['climate_data_file_name'])

        # Folder 2 Files #
        elif args['folder_tag'] == "Folder 2":

            random_number = random.randint(100,10000)
            temp_foldername2 = f"{random_number}_windoscope"
            os.mkdir(temp_foldername2)
            path = temp_foldername2
            s3.download_file('windvista-dev', args['wind_measurement_file'], args['wind_measurement_file_name'])
            shutil.unpack_archive(args['wind_measurement_file_name'], path, "zip")
            os.rename(temp_foldername2, args['folder_name'])
            shutil.move(args['folder_name'], args['main_folder'])

            if os.path.exists(args['wind_measurement_file_name']):    
                os.remove(args['wind_measurement_file_name'])

        # Folder 3 / 4 Files #
        elif args['folder_tag'] == "Folder 3" or args['folder_tag'] == 4:

            if args['file_txt_key'] != "NA" and args['file_txt_key'] != "":  
                path = os.path.join(args['main_folder'], args['folder_name'])
                s3.download_file('windvista-dev', args['file_txt_key'], args['downloaded_file_name'])
                with zipfile.ZipFile(args['downloaded_file_name'], 'r') as zip_ref:
                    zip_ref.extractall(path)
            
            if os.path.exists(args['downloaded_file_name']):
                os.remove(args['downloaded_file_name'])






##############################
##
## SHOW PROJECT UTILITY FUNCTION
##
##############################


# Function to find the shared users of a project #
def get_projects_shared_users(data):

    for i in range(len(data)):
        owner_id = data[i]['userID']
        with db.connect() as conn:
            owner = conn.execute(text(user_name_from_userid),user_id=owner_id).fetchone()[0]

        data[i]['owner'] = owner
            
        temp_list = []
        if data[i]["shared"] == "shared":
            shared_user = []
            shared_username = []
            shared_user.append(data[i]["shared_user"])
            shared_user = shared_user[0]
            shared_user = shared_user.strip('[').strip(']')
            shared_user = shared_user.split(',')
            print(f"shared user -  {shared_user}")

            temp_shared_user = []
            for j in shared_user:
                try:
                    temp_shared_user.append(int(j))
                except:
                    pass

            shared_user = temp_shared_user

            for k in range(len(shared_user)):
                userid = shared_user[k]
                with db.connect() as conn:
                    user = conn.execute(text(user_name_from_userid),user_id=userid).fetchone()[0]

                shared_username.append(user)

            data[i]['shared_to'] = shared_username
    return data