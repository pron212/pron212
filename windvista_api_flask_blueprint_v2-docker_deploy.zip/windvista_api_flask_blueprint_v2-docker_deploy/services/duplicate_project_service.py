from sqlalchemy import text
from db.queries import *
from db.connect import init_connection_engine
import boto3
from os import environ
import re

db = init_connection_engine()

s3 = boto3.client(
    's3', 
    aws_access_key_id=environ.get("AWS_ACCESS_KEY_ID") , 
    aws_secret_access_key=environ.get("AWS_SECRET_ACCESS_KEY"), 
    region_name="us-east-1"
    )

s3R = boto3.resource(
    's3', 
    aws_access_key_id=environ.get("AWS_ACCESS_KEY_ID") , 
    aws_secret_access_key=environ.get("AWS_SECRET_ACCESS_KEY"), 
    region_name="us-east-1"
    )

def duplicate_analysis_for_DuplicatingAProject(anlysID, timestamp, userid, pid, username):
    # global variable for analysis
    ltt_ref_filename_feather = None
    feather_process = None
    new_process_id = None
    prsid = None
    analysisid = None
    projectid = None
    title = None
    description = None
    userID = None
    masts = None
    lidars = None
    published = None
    in_progress = None
    # global variables for  ltt_reference
    ltt_username = None
    ltt_ref_uploaded_key = None
    ltt_ref_filename = None
    final_rds_new = None
    measure_rds_new = None
    shear_rds_new = None
    comb_shear_new = None
    ltt_depth_analysis_new = None
    windoscope_download_new = None
    shear_download_new = None
    ltt_download_new = None
    winddata_new = None
    tempraw_new = None
    cbox_new = None
    shear_feather_new = None
    measure_feather_new = None
    final_feather_new = None
    txt_key_new = None
    txt_key_url = None

    # global variable for processed_systems_unreg
    processed_systems_timpestamp = None
    processed_systems_systemType = None
    processed_systems_title = None
    processed_systems_sourcefrom = None
    processed_systems_txtKey = None
    processed_systems_txturl = None
    processed_systems_filename = None
    processed_systems_process_status = None
    processed_systems_final_feather = None
    processed_systems_user = None
    processed_systems_measure_feather = None
    processed_systems_shear_feather = None
    processed_systems_comb_shear = None
    processed_systems_Target_height = None
    processed_systems_Anemo_name = None
    processed_systems_ltt_process_status = None
    processed_systems_ltt_imp_adj = None
    processed_systems_ltt_depth_analysis = None
    processed_systems_windoscope_download = None
    processed_systems_shear_download = None
    processed_systems_ltt_download = None
    processed_systems_windoscope_process = None
    processed_systems_winddata = None
    processed_systems_tempraw = None
    processed_systems_tempraw_status = None
    processed_systems_cbox_data = None
    feather_conversion_shear_status = None
    shear_feather = None
    Direction_name = None
    measure_feather = None
    final_feather = None
    status = None
    # checking if analysis exists or not
    with db.connect() as conn:
        analysis = conn.execute(text(select_analys_query), anlysID=anlysID).fetchall()
        conn.close()
        if len(analysis) == 0:
            return {"message": "analysis does not exists"},200
        else:
            for row in analysis:
                title = row[2]
                description = row[3]
                userID = userid
                masts = row[5]
                lidars = row[6]
                user = title
                projectid = pid
                status = row[10]

    # getting maximum analysis id
    with db.connect() as conn:
        newid = conn.execute(select_max_analysis_id_query).fetchone()
        conn.close()
        for row in newid:
            analysisid = row
    # incrementing that analysis by one 
    new_analysis_id = analysisid + 1
        
    with db.connect() as conn:
        conn.execute(text(duplicate_analysis_insert_query), new_analysis_id=new_analysis_id, projectid=projectid, title=user, description=description, userID=userID, masts=masts, lidars=lidars, timestamp=timestamp, anlysID=anlysID,status = status)
        conn.close()
    
    # getting all aws ltt ref files from analysis id
    with db.connect() as conn:
        ltt_analysis = conn.execute(text(select_ltt_ref_file_query), anlysID=anlysID).fetchall()
        conn.close()
        if ltt_analysis is not None:
            if len(ltt_analysis) == 0:
                return {"analysis_id": new_analysis_id, "message": "ltt analysis does not exists"},200
            else:
                for row in ltt_analysis:
                    ltt_username = username
                    ltt_ref_uploaded_key = row[4]
                    ltt_ref_filename = row[5]
                    ltt_ref_filename_feather = row[6]
                    feather_process = row[7]
        else:
            return {"analysis_id": new_analysis_id, "message": "ltt analysis does not exists"},200
    
    
    if ltt_ref_uploaded_key in ["NA", None]:
        ltt_ref_uploaded_key_new = ltt_ref_uploaded_key
    else:
        ltt_ref_uploaded_key_new = f"{username}/lttref/{new_analysis_id}/ltt_ref_uploaded.zip"
    
        # ltt_ref_s3 upload
        copy_source = {'Bucket': 'windvista-dev', 'Key': str(ltt_ref_uploaded_key)}
        s3.copy_object(CopySource = copy_source, Bucket = 'windvista-dev', Key = str(ltt_ref_uploaded_key_new))
    

    if ltt_ref_filename in ['NA', None]:

        ltt_ref_filename_new = ltt_ref_filename
    else:
        ltt_ref_filename_new = f"{username}/lttref/{new_analysis_id}/ltt_ref_uploaded.rds"
        # ltt_ref_s3 upload
        copy_source = {'Bucket': 'windvista-dev', 'Key': str(ltt_ref_filename)}
        s3.copy_object(CopySource = copy_source, Bucket = 'windvista-dev', Key = str(ltt_ref_filename_new))
    

    if ltt_ref_filename_feather in ['NA', None]:
        ltt_ref_filename_feather_new = ltt_ref_filename_feather
    else:
        ltt_ref_filename_feather_new = f"{username}/lttref/{new_analysis_id}/ltt_ref_uploaded.feather"
        # ltt_ref_s3 upload
        copy_source = {'Bucket': 'windvista-dev', 'Key': str(ltt_ref_filename_feather)}
        s3.copy_object(CopySource = copy_source, Bucket = 'windvista-dev', Key = str(ltt_ref_filename_feather_new))
    
    
    # insert all the reuploaded file
    with db.connect() as conn:
        conn.execute(text(insert_ltt_ref_files_query), new_analysis_id=new_analysis_id, ltt_username=ltt_username, timestamp=timestamp, ltt_ref_uploaded_key_new=ltt_ref_uploaded_key_new, ltt_ref_filename_new=ltt_ref_filename_new, ltt_ref_filename_feather_new=ltt_ref_filename_feather_new, feather_process=feather_process)
        conn.close()
    

    #-------------------------------------------------------
    # new_processed ids
    with db.connect() as conn:
        result = conn.execute(select_max_prsid_query).fetchone()[0]
        prsid = result
    new_process_id = prsid + 1
    with db.connect() as conn:
        processed_systems_unreg = conn.execute(text(select_proc_sys_unreg_query), anlysID=anlysID).fetchall()
        conn.close()
        if processed_systems_unreg is not None:
            if len(processed_systems_unreg) == 0:
                return {"analysis_id": new_analysis_id, "message": "processed_systems_unreg analysis does not exists"},200
            else:
                for row in processed_systems_unreg:
                    processed_systems_timpestamp = row[2]
                    processed_systems_systemType = row[3]
                    processed_systems_title = row[4]
                    processed_systems_sourcefrom = row[5]
                    processed_systems_txtKey = row[6]
                    processed_systems_txturl = row[7]
                    processed_systems_filename = row[8]
                    processed_systems_process_status = row[9]
                    processed_systems_user = username
                    processed_systems_comb_shear = row[14]
                    processed_systems_Target_height = row[15]
                    processed_systems_Anemo_name = row[16]
                    processed_systems_ltt_process_status = row[17]
                    processed_systems_ltt_imp_adj = row[18]
                    processed_systems_ltt_depth_analysis = row[19]
                    processed_systems_windoscope_download = row[20]
                    processed_systems_shear_download = row[21]
                    processed_systems_ltt_download = row[22]
                    processed_systems_windoscope_process = row[23]
                    processed_systems_winddata = row[24]
                    processed_systems_tempraw_status = row[25]
                    processed_systems_cbox_data = row[26]
                    shear_feather = row[27]
                    Direction_name = row[28]
                    measure_feather = row[29]
                    final_feather = row[30]
                    if processed_systems_txtKey in ['NA', None]:
                        txt_key_new = processed_systems_txtKey
                    else:
                        txt_key_new = f"{username}/{new_process_id}/raw/raw.txt"
                        print(f" txt_key_new {txt_key_new}")
                        # ltt_ref_s3 upload
                        copy_source = {'Bucket': 'windvista-dev', 'Key': str(processed_systems_txtKey)}
                        s3.copy_object(CopySource = copy_source, Bucket = 'windvista-dev', Key = str(txt_key_new))
                    
                    print(txt_key_new)
                    if processed_systems_txturl in ['NA', None]:
                        txt_key_url = processed_systems_txturl
                    else:
                        new_name = processed_systems_txturl.replace("https://windvista-dev.s3.amazonaws.com/",'')
                        txt_key_url = f"{username}/{new_process_id}/raw/raw.txt"
                        print(f"new txt_key_url {txt_key_url}")
                        print(f"new new_name {new_name}")
                        # txt_key_url= f"https://windvista-dev.s3.amazonaws.com/{abx}"
                        # ltt_ref_s3 upload
                        copy_source = {'Bucket': 'windvista-dev', 'Key': str(new_name)}
                        s3.copy_object(CopySource = copy_source, Bucket = 'windvista-dev', Key = str(txt_key_url))
                    if processed_systems_comb_shear in ["NA", None]:
                        comb_shear_new = processed_systems_comb_shear
                    else:
                        later_part = processed_systems_comb_shear.split("/")
                        later_part = later_part[-1]
                        comb_shear_new = f"{username}/{new_process_id}/shear/combination/{later_part}"
                        print(f" this is comb shear new {comb_shear_new}")
                        # ltt_ref_s3 upload
                        copy_source = {'Bucket': 'windvista-dev', 'Key': str(processed_systems_comb_shear)}
                        s3.copy_object(CopySource = copy_source, Bucket = 'windvista-dev', Key = str(comb_shear_new))
                    if processed_systems_ltt_depth_analysis in ["NA", None]:
                        ltt_depth_analysis_new = processed_systems_ltt_depth_analysis
                    else:
                        print(f" this is processed_systems_ltt_depth_analysis {processed_systems_ltt_depth_analysis}")
                        ltt_depth_analysis_new = f"{username}/{new_process_id}/ltt/ltt_depth_analysis.rds"
                        print(f" this is ltt_depth_analysis_new {ltt_depth_analysis_new}")
                        # ltt_ref_s3 upload
                        copy_source = {'Bucket': 'windvista-dev', 'Key': str(processed_systems_ltt_depth_analysis)}
                        s3.copy_object(CopySource = copy_source, Bucket = 'windvista-dev', Key = str(ltt_depth_analysis_new))
                    
                    if processed_systems_windoscope_download in ["NA", None]:
                        windoscope_download_new = processed_systems_windoscope_download
                    else:
                        windoscope_download_new = f"{username}/{new_process_id}/windoscope/Download.zip"
                        print(f"windoscope_download_new {windoscope_download_new}")
                        # ltt_ref_s3 upload
                        copy_source = {'Bucket': 'windvista-dev', 'Key': str(processed_systems_windoscope_download)}
                        s3.copy_object(CopySource = copy_source, Bucket = 'windvista-dev', Key = str(windoscope_download_new))
                    if processed_systems_shear_download in ["NA", None]:
                        shear_download_new = processed_systems_shear_download
                    else:
                        shear_download_new = f"{username}/{new_process_id}/shear/Plots_Tables.zip"
                        print(f"shear_download_new {shear_download_new}")
                        # ltt_ref_s3 upload
                        copy_source = {'Bucket': 'windvista-dev', 'Key': str(processed_systems_shear_download)}
                        s3.copy_object(CopySource = copy_source, Bucket = 'windvista-dev', Key = str(shear_download_new))
                    if processed_systems_ltt_download in ["NA", None]:
                        ltt_download_new = processed_systems_ltt_download
                    else:
                        ltt_download_new = f"{username}/{new_process_id}/ltt/Plots_Tables.zip"
                        print(f"ltt_download_new {ltt_download_new}")
                        # ltt_ref_s3 upload
                        copy_source = {'Bucket': 'windvista-dev', 'Key': str(processed_systems_ltt_download)}
                        s3.copy_object(CopySource = copy_source, Bucket = 'windvista-dev', Key = str(ltt_download_new))
                    
                    if processed_systems_winddata in ["NA", None]:
                        winddata_new = processed_systems_winddata
                    else:
                        winddata_new = f"{username}/{new_process_id}/raw/winddata.RDS"
                        print(f"winddata_new {winddata_new}")
                        # ltt_ref_s3 upload
                        copy_source = {'Bucket': 'windvista-dev', 'Key': str(processed_systems_winddata)}
                        s3.copy_object(CopySource = copy_source, Bucket = 'windvista-dev', Key = str(winddata_new))
                    
                    if processed_systems_cbox_data in ["NA", None]:
                        cbox_new = processed_systems_cbox_data
                    else:
                        cbox_new = f"{username}/{new_process_id}/shear/result/shear_cbox_analysis.rds"
                        print(f"cbox_new {cbox_new}")
                        # ltt_ref_s3 upload
                        copy_source = {'Bucket': 'windvista-dev', 'Key': str(processed_systems_cbox_data)}
                        s3.copy_object(CopySource = copy_source, Bucket = 'windvista-dev', Key = str(cbox_new))
                        later_part = processed_systems_cbox_data.split("/")
                        later_part = later_part[-1]
                    
                        if bool(list(s3R.Bucket('windvista-dev').objects.filter(Prefix=str(processed_systems_cbox_data).replace(later_part, "shear_ts_master_analysis.rds")))):
                            ts_master_new = f"{username}/{new_process_id}/shear/result/shear_ts_master_analysis.rds"
                            print(f"ts_master_new {ts_master_new}")
                        
                            # ltt_ref_s3 upload
                            print(str(cbox_new).replace("_cbox_", "_ts_master_"))
                            copy_source = {'Bucket': 'windvista-dev', 'Key': str(processed_systems_cbox_data).replace(later_part, "shear_ts_master_analysis.rds")}
                            s3.copy_object(CopySource = copy_source, Bucket = 'windvista-dev', Key = str(ts_master_new))

                        if bool(list(s3R.Bucket('windvista-dev').objects.filter(Prefix=str(processed_systems_cbox_data).replace(later_part, "shear_ts_analysis.rds")))):
                            ts_new = f"{username}/{new_process_id}/shear/result/shear_ts_analysis.rds"
                            print(f"ts_master_new {ts_new}")
                            # ltt_ref_s3 upload
                            copy_source = {'Bucket': 'windvista-dev', 'Key': str(processed_systems_cbox_data).replace(later_part, "shear_ts_analysis.rds")}
                            s3.copy_object(CopySource = copy_source, Bucket = 'windvista-dev', Key = str(ts_new))
                            

                    if shear_feather in ["NA", None]:
                        shear_feather_new = shear_feather
                    else:
                        shear_feather_new = f"{username}/{new_process_id}/shear/result/shear_analysis.feather"
                        print(f"shear_feather_new {shear_feather_new}")
                        # ltt_ref_s3 upload
                        copy_source = {'Bucket': 'windvista-dev', 'Key': str(shear_feather)}
                        s3.copy_object(CopySource = copy_source, Bucket = 'windvista-dev', Key = str(shear_feather_new))
                    
                    if measure_feather in ["NA", None]:
                        measure_feather_new = measure_feather
                    else:
                        measure_feather_new = f"{username}/{new_process_id}/meaurement/demo.feather"
                        measure_feather = measure_feather.replace("https://windvista-dev.s3.amazonaws.com/",'')
                        print(f"measure_feather_new {measure_feather_new}")
                        print(f"measure_feather {measure_feather}")
                        # ltt_ref_s3 upload
                        copy_source = {'Bucket': 'windvista-dev', 'Key': str(measure_feather)}
                        s3.copy_object(CopySource = copy_source, Bucket = 'windvista-dev', Key = str(measure_feather_new))
                    if final_feather in ["NA", None]:
                        final_feather_new = final_feather
                    else:
                        final_feather_new = f"{username}/{new_process_id}/final/final_approach.feather"
                        print(f"final_feather_new {final_feather_new}")
                        # ltt_ref_s3 upload
                        copy_source = {'Bucket': 'windvista-dev', 'Key': str(final_feather)}
                        s3.copy_object(CopySource = copy_source, Bucket = 'windvista-dev', Key = str(final_feather_new))
                    
                    with db.connect() as conn:
                        conn.execute(text(processed_system_unreg),new_analysis_id=new_analysis_id, processed_systems_timpestamp=processed_systems_timpestamp,processed_systems_systemType=processed_systems_systemType, processed_systems_title=processed_systems_title, processed_systems_sourcefrom=processed_systems_sourcefrom, 
                        processed_systems_txtKey=txt_key_new, processed_systems_txturl=txt_key_url, processed_systems_filename=processed_systems_filename, processed_systems_process_status=processed_systems_process_status, processed_systems_user=processed_systems_user, 
                        processed_systems_comb_shear=comb_shear_new, processed_systems_Target_height=processed_systems_Target_height, processed_systems_Anemo_name=processed_systems_Anemo_name, processed_systems_ltt_process_status=processed_systems_ltt_process_status, 
                        processed_systems_ltt_imp_adj=processed_systems_ltt_imp_adj, processed_systems_ltt_depth_analysis=ltt_depth_analysis_new, processed_systems_windoscope_download=windoscope_download_new, processed_systems_shear_download=shear_download_new, processed_systems_ltt_download=ltt_download_new, 
                        processed_systems_windoscope_process=processed_systems_windoscope_process, processed_systems_winddata=winddata_new, processed_systems_tempraw_status=processed_systems_tempraw_status, processed_systems_cbox_data=cbox_new,
                        shear_feather=shear_feather_new,Direction_name=Direction_name,measure_feather=measure_feather_new,final_feather=final_feather_new)
                        conn.close()
                    
                    new_process_id = new_process_id + 1
        else:
            return {"analysis_id": new_analysis_id,"message": "processed_systems_unreg analysis does not exists"},200
    return {"analysis_id": new_analysis_id}, 200