from flask_restful import Resource
from db.queries import *
from services.project_service import user_authentication
from services.analysis_service import *
from routes import *


##################################################
##
## AUTHORIZATION FOR ANALYSIS CLASS FOR GET METHOD
##
##################################################


class Authorization_analysis(Resource):

    def __init__(self, email, project_id):
        self.email = email
        self.project_id = project_id
        
    def Analysis_get(self):
        
        with db.connect() as conn:
            user_id = conn.execute(text(authentication_analysis), project_id=self.project_id).fetchone()
        print(f"user id is {user_id}")
        
        if user_id is None:
            return 404

        UserId = user_id[0]
        
        with db.connect() as conn:
            username = conn.execute(text(user_name_from_userid), user_id=UserId).fetchone()    
        print(username)
        user = username[0]
        print(self.email)

        if user != self.email:
            obj = user_authentication(self.project_id,self.email)
            flag = obj.duplicate_auth()
            print(flag)

            if type(flag) is tuple and flag[1] == 404:
                return 403
            if flag == False:
                return 401


###################################################
##
## AUTHORIZATION FOR ANALYSIS CLASS FOR POST METHOD
##
###################################################


class Authorization_analysis2(Resource):

    def __init__(self, email, anlysID):
        self.email = email
        self.analysisid = anlysID

    def Analysis_post(self):

        with db.connect() as conn:
            user_id = conn.execute(text(authentication_analysis2), analysisid=self.analysisid).fetchone()
            project_id = conn.execute(text(publish_analysis_processid_query), analysisid=self.analysisid).fetchone()
        
        if user_id is None or project_id is None:
            return 200

        UserId = user_id[0]
        project_id = project_id[0]
        print(f"user id is {UserId}")

        with db.connect() as conn:
            username = conn.execute(text(user_name_from_userid), user_id=UserId).fetchone()    
        print(username)
        user = username[0]
        print(self.email)
        
        if user != self.email:
            obj = user_authentication(project_id ,self.email)
            flag = obj.duplicate_auth()
            print(flag)

            if type(flag) is tuple and flag[1] == 404:
                return 403

            if flag == False:
                return 401


######################################################
##
## AUTHORIZATION FOR ANALYSIS CLASS FOR POST METHOD V2
##
######################################################


class Authorization_analysis3(Resource):

    def __init__(self, email, project_id):
        self.email = email
        self.project_id = project_id

    def Analysis_post(self):

        with db.connect() as conn:
            user_id = conn.execute(text(authentication_analysis), project_id=self.project_id).fetchone()
        print(f"user id is {user_id}")
    
        if user_id is None:
            return 404

        UserId = user_id[0]
    
        with db.connect() as conn:
            username = conn.execute(text(user_name_from_userid), user_id=UserId).fetchone()    
        print(username)
        user = username[0]
        print(self.email)

        if user != self.email:
            return 403

##########################################################
##
## AUTHORIZATION FOR SYSTEM-LTT CLASS FOR GET,PUT METHOD
##
##########################################################


class Authorization_systems(Resource):

    def __init__(self, email, process_id):
        self.email = email
        self.process_id = process_id

    def prsidltt_put_get(self):

        with db.connect() as conn:
            user = conn.execute(text(authentication_systems), process_id=self.process_id).fetchone()
            analid = conn.execute(text(authentication_systems3), process_id=self.process_id).fetchone()
        
        if user is None or analid is None:
                return 200        
        print(self.email)
        analid = analid[0]
        
        with db.connect() as conn:
            project_id = conn.execute(text(publish_analysis_processid_query), analysisid=analid).fetchone()
        
        if project_id is None:
            return 200 
        project_id = project_id[0]            

        if user[0] != self.email:
            obj = user_authentication(project_id, self.email)
            flag = obj.duplicate_auth()
            print(flag)

            if type(flag) is tuple and flag[1] == 404:
                return 403
            
            if flag == False:
                return 401


##########################################################
##
## AUTHORIZATION FOR SYSTEM-SHEAR CLASS FOR GET,PUT METHOD
##
##########################################################


class Authorization_systems2(Resource):

    def __init__(self, email, process_id):
        self.email = email
        self.process_id = process_id

    def shear_put_get(self):

        with db.connect() as conn:
            user = conn.execute(text(authentication_systems), process_id=self.process_id).fetchone()
            analid = conn.execute(text(authentication_systems3), process_id=self.process_id).fetchone()
        
        if user is None or analid is None:
                return 200        
        print(self.email)
        analid = analid[0]
        
        with db.connect() as conn:
            project_id = conn.execute(text(publish_analysis_processid_query), analysisid=analid).fetchone()
        
        if project_id is None:
            return 200 
        project_id = project_id[0]            

        if user[0] != self.email:
            obj = user_authentication(project_id, self.email)
            flag = obj.duplicate_auth()
            print(flag)

            if type(flag) is tuple and flag[1] == 404:
                return 403
            
            if flag == False:
                return 401


###########################################################
##
## AUTHORIZATION FOR SYSTEM-FINAL CLASS FOR GET,PUT METHOD
##
###########################################################


class Authorization_systems3(Resource):

    def __init__(self, email, process_id):
        self.email = email
        self.process_id = process_id

    def final_put_get(self):

        with db.connect() as conn:
            user = conn.execute(text(authentication_systems), process_id=self.process_id).fetchone()
            analid = conn.execute(text(authentication_systems3), process_id=self.process_id).fetchone()
        
        if user is None or analid is None:
                return 200        
        print(self.email)
        analid = analid[0]
        
        with db.connect() as conn:
            project_id = conn.execute(text(publish_analysis_processid_query), analysisid=analid).fetchone()
        
        if project_id is None:
            return 200 
        project_id = project_id[0]            

        if user[0] != self.email:
            obj = user_authentication(project_id, self.email)
            flag = obj.duplicate_auth()
            print(flag)

            if type(flag) is tuple and flag[1] == 404:
                return 403
            
            if flag == False:
                return 401


##################################################################
##
## AUTHORIZATION FOR SYSTEM-WINDOSCOPE CLASS FOR GET,PUT METHOD
##
##################################################################


class Authorization_systems4(Resource):

    def __init__(self, email, process_id):
        self.email = email
        self.process_id = process_id

    def windoscope_put_get(self):

        with db.connect() as conn:
            user = conn.execute(text(authentication_systems), process_id=self.process_id).fetchone()
            analid = conn.execute(text(authentication_systems3), process_id=self.process_id).fetchone()
        
        if user is None or analid is None:
                return 200        
        print(self.email)
        analid = analid[0]
        
        with db.connect() as conn:
            project_id = conn.execute(text(publish_analysis_processid_query), analysisid=analid).fetchone()
        
        if project_id is None:
            return 200 
        project_id = project_id[0]            

        if user[0] != self.email:
            obj = user_authentication(project_id, self.email)
            flag = obj.duplicate_auth()
            print(flag)

            if type(flag) is tuple and flag[1] == 404:
                return 403
            
            if flag == False:
                return 401


##################################################################
##
## AUTHORIZATION FOR SYSTEM-SYSTEMS CLASS FOR GET,POST METHOD
##
##################################################################


class Authorization_systems5(Resource):

    def __init__(self, email, anlysID):
        self.email = email
        self.analysisid = anlysID

    def systems_get_post(self):

        with db.connect() as conn:
            user_id = conn.execute(text(authentication_analysis2), analysisid=self.analysisid).fetchone()
            project_id = conn.execute(text(publish_analysis_processid_query), analysisid=self.analysisid).fetchone()
        
        if user_id is None or project_id is None:
            return 200

        UserId = user_id[0]
        project_id = project_id[0]
        
        with db.connect() as conn:
            username = conn.execute(text(user_name_from_userid), user_id=UserId).fetchone()    
        user = username[0]
      
        if user != self.email:
            obj = user_authentication(project_id ,self.email)
            flag = obj.duplicate_auth()
            
            if type(flag) is tuple and flag[1] == 404:
                return 403
            
            if flag == False:
                return 401


###########################################################
##
## AUTHORIZATION FOR SYSTEM-REPORTS CLASS FOR GET METHOD
##
###########################################################


class Authorization_systems6(Resource):

    def __init__(self, email, anlysID):
        self.email = email
        self.analysisid = anlysID

    def reports_get_1(self):

        with db.connect() as conn:
            user_id = conn.execute(text(authentication_analysis2), analysisid=self.analysisid).fetchone()
            project_id = conn.execute(text(publish_analysis_processid_query), analysisid=self.analysisid).fetchone()
            
            if user_id is None or project_id is None:
                return 200

            UserId = user_id[0]
            project_id = project_id[0]
            print(f"user id is {UserId}")
            
            with db.connect() as conn:
                username = conn.execute(text(user_name_from_userid), user_id=UserId).fetchone()    
            print(username)
            user = username[0]
            print(self.email)
            
            if user != self.email:
                obj = user_authentication(project_id ,self.email)
                flag = obj.duplicate_auth()
                print(flag)
                
                if type(flag) is tuple and flag[1] == 404:
                    return 403
                
                if flag == False:
                    return 401


#==========================================================


class Authorization_systems7(Resource):

    def __init__(self, email, process_id):
        self.email = email
        self.process_id = process_id

    def reports_get_2(self):

        with db.connect() as conn:
            user = conn.execute(text(authentication_systems), process_id=self.process_id).fetchone()
            analid = conn.execute(text(authentication_systems3), process_id=self.process_id).fetchone()
            
            if user is None or analid is None:
                return 200        
            print(self.email)
            analid = analid[0]
            
            with db.connect() as conn:
                project_id = conn.execute(text(publish_analysis_processid_query), analysisid=analid).fetchone()
            
            if project_id is None:
                return 200 
            project_id = project_id[0]            

            if user[0] != self.email:
                obj = user_authentication(project_id, self.email)
                flag = obj.duplicate_auth()
                print(flag)
                
                if type(flag) is tuple and flag[1] == 404:
                    return 403
                
                if flag == False:
                    return 401