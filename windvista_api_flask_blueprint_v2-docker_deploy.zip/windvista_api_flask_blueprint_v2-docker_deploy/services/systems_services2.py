from sqlalchemy import text
from db.queries import *
from routes import *
from services.systems_services import *
from services.validations import *
import pyshorteners
import random
import humanize
from itertools import chain
import zipfile
import os
import shutil
import csv
import re
import humanize
import pandas as pd
from janitor import clean_names
import pyarrow.feather as feather
import itertools
import concurrent.futures

def  generate_tab_file_preload(email, process_id, timestamp):
    with db.connect() as conn:
        table = conn.execute(text(generate_tab_file_preload_query), processid=process_id).fetchone()    
    
    if table is None:
        return {"message":"Process ID doesn't exist"},200

    winddata = table[24]
    if winddata == "NA":
        return {"message":"In Processing"},200
    
    return "SUCCESS", 200

def download_text_file(process_id, email):
    with db.connect() as conn:
            data = conn.execute(text(download_text_file_query), processid=process_id).fetchone() 
    if data is None:
        return {"message":"incorrect process id"},200

    print(data)

    txt_key = data[0]
    new_file_download_name = data[1]

    url = s3.generate_presigned_url(
            ClientMethod='get_object', 
            ExpiresIn=300,
            Params={
                'Bucket': environ.get("AWS_S3_BUCKET"), 
                'Key': txt_key,
                'ResponseContentDisposition': 'attachment;filename={}'.format(new_file_download_name),
                'ResponseContentType': 'text/plain',

                }
        )

    short = pyshorteners.Shortener()
    download_url = short.tinyurl.short(url)

    return {'url':f"{download_url}"},200




# Function to get the latitude & longitude of the previously uploaded file (Old File) # 
def get_latlong_old_file(primary_key, email):

    old_file_txtkey = ""
    dir_name = f"latlong_validate_old_file{random.randint(1,100)}_{email}"
    random_number = random.randint(1,100)    
    local_file_name = f"downloaded_old_file{random_number}.txt"
    
    s3 = boto3.client(
        's3', 
        aws_access_key_id=environ.get("AWS_ACCESS_KEY_ID") , 
        aws_secret_access_key=environ.get("AWS_SECRET_ACCESS_KEY"), 
        region_name="us-east-1"
        )

    try:
        os.mkdir(dir_name)
        # Getting txtkey from the database #
        with db.connect() as conn:
            old_file_txtkey = conn.execute(text(meas_sys_config_postload_txtkey_query), process_id=primary_key).fetchone()   

        old_file_txtkey = old_file_txtkey[0]
        # Downloading the Old File #    
        s3.download_file(environ.get("AWS_S3_BUCKET"), old_file_txtkey, f"{dir_name}/{local_file_name}")

    except Exception as e:
        print("\n",e,"\n")

        # Removing the Directory #
        if os.path.isdir(dir_name):
            shutil.rmtree(dir_name)

        return {"message":"Old File Does not exists in s3"}

    file_path = f"{dir_name}/{local_file_name}"
    y,isdate = read_data(file_path)
    input_file = pd.read_csv(file_path, sep="\t", skiprows=y - 1, encoding='ISO-8859-1', low_memory=False).clean_names().remove_empty()
    sn = input_file.columns.values.tolist()
    response = latlong_preproces(file_path, y, sn, isdate, local_file_name) # Getting the latitude & longitude value of Old File #

    # Removing the Directory #
    if os.path.isdir(dir_name):
        shutil.rmtree(dir_name)

    return response



def ltt_text_file_preprocess(name, dir_name, data, filename_ind, timestamp_file_data, api_need, primary_key = None, email = None):

    try:
        file_path = data
        y,isdate = read_data(file_path)
        input_file = pd.read_csv(file_path, sep="\t", skiprows=y - 1, encoding='ISO-8859-1', low_memory=False).clean_names().remove_empty()
        sn = input_file.columns.values.tolist()
        validation1 = missing_columns_ws_wd(sn,filename_ind)
        if validation1 != 0:
            return validation1

        if len(sn) > 3 and api_need=="lttref":
            return {"Status":"Invalid File","message":"You've uploaded a zip file where there's an invalid reanalysis file(s) present whereas the application expects a zip file with valid reanalysis file(s). Please upload a zip file containing valid reanalysis file(s).","filename":filename_ind}
        validation2 = validate_special(input_file,filename_ind)
        if validation2!=0:
            return validation2
        
        
        # Old file latitude and longitude validation with new file's latitude and longitude #
        # If api_need is 'reupload' #
        if api_need=="reupload" and not (primary_key == None and email == None):
            
            # Adding tasks to the Thread Pool # -- (Running Multiple tasks concurrently)
            with concurrent.futures.ThreadPoolExecutor() as executor:
                oldFile_Thread = executor.submit(get_latlong_old_file, primary_key, email)
                newFile_Thread = executor.submit(latlong_preproces, file_path, y, sn, isdate, filename_ind)
            
            # New File Validation #
            validation3 = newFile_Thread.result()
            if isinstance(validation3, dict):
                return validation3
            validation3,elevation = validation3
            print(validation3)
            if isinstance(validation3, dict):
                return validation3
            latitude,longitude = ['%.5f' % x for x in validation3]
            excluded_columns = criteria_range(input_file,filename_ind,api_need)
            if isinstance(excluded_columns, dict):
                return excluded_columns


            # Old File Validation #
            oldFileLatLongResponse = oldFile_Thread.result()
            if isinstance(oldFileLatLongResponse, dict):
                return oldFileLatLongResponse
            
            [old_file_lat, old_file_long] =['%.5f' % x for x in oldFileLatLongResponse[0]]
            
            print("\nOld file LatLong => ", old_file_lat, old_file_long)
            print("\nNew file LatLong => ", latitude, longitude)
            validation4 = validate_latlong_oldfile_newfile(old_file_lat, old_file_long, latitude, longitude, filename_ind)

            # If coordinates does not match #
            if isinstance(validation4, dict):
                return validation4
        
        else:
            validation3 = latlong_preproces(file_path,y,sn,isdate,filename_ind)
            if isinstance(validation3, dict):
                return validation3
            validation3,elevation = validation3
            print(validation3)
            if isinstance(validation3, dict):
                return validation3
            latitude,longitude = ['%.5f' % x for x in validation3]
            excluded_columns = criteria_range(input_file,filename_ind,api_need)
            if isinstance(excluded_columns, dict):
                return excluded_columns


        first_column = pd.to_datetime(input_file["date_time"].iloc[0])
        last_column = pd.to_datetime(input_file["date_time"].iloc[-1])
        second_column = pd.to_datetime(input_file["date_time"].iloc[1])
        Diff1 = humanize.precisedelta(last_column - first_column, minimum_unit="hours")
        Diff2 = humanize.precisedelta(second_column - first_column, minimum_unit="hours")
        Diff2_temp = second_column - first_column
        
        timestamp_file_data.append([first_column.strftime('%Y'), last_column.strftime('%Y'), Diff2_temp, filename_ind])

        return {"Status":"Valid File",
        "Latitude":latitude,
        "Longitude":longitude,
        "Elevation":elevation,
        "Start timestamp":first_column.strftime('%Y-%m-%d %H:%M:%S'),
        "End timestamp":last_column.strftime('%Y-%m-%d %H:%M:%S'),
        "Overall difference between Start & End timestamp":Diff1,
        "Time interval between each timestamps":Diff2,
        "filename":filename_ind,
        "start_year":first_column.strftime('%Y'),
        "end_year":last_column.strftime('%Y'),
        "excluded_columns":excluded_columns
        }
        
    except Exception as e:
        print(e)
        if api_need == "lttref":
            return {"Status":"Invalid File","message":"You've uploaded a zip file where there's no reanalysis file(s) present whereas the application expects a zip file with reanalysis file(s). Please upload the LTT reference file containing valid reanalysis file.","filename":filename_ind}
        else:
            return {"Status":"Invalid File","message":"You've uploaded a text file which is not valid. The application expects text file that have metadata containing latitude, longitude and elevation, followed by column headers: Date/Time, ws and wd columns and then the data. Please upload a proper text file.","filename":filename_ind}
    finally:
        # print("YES")
        if os.path.exists(file_path):
            os.remove(file_path)
        if os.path.exists(name):
            os.remove(name)    
