from sqlalchemy import null, text
from db.queries import *
from db.connect import init_connection_engine
import boto3
from os import environ
import os
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from workers.worker2 import worker2


db = init_connection_engine()

s3 = boto3.client(
    's3', 
    aws_access_key_id=environ.get("AWS_ACCESS_KEY_ID") , 
    aws_secret_access_key=environ.get("AWS_SECRET_ACCESS_KEY"), 
    region_name=environ.get("AWS_DEFAULT_REGION")
    )


###############################
##
## USER AUTHENTICATION CLASS
##
###############################


class user_authentication:

    #data authorization check
    
    def __init__(self, projectid, email):
        self.projectid = projectid
        self.email = email
    
    def project_id(self):

        with db.connect() as conn:
            user_id = conn.execute(text(authentication_project), project_id=self.projectid).fetchone()
        
        if user_id is None:
            return {"message":"please enter correct project id"}, 404
        UserId = user_id[0]
        
        with db.connect() as conn:
            username = conn.execute(text(user_name_from_userid), user_id=UserId).fetchone()    
        user = username[0]
        
        if user != self.email:
            return False
        else:
            return True    


    #==================================================================================================================


    def duplicate_auth(self):

        try:
            with db.connect() as conn:
                shared_user = conn.execute(text(duplicate_auth_query), project_id=self.projectid).fetchone()
        
            if shared_user is None:
                return {"message":"please enter correct project id"}, 404
            print(self.projectid)
            print(shared_user)    
            shared_string = shared_user[0]
            shared_string = shared_string.strip('[')
            shared_string = shared_string.strip(']')
            shared = shared_string.split(',')
            print(shared)
            shared = [int(i) for i in shared]

            with db.connect() as conn:
                id_by_email = conn.execute(text(user_id), useremail=self.email).fetchone()
            id_by_email = id_by_email[0]
            print("id_by_email", id_by_email)
            
            
            if id_by_email not in shared:
                return False
            else:
                return True
        
        except Exception as e:
            print(e)
            return False


##############################
##
## EDIT PROJECT FUNCTION
##
##############################


def edit_project(user, title, description, location, project_id):
    
    user_id = None
    data = []

    # checking if user exists or not
    with db.connect() as conn:
        result = conn.execute(text(check_user_email), user=user).fetchone()
        if result is None:
            return {"message": "The given user doesn't exists"}, 404
        user_id = result[0]

    # getting all projects of user
    with db.connect() as conn:
        result = conn.execute(text(all_user_project_query), user_id=user_id).fetchall()
        data = [dict(row) for row in result]

    # checking if title already exists or not
    if not any(d['title'] == title for d in data):
        with db.connect() as conn:
            conn.execute(text(update_project_query),title=title, description=description, location=location, project_id=project_id)
    else:
        return {"message": "title already exists"}, 200

    return {'message': "project updated successfully"}, 200


################################
##
## CREATE NEW PROJECT FUNCTION
##
################################


def new_project(user, timestamp, title, location, description, mast, lidar):
    
    if len(title) < 3 or len(title) > 40:
        return {"message":"Project title's charecter length should always range between 3 to 40."},200

    if len(location) < 3 or len(location) > 18:
        return {"message":"Project location's charecter length should always range between 3 to 18."},200

    if len(description) < 1 or len(description) > 400:
        return {"message":"Project description's charecter length should always range between 1 to 400."},200
    

    userid = None  
        
    with db.connect() as conn:
        #  checking useremail
        result = conn.execute(text(user_id),useremail=user).fetchone()
        conn.close()
        
        if result is not None:
            for row in result:
                if row:
                    userid = row
                else:
                    return {"message": "user is not present"},404
        else:
            return {"message": "user is not present"},404

    # getting all project titles of user
    data = None
    
    with db.connect() as conn:
        titles = conn.execute(text(select_title_windvista_project_query), userid=userid).fetchall()
        conn.close()
        if titles is not None:
            data = [dict(rows) for rows in titles]

        else:
            return {"message": "No projects found"},404
    
    if not any(d['title'] == title for d in data):
        print("title is not present")
        with db.connect() as conn:
            conn.execute(text(insert_windvista_project_query), timestamp=timestamp, title=title, location=location, description=description, userid=userid, mast=mast, lidar=lidar)
            conn.close()
    else:
        return {"message": "Title already exist"},200
    
    project_id = None
    with db.connect() as conn:
        newid = conn.execute(select_max_project_id_query).fetchone()
        conn.close()
        for row in newid:
            project_id = row
    
    return {"projectID":project_id},200



##################################
##
## SHOW ARCHIVE PROJECT FUNCTION
##
##################################


def show_project_archive(user):

    # global varaible scope
    user_id = None

    # getting the userid checking if user already exists 
    # if exists return the user id
    # if not creating a new user

    with db.connect() as conn:
        user = conn.execute(text(user_id_username_query),user=user).fetchone()
        if user is not None:
            for userid in user:
                user_id = userid
        else:
            conn.execute(text(insert_user_query),user=user)
            # return jsonify({"message": "The given email id does not exists"}),404

    # once user is created getting new user id
    with db.connect() as conn:
        user = conn.execute(text(user_id_username_query),user=user).fetchone()
        if user is not None:
            for userid in user:
                user_id = userid

    print(user_id)

    data = None
    with db.connect() as conn:
        retsults = conn.execute(text(show_project_archived_query), userID=user_id)
        data = [dict(row) for row in retsults]

    return data, 200


#########################################
##
## ARCHIVE & UNARCHIVE PROJECT FUNCTION
##
#########################################


def uarchive_project(projectID, timestamp):
    
    # checking if project id is present or not
    with db.connect() as conn:
        try:
            project = conn.execute(text(select_windvista_project_query), projectID=projectID).fetchone()
            status = conn.execute(text(status_project_archive_or_not), projectID=projectID).fetchone()[0]
            
        except Exception as e:
            status = None

        if not project or not status:
            return {"message": "project does not exists"}, 200

        if status == 'active':
            with db.connect() as conn:
                conn.execute(text(update_windvista_project_query), timestamp=timestamp, projectID=projectID)
                conn.close()
            return {"message": "project archived"},200

        if status == "archived":
            with db.connect() as conn:
                conn.execute(text(remove_update_windvista_project_query), timestamp=timestamp, projectID=projectID)
                conn.close()
            return {"message": "project Unarchived"},200


##############################
##
## SHARE PROJECT FUNCTION
##
##############################


def share_project_email(user):

    try:
        with db.connect() as conn:
            team = conn.execute(text(all_team_members),user=user).fetchall()
        all_user = list(map(lambda v: v[0], team))
        return {"Team":all_user}, 200
    
    except Exception as e:
        print(e)
        return {"msg" : e}


##############################
##
## MAIL SENDING FUNCTION
##
##############################


def send_email(receiver_mail, project_id, email):

    Sender_Email = os.environ["WINDVISTA_EMAIL_USERNAME"]
    Receiver_Email = receiver_mail
    Password = os.environ["WINDVISTA_EMAIL_PASSWORD"]

    with db.connect() as conn:
        shared_title = conn.execute(text(select_project_name_query),project_id=project_id).fetchone()[0]

    with db.connect() as conn:
        receiver_first_name = conn.execute(text(receiver_first_name_query), receiver_mail=receiver_mail).fetchone()[0]

    with db.connect() as conn:
        sender_first_name = conn.execute(text(sender_first_name_query), email=email).fetchone()[0]
        
    mail_content1 = """\
    <!DOCTYPE html>
    <html>
    <head>
        <style>
            body {
            margin-left: 20px;
            background-color: #FFFFFF;
                background-repeat: no-repeat;
            background-attachment: fixed;
            background-position: center;
            text-align:center;
            }
            .header {
                background: url( "https://wind-public-files.s3.ap-south-1.amazonaws.com/wind-email/wplogo.jpg" ) no-repeat;
                height:100px;
                width:200;
                margin:-10px;
                background-color:#361755;
                }
            h1 {
                font-family: "Roboto","Helvetica Neue",Helvetica,Arial,sans-serif;
                font-size: 30px;
                font-style: normal;
                font-variant: normal;
                font-weight: bold;
                line-height: normal;
                color: black;
                
                }
            h2 {
                font-family: "Roboto","Helvetica Neue",Helvetica,Arial,sans-serif;
                font-size: 20px;
                font-style: normal;
                font-variant: normal;
                font-weight: bold;
                line-height: normal;
                color: grey;
                }
            p {
                margin-left: -20px;
                font-family: "Roboto","Helvetica Neue",Helvetica,Arial,sans-serif;
                font-size: 15px;
                font-style: normal;
                font-variant: normal;
                font-weight: normal;
                line-height: normal;
                color: grey;
                }
            a.button {
                color: black;
                background-color: #ffbf00;
                padding: 16px 32px;
                text-align: center;
                text-decoration: none;
                display: inline-block;
                font-size: 16px;
                margin: 4px 2px;
                transition-duration: 0.4s;
                cursor: pointer;
            }
            
        </style>
    </head>
    <body>
        <img src="https://wind-public-files.s3.ap-south-1.amazonaws.com/wind-email/wplogo.jpg" style="background-color:#361755;"/>
        <h3> Shared Project Details : </h3>
        """

    mail_content2 = f'''\
        {mail_content1}
        <h4>Hi {receiver_first_name}, <br>{sender_first_name} has shared a project with you.<br>Project Name: {shared_title}<br>Cheers,<br>WindVista Team</h4>
        <h3>To view the above shared project<h3>
        <a href="https://windvista-beta.sirpi.co.in/"style="color:black;background-color:#ffbf00;padding:16px 32px;text-align:center;text-decoration:none;display:inline-block;font-size:16px;margin:4px 2px;transition-duration:0.4s;cursor:pointer">Go to WindVista App</a>
        </body>
        </html>
        '''

    Message = MIMEMultipart()
    Message['From'] = Sender_Email
    Message['To'] = Receiver_Email
    Message['Subject'] = 'Shared Project Notification'

    Message.attach(MIMEText(mail_content2, 'html'))
    #Message.attach(MIMEText(mail_content1, 'html'))

    smtpobj = smtplib.SMTP(os.environ["WINDVISTA_EMAIL_HOST"], 587)
    smtpobj.ehlo()
    smtpobj.starttls()
    smtpobj.login(Sender_Email, Password)

    Text = Message.as_string()
    smtpobj.sendmail(Sender_Email, Receiver_Email, Text)
    smtpobj.quit()

    print("Mail Successfully Sent To : ", Receiver_Email)
    return "OK"


##############################
##
## SHARED PROJECT FUNCTION
##
##############################


def all_shared_project(sharedUser, project_id, timestamp,email):

    email = email.strip('"')
    user = None
    user_ids = []
    user_list = []
    newshare_user = []
    user_string = ""

    with db.connect() as conn:
        already_shared = conn.execute(text(shared_ids_query),project_id=project_id).fetchone()[0]
    
    if already_shared is not None:
        sharedUser = sharedUser.strip('[').strip(']')
        sharedUser = sharedUser.split(',')
        sharedUser_1 = []
        
        for i in range(len(sharedUser)):
            sharedUser_1.append(sharedUser[i].strip("'").strip('"'))
        x = sharedUser_1
        already_shared = already_shared.strip('[').strip(']')
        already_shared = already_shared.split(',')
        already_shared = [int(i) for i in already_shared if i.lower() != "none"]
        already_shared = list(set(already_shared))
        y = already_shared
        
        for i in range(len(already_shared)):
            userid = already_shared[i]
            with db.connect() as conn:
                user_already = conn.execute(text(user_name_from_userid),user_id=userid).fetchone()[0]
        
            if user_already in x:
                x.remove(user_already)
        
        for key in range(len(x)):
            user = x[key]
            user_list.append(user)
            send_email(user, project_id, email)
            print(user)
            with db.connect() as conn:
                user_id = conn.execute(text(user_id_username_query),user=user).fetchone()
                print(user_id)
                user_id = user_id[0]
                user_ids.append(user_id)
        
        y = [int(i) for i in y]
        if set(user_ids).issubset(y):
            user_ids = y
        else:
            user_ids.extend(y)
        user_string = str(user_ids)

        with db.connect() as conn:
            conn.execute(text(insert_shared2),user_id=user_string, timestamp=timestamp, project_id=project_id)
        return {"msg":"project shared"}, 200
    
    else:
        print(sharedUser)
        sharedUser = sharedUser.strip('[').strip(']')
        sharedUser = sharedUser.split(',')
        sharedUser_1 = []

        for i in range(len(sharedUser)):
            sharedUser_1.append(sharedUser[i].strip("'").strip('"'))
        x = sharedUser_1

        for key in range(len(x)):
            user = x[key]
            user_list.append(user)
            send_email(user, project_id, email)
            print(user)
            with db.connect() as conn:
                user_id = conn.execute(text(user_id_username_query),user=user).fetchone()[0]
                user_ids.append(user_id)
                user_string = str(user_ids)
        
        with db.connect() as conn:
            conn.execute(text(insert_shared2),user_id=user_string, timestamp=timestamp, project_id=project_id)
        
        return {"msg":"project shared"}, 200


##############################
##
## VIEW SHARED PROJECT FUNCTION
##
##############################


def View_shared(mainUser):

    try:
        with db.connect() as conn:
            main_user_id = conn.execute(text(user_id_username_query),user=mainUser).fetchone()[0]
            data = conn.execute(text(show_shared_projects),userID=main_user_id).fetchall()
        
        shared_project = [dict(row) for row in data]
        temp_list = []
        for i in range(len(shared_project)):
            
            owner_id = shared_project[i]['userID']
            with db.connect() as conn:
                    owner = conn.execute(text(user_name_from_userid),user_id=owner_id).fetchone()[0]

            shared_project[i]['owner'] = owner
        
        return shared_project, 200

    except Exception as e:
        print(e)
        return {"msg": "user ID does not exist"}, 200


###################################
##
## VIEW UNSHARED PROJECT FUNCTION
##
###################################


def unshare_project(unshareto, email, project_id):

    unshareto = unshareto.strip('[')
    unshareto = unshareto.strip(']')
    unshareto = unshareto.split(',')
    unshareto = [i.strip('"') for i in unshareto]
    print(email)
    print(project_id)
    [print(i) for i in unshareto]
    unshareto_id = []

    try:
        for i in unshareto:
            with db.connect() as conn:
                user_id = conn.execute(text(check_user_email),user=i).fetchone()[0]
            unshareto_id.append(user_id)

    except:
        return {"message":f"{unshareto} is wrong"},200

    print(unshareto_id)    

    try:
        with db.connect() as conn:
            shared_users = conn.execute(text(shared_ids_query),project_id=project_id).fetchone()[0]
    except:
        return {"message":"project isn't shared"},200    

    shared_users = shared_users.strip('[')
    shared_users = shared_users.strip(']')
    shared_users = shared_users.split(',')
    shared_users = [int(i) for i in shared_users]

    for i in unshareto_id:
       if i not in shared_users: 
           return {"message":f"{unshareto} was not shared"},200

    for i in unshareto_id:
        if i in shared_users: 
            shared_users.remove(i)

    status = "shared"
    print(shared_users)

    if len(shared_users) == 0:
        status = "active"
        with db.connect() as conn:
            conn.execute(text(unshare_query), project_id=project_id)
    else:
        shared_users = str(shared_users)
        with db.connect() as conn:
            conn.execute(text(insert_shared),user_id=shared_users, status=status, project_id=project_id)

    return {"unshared to":f"{unshareto}"},200
