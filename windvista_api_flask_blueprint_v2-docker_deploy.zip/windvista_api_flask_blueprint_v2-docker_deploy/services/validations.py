import random
import zipfile
import os
import shutil
import re
import numpy as np
import pandas as pd
from routes import *
import csv
from itertools import chain


def read_data(file_path):
    with open(file_path, "r", encoding='ISO-8859-1') as file:
        tsv_file = csv.reader(file, delimiter="\t")
        y = 0
        isdate = False
        for line in tsv_file:
            y += 1
            if 'Date/Time' in line:
                isdate = True
                break
    return [y,isdate]        


def dmsconvert(latitude,longitude,latformat):
    data = pd.DataFrame([{"latitude":latitude,"longitude":longitude}])
    data = data.reindex(sorted(data.columns), axis=1)
    data = data.replace(to_replace ="\\\\",value="",regex = True)
    l = list(data.columns.values)
    str_degree = "°\"'"
    try:
        match = re.findall(r"°|\"|'|", data[l[0]].sum().astype(str) + data[l[1]].sum().astype(str))
    except:
        match = re.findall(r"°|\"|'|", data[l[0]].sum() + data[l[1]].sum())
    flag = False
    for i in str_degree:
        if i in match:
            flag = True

    if flag:
        #convert function logic here
        if latformat == 4:
            for i in l:
                data_t =  data[i].astype(str).str.replace("′","°").str.replace("″","°")
                data_t = data_t.astype(str).str.split('''[°,\",']''')
                temp_data = pd.DataFrame()
                temp_data[f'{i}_first'] = data_t.str[0]
                temp_data[f'{i}_second'] = data_t.str[1]
                temp_data[f'{i}_third'] = data_t.str[2]
                temp_data = temp_data.astype(float)
                temp_data[f'{i}_val'] = temp_data[f'{i}_first'] +  temp_data[f'{i}_second']/60 + temp_data[f'{i}_third']/3600
                temp_data[f'{i}_fourth'] = data_t.str[3]
                temp_data.loc[(temp_data[f'{i}_fourth'].str.lower()=='w') | (temp_data[f'{i}_fourth'].str.lower()=='s'), f'{i}_val'] = temp_data[f'{i}_val'] * -1
                data[i] = temp_data[f'{i}_val']
        if latformat == 3:
            for i in l:
                data_t =  data[i].astype(str).str.replace("′","°")
                data_t = data_t.astype(str).str.split('''[°,\",']''')
                temp_data = pd.DataFrame()
                temp_data[f'{i}_first'] = data_t.str[0]
                temp_data[f'{i}_second'] = data_t.str[1]
                temp_data = temp_data.astype(float)
                temp_data[f'{i}_val'] = temp_data[f'{i}_first'] +  temp_data[f'{i}_second']/60
                temp_data[f'{i}_fourth'] = data_t.str[2]
                temp_data.loc[(temp_data[f'{i}_fourth'].str.lower()=='w') | (temp_data[f'{i}_fourth'].str.lower()=='s'), f'{i}_val'] = temp_data[f'{i}_val'] * -1
                data[i] = temp_data[f'{i}_val']
        if latformat == 2:
            for i in l:
                data_t = data[i].astype(str).str.split('''[°,\",']''')
                temp_data = pd.DataFrame()
                temp_data[f'{i}_first'] = data_t.str[0]
                temp_data = temp_data.astype(float)
                temp_data[f'{i}_val'] = temp_data[f'{i}_first']
                temp_data[f'{i}_fourth'] = data_t.str[1]
                temp_data.loc[(temp_data[f'{i}_fourth'].str.lower()=='w') | (temp_data[f'{i}_fourth'].str.lower()=='s'), f'{i}_val'] = temp_data[f'{i}_val'] * -1
                data[i] = temp_data[f'{i}_val']
    else:
        data1 = re.findall(r"\d*\.?\d*", data[l[0]].sum() + data[l[1]].sum())
        data1 = list(filter(None,data1))
        print(data1[0])
        if re.findall(r"[a-zA-Z]", data[l[0]].sum()) == ["S"]:
            data1[0] = -pd.to_numeric(data1[0])
        else:
            data1[0] = pd.to_numeric(data1[0])
        if re.findall(r"[a-zA-Z]", data[l[1]].sum()) == ["W"]:
            data1[1] = -pd.to_numeric(data1[1])
        else:
            data1[1] = pd.to_numeric(data1[1])
        return ['%.6f' % data1[0],'%.6f' % data1[1]]
    return ['%.6f' % data["latitude"][0],'%.6f' % data["longitude"][0]]


def missing_columns(latindex,longindex,elevationindex,isdate,filename_ind):
            
    j = []
    if len(latindex) == 0:
        j.append(f"latindex")
    if len(longindex) == 0:
        j.append(f"longindex")
    if len(elevationindex) == 0:
        j.append(f"elevationindex")
    if isdate == False:
        j.append(f"isdate")
    
    print(len(j))
    if len(j) == 4:
        return {"Status":"Invalid File","message":"You've uploaded a text file without header (metadata) information and Date/Time column, whereas the application expects latitude, longitude and elevation, followed by column headers: Date/Time, ws and wd columns. Please upload a proper text file with metadata and Date/Time column.","filename":filename_ind}
    if isdate == False:
        return {"Status":"Invalid File","message":"You've uploaded a text file without Date/Time column, whereas the application expects the text files with Date/Time column. Please upload a proper text file with Date/Time column.","filename":filename_ind}
    if len(j) == 3:
        return {"Status":"Invalid File","message":"You've uploaded a text file without header (metadata) information, whereas the application expects latitude, longitude and elevation, followed by column headers: Date/Time, ws and wd columns. Please upload a proper text file with metadata.","filename":filename_ind}
    if len(j) == 2:
        if "latindex" not in j:
            return {"Status":"Invalid File","message":"You've uploaded a text file without longitude and elevation value in the header (metadata) whereas the application expects a text file with metadata comprising of latitude, longitude and elevation. Please upload a valid text file containing longitude and elevation.","filename":filename_ind}
        if "longindex" not in j:
            return {"Status":"Invalid File","message":"You've uploaded a text file without latitude and elevation value in the header (metadata) whereas the application expects a text file with metadata comprising of latitude, longitude and elevation. Please upload a valid text file containing latitude and elevation.","filename":filename_ind}
        if "elevationindex" not in j:
            return {"Status":"Invalid File","message":"You've uploaded a text file without latitude and longitude value in the header (metadata) whereas the application expects a text file with metadata comprising of latitude, longitude and elevation. Please upload a valid text file containing latitude and longitude.","filename":filename_ind}
    if len(j) == 1:  
        if "latindex" in j:
            return {"Status":"Invalid File","message":"You've uploaded a text file without latitude value in the header (metadata) whereas the application expects a text file with metadata comprising of latitude, longitude and elevation. Please upload a valid text file containing latitude.","filename":filename_ind}
        if "longindex" in j:
            return {"Status":"Invalid File","message":"You've uploaded a text file without longitude value in the header (metadata) whereas the application expects a text file with medata comprising of latitude, longitude and elevation. Please upload a valid text file containing longitude.","filename":filename_ind} 
        if "elevationindex" in j:
            return {"Status":"Invalid File","message":"You've uploaded a text file without elevation value in the header (metadata) whereas the application expects a text file with metadata comprising of latitude, longitude and elevation. Please upload a valid text file containing elevation.","filename":filename_ind}
    return 0


def missing_columns_ws_wd(sn,filename_ind):
    # reference_ht_regex = "([1-9]0|[1-9]?[1-9]|1[0-9]{1,2}|2[0-4][0-9])(_\d)?|250"
    reference_ht_regex = "([1-9]?[0-9]|1[0-9]{1,2}|2[0-4][0-9])(_\d)?|250"
    parallel_regex = "a|b|c|d|e|n|s|ne|nw|se|sw|e|w|nne|nnw|sse|ssw|ene|ese|wsw|wnw"
    ws_regex = f"((((speed|ws|wspeed)_({reference_ht_regex})(_\[m_s\])?)|^(u({reference_ht_regex})_(wsp)_({reference_ht_regex})(_\[m_s\])?)$|((ws)_({reference_ht_regex})(_({parallel_regex}))?_(mean|sd|min|max)_\[m_s\])))"    
    wd_regex = f"(((wd|wdir)_({reference_ht_regex})(_\[(°|_)\])?)|(u({reference_ht_regex})_(dir)_({reference_ht_regex})(_\[(°|_)\])?)|((wd)_({reference_ht_regex})(_({parallel_regex}))?_mean_\[(°|_)\]))"    
    
    print(set(sn))
    if not any(re.compile(wd_regex).search(x) for x in set(sn)):
        print(any(re.compile(wd_regex).search(x) for x in set(sn)))
        return {"Status":"Invalid File","message":"You've uploaded a text file without column headers comprising of these characters: dir or wdir or wd. Please upload a proper text file with proper column headers.","filename":filename_ind}
    if not any(re.compile(ws_regex).search(x) for x in set(sn)):
        print(any(re.compile(ws_regex).search(x) for x in set(sn)))
        return {"Status":"Invalid File","message":"You've uploaded a text file without column headers comprising of these characters: speed or ws or wspeed or wsp or ws. Please upload a proper text file with proper column headers.","filename":filename_ind}
    if len(sn) == 1:
        return {"Status":"Invalid File","message":"You've uploaded a text file without column headers comprising of these characters: speed or ws or wspeed or wsp or ws or dir or wdir or wd. Please upload a proper text file with proper column headers.","filename":filename_ind}
    return 0


def validate_latlong(latitude,longitude,latformat,filename_ind):
    try:
        # dummy case to trigger exception (DMS Checker)
        latitude = pd.to_numeric(latitude)
        longitude = pd.to_numeric(longitude)
    except:
        latitude = latitude.replace(" ", "")
        longitude = longitude.replace(" ", "")
        inverseDMS_lat = '[a-zA-Z](([1-8]?[0-9])\D+([1-5]?[0-9]|60)\D+([01-5]?[0-9]|60)(\.[0-9]+)?|90\D+0\D+0)\D+'
        inverseDDM_lat = '[a-zA-Z](([1-8]?[0-9])\D+[1-6]?[0-9](\.\d{1,3})?|90(\D+0)?)\D+'
        inverseDD_lat = '[a-zA-Z][\+-]?(([1-8]?[0-9])(\.\d{1,6})?|90)\D*'
        
        inverseDMS_long = '[a-zA-Z][\+-]?([1-7]?\d{1,2}\D+([1-5]?\d|60)\D+([01-5]?\d|60)(\.\d)?|180\D+0\D+0)\D+?'
        inverseDDM_long = '[a-zA-Z]((1[0-7][0-9]|[1-9]?[0-9])\D+[1-6]?[0-9](\.\d{1,3})?|180(\D+0)?)\D+'
        inverseDD_long = '[a-zA-Z][\+-]?((1[0-7][0-9]|[1-9]?[0-9])(\.\d{1,6})?|180)\D*'
        
        if(re.fullmatch(f"^({inverseDMS_lat})|({inverseDDM_lat})|({inverseDD_lat})$",latitude)):
            latitude = latitude[1:]+latitude[0]
        if(re.fullmatch(f"^({inverseDMS_long})|({inverseDDM_long})|({inverseDD_long})$",longitude)):
            longitude = longitude[1:]+longitude[0]
        print(latitude)
        print(longitude)
        # LatLong Format Checker (DMS,DDM or DD)
        if((re.match('^(([1-8]?[0-9])\D+([1-5]?[0-9]|60)\D+([01-5]?[0-9]|60)(\.[0-9]+)?|90\D+0\D+0)\D+[NSns]$',latitude)) or (re.match('^[\+-]?([1-7]?\d{1,2}\D+([1-5]?\d|60)\D+([01-5]?\d|60)(\.\d)?|180\D+0\D+0)\D+?[EWew]$',longitude))):
            latformat = 4
        if((re.match('^(([1-8]?[0-9])\D+[1-6]?[0-9](\.\d{1,3})?|90(\D+0)?)\D+[NSns]$',latitude)) or (re.match('^((1[0-7][0-9]|[1-9]?[0-9])\D+[1-6]?[0-9](\.\d{1,3})?|180(\D+0)?)\D+[EWew]$',longitude))):
            latformat = 3
        if((re.match('^[\+-]?(([1-8]?[0-9])(\.\d{1,6})?|90)\D*[NSns]$',latitude)) or (re.match('^[\+-]?((1[0-7][0-9]|[1-9]?[0-9])(\.\d{1,6})?|180)\D*[EWew]$',longitude))):
            latformat = 2

        if(re.match('^(([1-8]?[0-9])\D+([1-5]?[0-9]|60)\D+([01-5]?[0-9]|60)(\.[0-9]+)?|90\D+0\D+0)\D+[^NSns]$',latitude)):
            return {"Status":"Invalid File","message":"You've uploaded a text file with wrong compass direction in latitude, whereas the application expects latitude (in DMS) to be either N or S. Please upload a text file containing proper compass direction.","filename":filename_ind}
        if(re.match('^(([1-8]?[0-9])\D+[1-6]?[0-9](\.\d{1,3})?|90(\D+0)?)\D+([^NSns])$',latitude)):
            return {"Status":"Invalid File","message":"You've uploaded a text file with wrong compass direction in latitude, whereas the application expects latitude (in DDM) to be either N or S. Please upload a text file containing proper compass direction.","filename":filename_ind}
        if(re.match('^[\+-]?(([1-8]?[0-9])(\.\d{1,6})?|90)\D+[^NSns]$',latitude)): 
            return {"Status":"Invalid File","message":"You've uploaded a text file with wrong compass direction in latitude, whereas the application expects latitude (in DD) to be either N or S. Please upload a text file containing proper compass direction.","filename":filename_ind}
        if(re.match('^(([1-8]?[0-9])\D+([1-5]?[0-9]|60)\D+([01-5]?[0-9]|60)(\.[0-9]+)?|90\D+0\D+0)$',latitude)): 
            return {"Status":"Invalid File","message":"You've uploaded a text file with no compass direction in latitude, whereas the application expects latitude (in DMS) to be either N or S. Please upload a text file containing proper compass direction.","filename":filename_ind}
        if(re.match('^(([1-8]?[0-9])\D+[1-6]?[0-9](\.\d{1,3})?|90(\D+0)?)$',latitude)): 
            return {"Status":"Invalid File","message":"You've uploaded a text file with no compass direction in latitude, whereas the application expects latitude (in DDM) to be either N or S. Please upload a text file containing proper compass direction.","filename":filename_ind}
        if(re.match('^[\+-]?(([1-8]?[0-9])(\.\d{1,6})?|90)$',latitude)): 
            return {"Status":"Invalid File","message":"You've uploaded a text file with no compass direction in latitude, whereas the application expects latitude (in DD) to be either N or S. Please upload a text file containing proper compass direction.","filename":filename_ind}
        
        # Longitude
        if(re.match('^[\+-]?([1-7]?\d{1,2}\D+([1-5]?\d|60)\D+([01-5]?\d|60)(\.\d+)?|180\D+0\D+0)\D+[^EWew]$',longitude)):
            return {"Status":"Invalid File","message":"You've uploaded a text file with wrong compass direction in longitude, whereas the application expects longitude (in DMS) to be either E or W. Please upload a text file containing proper compass direction.","filename":filename_ind}
        if(re.match('^((1[0-7][0-9]|[1-9]?[0-9])\D+[1-6]?[0-9](\.\d{1,3})?|180(\D+0)?)\D+([^EWew])$',longitude)):
            return {"Status":"Invalid File","message":"You've uploaded a text file with wrong compass direction in longitude, whereas the application expects longitude (in DDM) to be either E or W. Please upload a text file containing proper compass direction.","filename":filename_ind}
        if(re.match('^[\+-]?((1[0-7][0-9]|[1-9]?[0-9])(\.\d{1,6})?|180)\D+[^EWew]$',longitude)):
            return {"Status":"Invalid File","message":"You've uploaded a text file with wrong compass direction in longitude, whereas the application expects longitude (in DD) to be either E or W. Please upload a text file containing proper compass direction.","filename":filename_ind}
        if(re.match('^[\+-]?([1-7]?\d{1,2}\D+([1-5]?\d|60)\D+([01-5]?\d|60)(\.\d+)?|180\D+0\D+0)$',longitude)):
            return {"Status":"Invalid File","message":"You've uploaded a text file with no compass direction in longitude, whereas the application expects longitude (in DMS) to be either E or W. Please upload a text file containing proper compass direction.","filename":filename_ind}
        if(re.match('^((1[0-7][0-9]|[1-9]?[0-9])\D+[1-6]?[0-9](\.\d{1,3})?|180(\D+0)?)$',longitude)):
            return {"Status":"Invalid File","message":"You've uploaded a text file with no compass direction in longitude, whereas the application expects longitude (in DDM) to be either E or W. Please upload a text file containing proper compass direction.","filename":filename_ind}
        if(re.match('^[\+-]?((1[0-7][0-9]|[1-9]?[0-9])(\.\d{1,6})?|180)$',longitude)):
            return {"Status":"Invalid File","message":"You've uploaded a text file with no compass direction in longitude, whereas the application expects longitude (in DD) to be either E or W. Please upload a text file containing proper compass direction.","filename":filename_ind}
        

        data1 = dmsconvert(latitude,longitude,latformat)
        latitude = data1[0]
        longitude = data1[1]
        
    if type(latitude) == str:
        if latitude[-1] == "S":
            latitude = pd.to_numeric(latitude[:-1]) * -1
        else:
            latitude = pd.to_numeric(latitude[:-1])
    if type(longitude) == str:
        if longitude[-1] == "W":
            longitude = pd.to_numeric(longitude[:-1]) * -1   
        else:
            longitude = pd.to_numeric(longitude[:-1])
    latitude = pd.Series(latitude)
    longitude = pd.Series(longitude)        
    if latformat == 1:
        bool_series1 = (latitude.astype(float).between(-90, 90, inclusive = True)).tolist()
        bool_series2 = (longitude.astype(float).between(-180, 180, inclusive = True)).tolist()
        if False in bool_series1:
            return {"Status":"Invalid File","message":"You've uploaded a text file with out of bound value in the latitude, whereas the application expects latitude value in the range -90.0 to 90.0. Please upload a text file containing proper latitude value.","filename":filename_ind}
        if False in bool_series2:
            return {"Status":"Invalid File","message":"You've uploaded a text file with out of bound value in the longitude, whereas the application expects longitude value in the range -180.0 to 180.0. Please upload a text file containing proper longitude value.","filename":filename_ind}
    if latformat == 2:
        bool_series1 = (latitude.astype(float).between(-90, 90, inclusive = True)).tolist()
        bool_series2 = (longitude.astype(float).between(-180, 180, inclusive = True)).tolist()
        if False in bool_series1:
            return {"Status":"Invalid File","message":"You've uploaded a text file with out of bound value in the latitude, whereas the application expects latitude value in the range -90.0 to 90.0 for DD. Please upload a text file containing proper latitude value.","filename":filename_ind}
        if False in bool_series2:
            return {"Status":"Invalid File","message":"You've uploaded a text file with out of bound value in the longitude, whereas the application expects longitude value in the range -180.0 to 180.0 for DD. Please upload a text file containing proper longitude value.","filename":filename_ind}
    if latformat == 3:
        bool_series1 = (latitude.astype(float).between(0, 90, inclusive = True)).tolist()
        bool_series2 = (longitude.astype(float).between(0, 180, inclusive = True)).tolist()
        if False in bool_series1:
            return {"Status":"Invalid File","message":"You've uploaded a text file with out of bound value in the latitude, whereas the application expects latitude value in the range 0.0 to 90.0 for DDM. Please upload a text file containing proper latitude value.","filename":filename_ind}
        if False in bool_series2:
            return {"Status":"Invalid File","message":"You've uploaded a text file with out of bound value in the longitude, whereas the application expects longitude value in the range 0.0 to 180.0 for DDM. Please upload a text file containing proper longitude value.","filename":filename_ind}
    if latformat == 4:
        bool_series1 = (latitude.astype(float).between(0, 90, inclusive = True)).tolist()
        bool_series2 = (longitude.astype(float).between(0, 180, inclusive = True)).tolist()
        if False in bool_series1:
            return {"Status":"Invalid File","message":"You've uploaded a text file with out of bound value in the latitude, whereas the application expects latitude value in the range 0.0 to 90.0 for DMS. Please upload a text file containing proper latitude value.","filename":filename_ind}
        if False in bool_series2:
            return {"Status":"Invalid File","message":"You've uploaded a text file with out of bound value in the longitude, whereas the application expects longitude value in the range 0.0 to 180.0 for DMS. Please upload a text file containing proper longitude value.","filename":filename_ind}
    return [latitude,longitude]

def validate_special(input_file,filename_ind):
    validation_date = input_file.filter(regex="date_time").values
    validation_rest = input_file[input_file.columns.difference(["date_time"])]
    try:
        dates_list = pd.to_datetime(validation_date[:,0],format="%Y-%m-%d %H:%M")
    except:
        return {"Status":"Invalid File","message":"You've uploaded a text file with invalid Date/time column, whereas the application expects a file with valid Date/time column of format YYYY-mm-dd HH:MM. Please upload a proper text file.","filename":filename_ind}
    try:
        validation_rest = validation_rest.astype(float)
    except Exception as e:
        return {"Status":"Invalid File","message":"You've uploaded a text file with special characters or alphabets, whereas the application expects a file with floating points. Please upload a proper text file.","filename":filename_ind}
    return 0

def format_columns(string):
    string = string.replace('MEAN_[M_S]', 'mean [m/s]').replace('MIN_[M_S]', 'min [m/s]').replace('MAX_[M_S]', 'max [m/s]').replace('SD_[M_S]', 'sd [m/s]').replace('MEAN_[°C]', 'mean [°C]').replace('MEAN_[%]', 'mean [%]').replace('MEAN_[MBAR]', 'mean [mbar]').replace('MEAN_[HPA]', 'mean [hPa]').replace('MEAN_[KPA]', 'mean [kPa]').replace('MEAN_[PA]', 'mean [Pa]').replace('MEAN_[°]', 'mean [°]').replace('MEAN_[ATM]', 'mean [atm]').replace('MEAN_[HG]', 'mean [Hg]').replace('MEAN_[PSI]', 'mean [psi]').replace('MEAN_[KG_M3]', 'mean [kg/m3]').replace('_[_]', ' [°]').replace('_[°]', ' [°]').replace('MEAN_[_C]', 'mean [°C]')
    return re.sub("(?<=\d)[_](?=\d)",".",string)

def criteria_range2(input_file, regex, minimum, maximum):
    subsetcolumns = input_file.filter(regex=regex).astype(float).replace(9999.0, np.nan)
    subset_names = subsetcolumns.columns.values
    y = []
    for x in subset_names:
        if not all(subsetcolumns[x].astype(float).dropna().between(minimum,maximum,inclusive=True)):
            y.append(x)
    y = [format_columns(x.upper()) for x in y]
    return y

def isexcluded(input_file,excluded_regex):
    included_columns = input_file.filter(regex=excluded_regex).columns.to_list()
    included_columns.append("date_time")
    excluded_columns = input_file[input_file.columns.difference(included_columns)]
    if excluded_columns.shape[1] != 0:
        return f"{formated([format_columns(x.upper()) for x in excluded_columns])}"
    return "No columns were excluded"

def formated(ws):
    if len(ws) > 1:
        j =""
        count = 0
        for i in ws:
            count = count + 1
            if count == 1:
                j = j + i
            elif count != len(ws):
                j = j + ", " + i
            else:
                j = j + " and " + i
        return j
    else:
        return ws[0]

def criteria_range(input_file,filename_ind,api_need):
    # reference_ht_regex = "([1-9]0|[1-9]?[1-9]|1[0-9]{1,2}|2[0-4][0-9])(_\d)?|250"
    reference_ht_regex = "([1-9]?[0-9]|1[0-9]{1,2}|2[0-4][0-9])(_\d)?|250"
    parallel_regex = "a|b|c|d|e|n|s|ne|nw|se|sw|e|w|nne|nnw|sse|ssw|ene|ese|wsw|wnw"
    ws_regex = f"((((speed|ws|wspeed)_({reference_ht_regex})(_\[m_s\])?)|(u({reference_ht_regex})_(wsp)_({reference_ht_regex})(_\[m_s\])?))|((ws)_({reference_ht_regex})(_({parallel_regex}))?_(mean|sd|min|max)_\[m_s\]))"    
    wd_regex = f"(((wd|wdir)_({reference_ht_regex})(_\[(°|_)\])?)|(u({reference_ht_regex})_(dir)_({reference_ht_regex})(_\[(°|_)\])?)|((wd)_({reference_ht_regex})(_({parallel_regex}))?_mean_\[(°|_)\]))"    
    
    vws_regex = f"(vws)_({reference_ht_regex})(_({parallel_regex}))?_mean_\[m_s\]"
    t_regex = f"(t)_({reference_ht_regex})(_({parallel_regex}))?_mean_\[(°|_)c\]"
    ti_regex = f"(ws|speed|wspeed|wsp)_({reference_ht_regex})(_({parallel_regex}))?_(ti)"
    ad_regex = f"(ad)_({reference_ht_regex})(_({parallel_regex}))?_mean_\[kg_m3\]"
    rh_regex = f"(rh)_({reference_ht_regex})(_({parallel_regex}))?_mean_\[%\]"
    p_mbar_regex =  f"(p)_({reference_ht_regex})(_({parallel_regex}))?_mean_\[mbar\]"
    p_kpa_regex =  f"(p)_({reference_ht_regex})(_({parallel_regex}))?_mean_\[kpa\]"
    p_hpa_regex =  f"(p)_({reference_ht_regex})(_({parallel_regex}))?_mean_\[hpa\]"
    p_pa_regex =  f"(p)_({reference_ht_regex})(_({parallel_regex}))?_mean_\[pa\]"
    p_atm_regex =  f"(p)_({reference_ht_regex})(_({parallel_regex}))?_mean_\[atm\]"
    p_hg_regex =  f"(p)_({reference_ht_regex})(_({parallel_regex}))?_mean_\[hg\]"
    p_psi_regex =  f"(p)_({reference_ht_regex})(_({parallel_regex}))?_mean_\[psi\]"

    excluded_columns = "No columns were excluded"
    excluded_regex = f"^{ws_regex}|({vws_regex})|{wd_regex}|({t_regex})|({ti_regex})|({ad_regex})|({rh_regex})|({p_mbar_regex})|({p_kpa_regex})|({p_hpa_regex})|({p_pa_regex})|({p_atm_regex})|({p_hg_regex})|({p_psi_regex})$"
    if api_need == "add":
        excluded_columns = isexcluded(input_file,excluded_regex)

    ws = criteria_range2(input_file=input_file,regex=f"^{ws_regex}$",minimum=0,maximum=100)
    wd = criteria_range2(input_file=input_file,regex=f"^{wd_regex}$",minimum=0,maximum=360)
    vws = criteria_range2(input_file=input_file,regex=f"^{vws_regex}$",minimum=-50,maximum=50)
    t = criteria_range2(input_file=input_file,regex=f"^{t_regex}$",minimum=-50,maximum=70)
    ti = criteria_range2(input_file=input_file,regex=f"^{ti_regex}$",minimum=0,maximum=1)
    ad = criteria_range2(input_file=input_file,regex=f"^{ad_regex}$",minimum=0.5,maximum=2)
    rh = criteria_range2(input_file=input_file,regex=f"^{rh_regex}$",minimum=0,maximum=120)
    p_mbar = criteria_range2(input_file=input_file,regex=f"^{p_mbar_regex}$",minimum=-600,maximum=1800)
    p_kpa = criteria_range2(input_file=input_file,regex=f"^{p_kpa_regex}$",minimum=-60,maximum=180)
    p_hpa = criteria_range2(input_file=input_file,regex=f"^{p_hpa_regex}$",minimum=-600,maximum=1800)
    p_pa = criteria_range2(input_file=input_file,regex=f"^{p_pa_regex}$",minimum=-60000,maximum=180000)
    p_atm = criteria_range2(input_file=input_file,regex=f"^{p_atm_regex}$",minimum=-0.592,maximum=1.777)
    p_hg = criteria_range2(input_file=input_file,regex=f"^{p_hg_regex}$",minimum=-17.718,maximum=53.154)
    p_psi = criteria_range2(input_file=input_file,regex=f"^{p_psi_regex}$",minimum=-8.702,maximum=26.107)
    
    print(input_file.filter(regex=ti_regex))
    if len(ws) > 0:
        return {"Status":"Invalid File","message":f"You've uploaded a text file with out of bound value in the column(s) {formated(ws)}, whereas the application expects WS Sensor(s) in range 0 to 100 [m/s]. Please upload a text file containing proper bounds.","filename":filename_ind}
    if len(wd) > 0:
        return {"Status":"Invalid File","message":f"You've uploaded a text file with out of bound value in the column(s) {formated(wd)}, whereas the application expects WD Sensor(s) in range 0 to 360 [°]. Please upload a text file containing proper bounds.","filename":filename_ind}
    if len(vws) > 0:
        return {"Status":"Invalid File","message":f"You've uploaded a text file with out of bound value in the column(s) {formated(vws)}, whereas the application expects VWS Sensor(s) in range -50 to 50 [m/s]. Please upload a text file containing proper bounds.","filename":filename_ind}
    if len(t) > 0:
        return {"Status":"Invalid File","message":f"You've uploaded a text file with out of bound value in the column(s) {formated(t)}, whereas the application expects T Sensor(s) in range -50 to 70 [°C]. Please upload a text file containing proper bounds.","filename":filename_ind}
    if len(ti) > 0:
        return {"Status":"Invalid File","message":f"You've uploaded a text file with out of bound value in the column(s) {formated(ti)}, whereas the application expects TI Sensor(s) in range 0 to 1. Please upload a text file containing proper bounds.","filename":filename_ind}
    if len(ad) > 0:
        return {"Status":"Invalid File","message":f"You've uploaded a text file with out of bound value in the column(s) {formated(ad)}, whereas the application expects AD Sensor(s) in range 0.5 to 2 [kg/m3]. Please upload a text file containing proper bounds.","filename":filename_ind}
    if len(rh) > 0:
        return {"Status":"Invalid File","message":f"You've uploaded a text file with out of bound value in the column(s) {formated(rh)}, whereas the application expects RH Sensor(s) in range 0 to 120 [%]. Please upload a text file containing proper bounds.","filename":filename_ind}
    if len(p_mbar) > 0:
        return {"Status":"Invalid File","message":f"You've uploaded a text file with out of bound value in the column(s) {formated(p_mbar)}, whereas the application expects P Sensor(s) in range -600 to 1800 [mbar]. Please upload a text file containing proper bounds.","filename":filename_ind}
    if len(p_kpa) > 0:
        return {"Status":"Invalid File","message":f"You've uploaded a text file with out of bound value in the column(s) {formated(p_kpa)}, whereas the application expects P Sensor(s) in range -60 to 180 [kPa]. Please upload a text file containing proper bounds.","filename":filename_ind}
    if len(p_hpa) > 0:
        return {"Status":"Invalid File","message":f"You've uploaded a text file with out of bound value in the column(s) {formated(p_hpa)}, whereas the application expects P Sensor(s) in range -600 to 1800 [hPa]. Please upload a text file containing proper bounds.","filename":filename_ind}
    if len(p_pa) > 0:
        return {"Status":"Invalid File","message":f"You've uploaded a text file with out of bound value in the column(s) {formated(p_pa)}, whereas the application expects P Sensor(s) in range -60000 to 180000 [Pa]. Please upload a text file containing proper bounds.","filename":filename_ind}
    if len(p_atm) > 0:
        return {"Status":"Invalid File","message":f"You've uploaded a text file with out of bound value in the column(s) {formated(p_atm)}, whereas the application expects P Sensor(s) in range -0.592 to 1.777 [atm]. Please upload a text file containing proper bounds.","filename":filename_ind}
    if len(p_hg) > 0:
        return {"Status":"Invalid File","message":f"You've uploaded a text file with out of bound value in the column(s) {formated(p_hg)}, whereas the application expects P Sensor(s) in range -17.718 to 53.154 [Hg]. Please upload a text file containing proper bounds.","filename":filename_ind}
    if len(p_psi) > 0:
        return {"Status":"Invalid File","message":f"You've uploaded a text file with out of bound value in the column(s) {formated(p_psi)}, whereas the application expects P Sensor(s) in range -8.702 to 26.107 [psi]. Please upload a text file containing proper bounds.","filename":filename_ind}
    return excluded_columns



def additional_overlaping_verifications(s3, email, ltt_ref_zip_file, dir_name, local_file_name):
    
    try:
        s3.download_file(environ.get("AWS_S3_BUCKET"), ltt_ref_zip_file, local_file_name)
    except:
        return {"message":"File Does not exists in s3"}
    print(local_file_name)
    try:
        with zipfile.ZipFile(local_file_name, 'r') as zip_ref:
            zip_ref.extractall(dir_name)
    except Exception as error:
        print(error)
        if os.path.exists:
            os.remove(local_file_name)  
        return {"Status":"Invalid File","message":"File is not a zip file"}

    files = []
    for file in os.listdir(f"{dir_name}"):
        if file.endswith(".txt"):
            files.append(file)        

    if len(files) == 0:
            return {"Status":"Invalid File","message":"You've uploaded a zip file which doesn't contain .txt files, whereas the application expects the zip file to consist of .txt files. Please upload the LTT reference file containing .txt files."}
        
    file_data = []
    for f in range(0,len(files)):
        filename = f'{dir_name}/{files[f]}'
        filename_ind = f"{files[f]}"
        file_data.append(ltt_text_file_preprocess_for_additional_checks(filename, filename_ind))

         
    return [file_data, files]


def ltt_text_file_preprocess_for_additional_checks(data, filename_ind):
    try:
        file_path = data
        # file_path = os.path.abspath(data)
        y,isdate = read_data(file_path)
        input_file = pd.read_csv(file_path, sep="\t", skiprows=y - 1, encoding='ISO-8859-1', low_memory=False).clean_names().remove_empty()
                
        first_column = pd.to_datetime(input_file["date_time"].iloc[0])
        last_column = pd.to_datetime(input_file["date_time"].iloc[-1])

        return {"Status":"Valid File",
        "filename":filename_ind,
        "start_year":first_column.strftime('%Y'),
        "end_year":last_column.strftime('%Y')
        }
    
    except Exception as e:
        print(e)
        return {"Status":"Invalid File","message":"You've uploaded a text file which is not valid. The application expects text file that have metadata containing latitude, longitude and elevation, followed by column headers: Date/Time, ws and wd columns and then the data. Please upload a proper text file.","filename":filename_ind}

def latlong_preproces(file_path,y,sn,isdate,filename_ind):
    
    meta_data = pd.read_csv(file_path, sep='delimiter',header = None,skip_blank_lines=True,engine='python',nrows=y-1,encoding='ISO-8859-1')
       
    try:
        latindex = meta_data[0].loc[lambda x: x.str.contains("Latitude")].index
    except:
        latindex = 0
    try:
        longindex = meta_data[0].loc[lambda x: x.str.contains("Longitude")].index
    except: 
        longindex = 0
    try:
        elevationindex = meta_data[0].loc[lambda x: x.str.contains("Elevation")].index
    except:
        elevationindex = 0
    validation1 = missing_columns(latindex,longindex,elevationindex,isdate,filename_ind)
    if validation1 != 0:
        return validation1

    latitude = meta_data.loc[latindex].values
    longitude = meta_data.loc[longindex].values
    elevation = meta_data.loc[elevationindex].values
    latitude = "".join(list(chain(*latitude))).split("=")[1]
    longitude = "".join(list(chain(*longitude))).split("=")[1]
    elevation = "".join(list(chain(*elevation))).split("=")[1].strip(" ")
    latformat = 1  
    validation2 = validate_latlong(latitude,longitude,latformat,filename_ind)
    return [validation2,elevation]




# Old file's latitude and longitude validation with new file's latitude and longitude #
def validate_latlong_oldfile_newfile(old_file_lat, old_file_long, new_file_lat, new_file_long, filename_ind):

    if old_file_lat == new_file_lat and old_file_long == new_file_long:
        return True
    
    return {"Status":"Invalid File","message":"You've uploaded a text file with invalid coordinates. The application expects text file that have metadata containing latitude, longitude and elevation, followed by column headers: Date/Time, ws and wd columns and then the data. Please upload a proper text file.","filename":filename_ind}
