from sqlalchemy import text
from db.queries import *
from routes import *
import re
import requests
import os
import tempfile
import pandas as pd
import pyarrow.feather as feather
import random
import csv


#######################################
##
## NEW ANALYSIS DATA
##
#######################################


def analysis_new_data(analysis_id):
               
    temp = tempfile.NamedTemporaryFile()

    with db.connect() as conn:
      results = conn.execute(text(analysis_data_new_query), analysis_id=analysis_id).fetchall()
      conn.close()
    
#     if not results or not status:
#         return {"message": "analysis does not exists"}, 404

        
    analysis = results
    prsids = []
    titleset = []
    final = []
    measure = []
    timestamps = []

    if results is None:
        return {"message":"This analysis id does not exists in db"},200

    for i,value in enumerate(analysis):
        prsids.append(value[0])
        titleset.append(value[1])

    #this condn was also there in plumber code
    if prsids is None:
        return "",200

    for i in prsids:

        #for final data 
        with db.connect() as conn:
            feather_url = conn.execute(text(analysis_data_new_query_feather), process_id=i).fetchall()
            conn.close()
        
        if feather_url[0][1] is not None:
            s3 = boto3.resource('s3')
            s3.Bucket('windvista-dev').download_file(feather_url[0][1],"raw.txt")
        
            with open("raw.txt", "r",encoding = "ISO-8859-1") as file:
                tsv_file = csv.reader(file, delimiter="\t")
                y = 0
                for line in tsv_file:
                    y += 1
                    if 'Date/Time' in line:
                        break

            input_file = pd.read_csv("raw.txt", sep="\t", skiprows=y - 1, encoding='ISO-8859-1')
            windata_mean = input_file.clean_names().remove_empty()
            
            df = pd.DataFrame(windata_mean)
            first_column = pd.to_datetime(df["date_time"].iloc[0]).strftime('%Y-%m-%d %H:%M:%S')
            last_column = pd.to_datetime(df["date_time"].iloc[-1]).strftime('%Y-%m-%d %H:%M:%S')

            os.remove("raw.txt")
            timestamps.append({"Start timestamp":first_column,"End Timestamp":last_column})

        if feather_url[0][0] is not None:
            s3 = boto3.resource('s3')
            s3.Bucket('windvista-dev').download_file(feather_url[0][0], temp.name)
            x = feather.read_feather(temp.name)
            final.append(x.to_dict('records'))
        
        else:
            with db.connect() as conn:
                feather_url = conn.execute(text(final_approach_query),process_id=i).fetchone()
            
            if feather_url is None:
                return {"message": "Given process id does not exists"}, 404
            ltt_imp_adj = feather_url[0]
            shear_feather = feather_url[1]
            user =  feather_url[2]
        
            if ltt_imp_adj=="NA" or ltt_imp_adj=="NaN %" or ltt_imp_adj is None or shear_feather=="NA" or shear_feather is None:
                final.append({"message":"file not found"})
            
            else:
                boto3.client('s3').download_file('windvista-dev', shear_feather, temp.name)
                data = feather.read_feather(temp.name)

                ltt_analysis = float(ltt_imp_adj.strip("%"))  
                
                if ltt_analysis >= 0:
                    ltt_analysis_2 = (ltt_analysis / 100) + 1
                
                elif ltt_analysis < 0:
                    ltt_analysis_2 = 1 - (abs(ltt_analysis) / 100)

                shear_analysis = pd.DataFrame(data)
                shear_analysis = shear_analysis.loc[shear_analysis['Combinations'] == shear_analysis["Combinations"].unique()[0]]
                final_approach = shear_analysis
                final_approach["final"] = ((shear_analysis['Prediction']).astype(float))*ltt_analysis_2
                final_approach["final"] = final_approach["final"].apply("{:,.3f}".format)
                
                final_data = final_approach.filter(['Height','final'], axis=1)
                final_data.rename(columns = {'Height':'height'}, inplace = True)

                obj = f"{user}/{i}/final/final_approach.feather"
                
                filename_feather = f"final_approach_{user}_{i}_{random.randint(1,1000)}.feather"
                feather.write_feather(final_data,filename_feather,version=1)

                # for feather upload
                response =  boto3.client('s3').generate_presigned_post('windvista-dev',obj,Fields=None,Conditions=None,ExpiresIn=3600)
                with open(filename_feather, 'rb') as f:
                    files = {'file': (filename_feather, f)}
                    http_response = requests.post(response['url'], data=response['fields'], files=files)

                final_feather_status_key = obj
            
                with db.connect() as conn:
                    conn.execute(text(final_approach_update_query),final_feather_status_key=final_feather_status_key, process_id=i)
                
                os.remove(filename_feather)
            
                final.append(final_data.to_dict(orient="records"))

        #for Measurement details data
        with db.connect() as conn:
            measurement_url = conn.execute(text(measurement_details_query), process_id=i).fetchone()
        
        if measurement_url is not None:
        
            if measurement_url[0]=="NA" or measurement_url[0]=="NaN" or measurement_url[0] is None:
                measure.append("file not found")
            
            else:
                boto3.client('s3').download_file('windvista-dev', measurement_url[0], temp.name)
                measure_data = feather.read_feather(temp.name)
                measure.append(measure_data.to_dict(orient="records"))

        else:
            measure.append("file not found")

    final_table = pd.DataFrame({'prsID': prsids,'title': titleset,'final': final, 'measure':measure,"timestamp":timestamps})

    return final_table.to_dict('records'),200
        

        

#######################################
##
## UNARCHIVE ANALYSIS
##
#######################################


def uarchive_analysis(anlysID, timestamp):

    status = None
    # checking if analysis exists or not

    try:
        with db.connect() as conn:
            analysis = conn.execute(text(select_analys_query), anlysID=anlysID).fetchone()
            status = conn.execute(text(status_archive_or_not), anlysID=anlysID ).fetchone()[0]
            conn.close()
        
    except:
        status = None
        
    if not analysis or not status:
        return {"message": "analysis does not exists"}, 404

    if "archived" == status:
        with db.connect() as conn:
            conn.execute(text(unarchive_analysis_query), timestamp=timestamp, anlysID=anlysID)
            conn.close()

        return {"message": "analysis unarchived"},200

    if "active" == status:
        with db.connect() as conn:
            conn.execute(text(archive_analysis_query), timestamp=timestamp, anlysID=anlysID)
            conn.close()
        return {"message": "analysis archived"},200



#######################################
##
## NEW ANALYSIS
##
#######################################


def new_analysis(project_id, title, description, user, timestamp):

    if len(title) < 3 or len(title) > 40:
        return {"message":"New Analysis title's character length should always between 3 to 40."}, 200

    if len(description) < 1 or len(description) > 400:
            return {"message":"New Analysis description's character length should always between 1 to 400."},200

    if project_id == 0:
        return {"message":"please enter correct project id it should not be negative or zero"}
    
    data = []

    with db.connect() as conn:
            res = conn.execute(text(new_analysis_query), user = user).fetchone()
            if res is None:
                return {"message":"Given Username Does Not Exists"},200
            userid = res[0]
            conn.close()

    userID1 = userid
    title1 = title
    mast1 = 0
    lidar1 = 0

    with db.connect() as conn:
        result = conn.execute(text(new_analysis_query2), userid = userID1,projectid = project_id).fetchall()
        data = [dict(row) for row in result]
        conn.close()

    print(userID1)
    print(result)
    
    if any(d['title'] == title for d in data):
        return {"message":"Title already exists"},200
    
    with db.connect() as conn:
        conn.execute(text(insert_new_analysis),projectid = project_id, title = title, description = description, userid = userID1, masts = mast1, lidars = lidar1,timestamp = timestamp)
        analysis_id = conn.execute(text(select_max_analysis_id_query)).fetchone()
        analysis_id = analysis_id[0]
        conn.close()

    return analysis_id,200


#######################################
##
## PUBLISH ANALYSIS
##
#######################################


def publish(analysis_id):

    try:

        with db.connect() as conn:
            result = conn.execute(text(publish_analysis_query), analysisid = analysis_id).fetchone()
            print(result)
            results = result[0]
            conn.close()

    except:
        status = None

    if not analysis_id or not status:
        return {"message": "analysis does not exists"}, 404
      
    if results=="published":
        return {"message":"Analysis Already Published"},200

    with db.connect() as conn:
        conn.execute(text(insert_publish_analysis), analysisid=analysis_id)
        conn.close()
        
    #publish count
    with db.connect() as conn:
        project_id = conn.execute(text(publish_analysis_processid_query),analysisid=analysis_id).fetchone()[0]

    with db.connect() as conn:
        ini_count = conn.execute(text(publish_count_query),project_id=project_id).fetchone()[0]
        print(ini_count)
        ini_count += 1
        conn.execute(text(update_publish_analysis_query),ini_count=ini_count, project_id=project_id)

    return {"message":"Analysis Published"},200


#######################################
##
## SHOW ANALYSIS ARCHIVE
##
#######################################


def show_analysis_archive(project_id):

    # global variable scope
    project_title = None
    project_desc = None
    project_location = None

    with db.connect() as conn:
        data = []
        results = conn.execute(text(show_analysis_archived_query), project_id=project_id).fetchall()
        project_ = conn.execute(text(select_windvista_prject_query), project_id=project_id).fetchall()
        conn.close()
        
        
    for row in project_:
        project_title = row[0]
        project_desc = row[1]
        project_location = row[2]
            
    data = [dict(row) for row in results]

    project_data = {
        "project_title": project_title,
        "project_description": project_desc,
        "project_location": project_location,
        "project_id": project_id
    }

    return {"project data":project_data, "data":data},200


#######################################
##
## SHOW ANALYSIS
##
#######################################


def show_analysis(project_id, email):

    # global variable scope
    project_title = None
    project_desc = None
    project_location = None
    shared_status = None

    with db.connect() as conn:
        data = []
        results = conn.execute(text(show_analysis_query), project_id=project_id).fetchall()
        project_ = conn.execute(text(select_windvista_prject_query), project_id=project_id).fetchall()
        conn.close()

    for row in project_:
        project_title = row[0]
        project_desc = row[1]
        project_location = row[2]
        shared_status = row[3]
        userid = row[4]
    data = [dict(row) for row in results]

    with db.connect() as conn:
        username = conn.execute(text(user_name_from_userid), user_id=userid).fetchone()
    username = username[0]

    if email==username:
        shared_status = "active"
        
    project_data = {
        "project_title": project_title,
        "project_description": project_desc,
        "project_location": project_location,
        "project_id": project_id,
        "shared_status": shared_status
    }
   
    return {"project data":project_data, "data":data},200
