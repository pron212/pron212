from sqlalchemy import lambda_stmt
from workers.worker2 import worker2
from services.systems_services import *
import concurrent.futures




#################################
##
## FINAL DOWNLOAD FILE FUNCTION
##
#################################


# services.systems_services #
@worker2.task(name = "final_download_file")
def final_download_file(email, timestamp, process_id):

    random_number = random.randint(100,10000)
    
    with db.connect() as conn:
        data = conn.execute(text(final_download_file_query), processid=process_id).fetchone()

    if data is None:
        return {"message":"Incorrect process id"},200
    
    analysisid = data[4]

    try:
        with db.connect() as conn:
            ltt_ref_uploaded_key = conn.execute(text(final_download_file_query2), analysis_id=analysisid).fetchone()[0]
    except:
        ltt_ref_uploaded_key = None

    txtkey = data[0]
    windoscope_download = data[1]
    shear_download = data[2]
    ltt_download = data[3]
    #main directory
    
    try:
        first_time = timestamp
        give_time = first_time
        if len(give_time)>7:
            give_time = int(first_time[:-3])    
        systemTime = datetime.datetime.fromtimestamp(int(give_time)).strftime('%Y-%m-%d') 
    except:
        return {"message":"Please enter correct timestamop"},200
    dt_obj = systemTime
    try:
        with db.connect() as conn:
            system_name = conn.execute(text(final_download_file_query3), processid=process_id).fetchone()[0]
    except:
        return {"message":"system does not exists"},200
    
    system_name = re.sub('\.txt$', '', system_name)
    system_name = re.sub('\-Exported$', '', system_name)
    system_name = system_name.replace(' ','-')
    system_name = system_name.replace('_','-')
    print(system_name)
    
    main_folder = f"{system_name}-WindVista-Outputs_{dt_obj}"
    main_folder_upload = main_folder+".zip"
    os.mkdir(main_folder)
    
    #Folder naming convention
    Folder_Name1 = "Input-Data"
    Folder_Name2 = "Wind-Measurement-Plots-and-Tables"
    Folder_Name3 = "Shear-Analysis"
    Folder_Name4 = "Long-Term-Analysis"
    Folder_Name5 = "Overall-Results"

    os.mkdir(Folder_Name1)
    os.mkdir(Folder_Name3)
    os.mkdir(Folder_Name4)
    os.mkdir(Folder_Name5)

    #under Folder_Name1
    Input_Text_File = txtkey
    Input_Text_File_Name = "inputs.txt"
    input_text_folder_name = "Input-Text-File"
    os.mkdir(input_text_folder_name)
    shutil.move(input_text_folder_name, Folder_Name1)

    Climate_data_File = ltt_ref_uploaded_key
    Climate_data_File_Name = f"Climate_data_File{random_number}.zip"
    climate_file_folder_name = "Climate-File"
    os.mkdir(climate_file_folder_name)
    shutil.move(climate_file_folder_name, Folder_Name1)

    #under Folder_Name2
    Wind_Measurement_File = windoscope_download
    Wind_Measurement_File_Name = f"Wind_Measurement_File_plots{random_number}.zip"

    #under Folder_Name3
    shear_analysis_File = shear_download
    shear_analysis_File_Name = f"shear_analysis_File{random_number}.zip"
    

    #under Folder_Name4
    ltt_analysis_File = ltt_download
    ltt_analysis_File_Name = f"ltt_analysis_File{random_number}.zip"

    shutil.move(Folder_Name1, main_folder)
    shutil.move(Folder_Name3, main_folder)
    shutil.move(Folder_Name4, main_folder)
    shutil.move(Folder_Name5, main_folder)
    

    # Downloading all the files parallelly #
    with concurrent.futures.ThreadPoolExecutor() as executor:

        # Thread to download folder1 files #
        executor.submit( lambda: download_final_files(folder_tag="Folder 1", main_folder=main_folder, folder_name=Folder_Name1, input_text_folder_name=input_text_folder_name, input_text_file_name=Input_Text_File_Name, input_text_file=Input_Text_File, climate_data_File=Climate_data_File, climate_file_folder_name=climate_file_folder_name, climate_data_file_name=Climate_data_File_Name))

        # Thread to download folder2 files #
        executor.submit( lambda: download_final_files(folder_tag="Folder 2", main_folder=main_folder, folder_name=Folder_Name2, wind_measurement_file=Wind_Measurement_File, wind_measurement_file_name=Wind_Measurement_File_Name, ))
        
        # Thread to download folder3 files #
        executor.submit( lambda: download_final_files(folder_tag="Folder 3", main_folder=main_folder, folder_name=Folder_Name3, file_txt_key=shear_analysis_File, downloaded_file_name=shear_analysis_File_Name))
       
        # Thread to download folder4 files #
        executor.submit( lambda: download_final_files(folder_tag="Folder 4", main_folder=main_folder, folder_name=Folder_Name4, file_txt_key=ltt_analysis_File, downloaded_file_name=ltt_analysis_File_Name))


    output_filename = f"{email}_{random_number}{process_id}_final_data_file"
    shutil.make_archive(output_filename, 'zip', main_folder)
    
    
    # for zip file upload
    response = s3.generate_presigned_post('windvista-dev',output_filename,Fields=None,Conditions=None,ExpiresIn=3600)

    # Demonstrate how another Python program can use the presigned URL to upload a file
    output_filename_local = output_filename+".zip"
    with open(output_filename_local, 'rb') as f:
        files = {'file': (output_filename_local, f)}
        http_response = requests.post(response['url'], data=response['fields'], files=files)    


    url = s3.generate_presigned_url(
            ClientMethod='get_object', 
            ExpiresIn=300,
            Params={
                'Bucket': 'windvista-dev', 
                'Key': output_filename,
                'ResponseContentDisposition': 'attachment;filename={}'.format(main_folder_upload),
                'ResponseContentType': 'application/zip',

                }
    )

    short = pyshorteners.Shortener()
    download_url = short.tinyurl.short(url)


    if os.path.exists(output_filename_local):
        os.remove(output_filename_local)
    
    try:
        abs_path = os.path.abspath(main_folder)
        shutil.rmtree(abs_path)
    except Exception as error:
        print(error)
        try:
            os.rename(abs_path, "z")
            shutil.rmtree("z")
        except Exception as e:
            print(e)

    return {"url":f"{download_url}"}






##############################
##
## SHOW PROJECT CLASS
##
##############################


# services.project_service #
@worker2.task(name='show_project')
def show_project(user):

    # global varaible scope
    user_id = None
    
    # getting the userid checking if user already exists 
    # if exists return the user id
    # if not creating a new user

    with db.connect() as conn:
        user1 = conn.execute(text(user_id_username_query),user=user).fetchone()
        if user1 is not None:
            for userid in user1:
                user_id = userid
        else:
            conn.execute(text(insert_user_query),user=user)
            # return {"message": "The given email id does not exists"}
            # once user is created getting new user id
            with db.connect() as conn:
                user1 = conn.execute(text(user_id_username_query),user=user).fetchone()
                if user1 is not None:
                    for userid in user1:
                        user_id = userid
            
            return []

    data = []
    with db.connect() as conn:
        retsults = conn.execute(text(show_project_query), userID=user_id)
        data = [dict(row) for row in retsults]

    total_projects = len(data)
    threads = []

    # Getting Shared Users for every project by using Multi-Threading #
    with concurrent.futures.ThreadPoolExecutor() as executor:
        thread = executor.submit(get_projects_shared_users, data[0:total_projects//2])
        threads.append(thread)
        thread = executor.submit(get_projects_shared_users, data[total_projects//2:])
        threads.append(thread)

    data = []
    for thread in threads:
        data.extend(thread.result())

    return data
