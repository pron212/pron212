from workers.worker1 import worker1
from services.systems_services2 import *
from services.duplicate_project_service import duplicate_analysis_for_DuplicatingAProject




#####################################
##
## LTT REF UPLOADED BINARY FUNCTION
##
#####################################


# systems_services2.py #
@worker1.task(name='validate')
def ltt_text_file_preprocess_preload(name, email, api_need, primary_key):
        
    dir_name = ""
    s3 = boto3.client(
        's3', 
        aws_access_key_id=environ.get("AWS_ACCESS_KEY_ID") , 
        aws_secret_access_key=environ.get("AWS_SECRET_ACCESS_KEY"), 
        region_name="us-east-1"
        )
    s3R = boto3.resource(
        's3', 
        aws_access_key_id=environ.get("AWS_ACCESS_KEY_ID") , 
        aws_secret_access_key=environ.get("AWS_SECRET_ACCESS_KEY"), 
        region_name="us-east-1"
        )    
    try:
        dir_name = f"ltt_validate_{random.randint(1,100)}_{email}"
        random_number = random.randint(1,100)    
        local_file_name = f"ltt_downloadfile{random_number}.zip"
        
        try:
            s3.download_file(environ.get("AWS_S3_BUCKET"), name, local_file_name)
        except:
            return {"message":"File Does not exists in s3"}
        try:
            with zipfile.ZipFile(local_file_name, 'r') as zip_ref:
                zip_ref.extractall(dir_name)
        except Exception as error:
            print(error)
            return {"Status":"Invalid File","message":"File is not a zip file"}
        files = []
        for file in os.listdir(f"{dir_name}"):
            if file.endswith(".txt"):
                files.append(file)
        
        if len(files) == 0:
            return {"Status":"Invalid File","message":"You've uploaded a zip file which doesn't contain .txt files, whereas the application expects the zip file to consist of .txt files. Please upload the LTT reference file containing .txt files."}
        
        file_data = []
        timestamp_file_data = []
        for f in range(0,len(files)):
            filename = f'{dir_name}/{files[f]}'
            filename_ind = f"{files[f]}"
            file_data.append(ltt_text_file_preprocess(local_file_name,dir_name,filename, filename_ind, timestamp_file_data, api_need, primary_key=primary_key, email=email))
        
        
        try:
            #frequency validations  
            t_diff = []


            for i in timestamp_file_data:
                t_diff.append(i[2])
        
            t_diff_count = {}   
            for i in set(t_diff):
                c = t_diff.count(i)
                t_diff_count[c] = i
            
      
            max_occurance = max(list(t_diff_count))
            accepted_diff_val = t_diff_count[max_occurance]
            accepted_filenames = []
            for i in timestamp_file_data:
                if accepted_diff_val == i[2]:
                    accepted_filenames.append(i[3])
        
            accepted_diff_val = humanize.precisedelta(accepted_diff_val, minimum_unit="hours")
            
            for index in range(0, len(file_data)):
                if file_data[index]['Status'] == "Valid File":
                    if file_data[index]['filename'] not in accepted_filenames:
                       if "1 hour" not in accepted_diff_val and "6 hours" not in accepted_diff_val:
                            file_data[index] = {"Status":"Invalid File","message":f"You've uploaded a text file with invalid frequency, whereas the application accepts text file(s) with same frequency. Please upload a text file with {accepted_diff_val} of frequency.","filename":file_data[index]['filename']}

            
            def common_function_for_add_reupload(ltt_ref_zip_file):
                if ltt_ref_zip_file != None:
                    ltt_ref_zip_file = ltt_ref_zip_file[0]
                    dir_name = f"crosschecking{random.randint(100,1000)}_{email}"
                    random_number = random.randint(100,1000)    
                    local_file_name = f"crosschecking{random_number}.zip"

                    additional_return = additional_overlaping_verifications(s3, email, ltt_ref_zip_file, dir_name, local_file_name)
                    if os.path.exists:
                        shutil.rmtree(dir_name)    
                    if os.path.exists:
                        os.remove(local_file_name) 

                    additional_list = additional_return[0]
                    additional_filename = additional_return[1]
                    

                    additional_return_allyears = []
                    for i in additional_list:
                        additional_return_allyears.append({int(i['start_year']), int(i['end_year'])})

                    return [additional_list, additional_filename, additional_return_allyears]
            #overlaping validations
            if api_need == "add":
                with db.connect() as conn:
                    ltt_ref_zip_file = conn.execute(text(ltt_ref_zipfile_query), analysis_id=primary_key).fetchone()
                returned_val = common_function_for_add_reupload(ltt_ref_zip_file)
                additional_list = returned_val[0]
                additional_filename = returned_val[1]
                additional_return_allyears = returned_val[2]
                file_data.extend(additional_list)
                  
            if api_need == "reupload":
                with db.connect() as conn:
                    analysisid = conn.execute(text(authentication_systems3), process_id=primary_key).fetchone()
                    ltt_ref_zip_file = conn.execute(text(ltt_ref_zipfile_query), analysis_id=analysisid[0]).fetchone()
                print(analysisid)
                returned_val = common_function_for_add_reupload(ltt_ref_zip_file)
                additional_list = returned_val[0]
                additional_filename = returned_val[1]
                additional_return_allyears = returned_val[2]
                file_data.extend(additional_list)
            print(file_data)        
            valid_times = []
            all_v_times = []
            for i in file_data:
                start_end_times = []
                if i['Status'].lower() == "valid file":
                    start_end_times.append(int(i['start_year']))
                    start_end_times.append(int(i['end_year']))
                if len(start_end_times) == 2:
                    all_v_times.append(start_end_times)
                if len(start_end_times) == 2 and start_end_times not in valid_times:
                    valid_times.append(start_end_times)
            
           
            valid_times_count = {}
            for i in valid_times:
                valid_times_count[f'{i}'] = all_v_times.count(i)
            

            valid_times_copy = valid_times.copy()
            
                
            all_possible_overlaps = []
            #all possible overlaps
            for i in itertools.product(valid_times,valid_times):
                all_possible_overlaps.append(list(i))

            all_possible_overlaps = [i for i in all_possible_overlaps if set(i[0]) != set(i[1])]

            #non-overlaping
            non_overlaping = []
            for i in all_possible_overlaps:
                if not(i[0][0]<i[1][0]<i[0][1] or i[0][0]<i[1][1]<i[0][1] or i[1][0]<i[0][0]<i[1][1] or i[1][0]<i[0][1]<i[1][1]):
                    non_overlaping.append(i)
       
            non_overlaping_1 = []
            for i in non_overlaping:
                if [i[1], i[0]] not in non_overlaping_1:
                    non_overlaping_1.append(i)

           
            invalid_file_years_non_overlaping = []
            if api_need == "lttref":
                for i in non_overlaping_1:
                    if valid_times_count[f'{i[0]}'] >= valid_times_count[f'{i[1]}']:
                        invalid_file_years_non_overlaping.append(i[0])
                    else:
                        invalid_file_years_non_overlaping.append(i[1])  
            else:
                for i in non_overlaping_1:
                    if set(i[0]) not in additional_return_allyears:
                        invalid_file_years_non_overlaping.append(i[0])
                    else:
                        invalid_file_years_non_overlaping.append(i[1]) 
                
                file_data = [i for i in file_data if "Longitude" in i.keys()]
                
     
            for i in invalid_file_years_non_overlaping:
                for index in range(0, len(file_data)):
                    if int(file_data[index]['start_year']) == int(i[0]) and int(file_data[index]['end_year']) == int(i[1]):
                        file_data[index] = {"Status":"Invalid File","message":"You've uploaded a text file file with no overlapping time periods whereas the application expects an overlapping time period between all the uploaded input text files. Please upload text files with proper time periods.","filename":file_data[index]['filename']}
              
        except Exception as e:
            print(e)
            
        # Grouping all the invalid files together & all the valid files together #
        next_invalid_file_index = 0
        for fileIndex in range(len(file_data)):
            if file_data[fileIndex]["Status"] == "Invalid File":
                file_data[next_invalid_file_index], file_data[fileIndex] = file_data[fileIndex], file_data[next_invalid_file_index]
                next_invalid_file_index += 1
        
        return file_data

    except Exception as error:
        print(error)

    finally:
        if os.path.exists(dir_name):
            shutil.rmtree(dir_name)
        if os.path.exists(local_file_name):
            os.remove(local_file_name)
        if bool(list(s3R.Bucket(environ.get("AWS_S3_BUCKET")).objects.filter(Prefix=name))):    
            s3 = boto3.client('s3')
            s3.delete_object(Bucket=environ.get("AWS_S3_BUCKET"),Key=name)









#######################################
##
## DUPLICATE ANALYSIS
##
#######################################


@worker1.task(name='duplicate_analysis')
def duplicate(anlysID, timestamp, user):
        
    # global variable for analysis
    ltt_ref_filename_feather = None
    feather_process = None
    new_process_id = None
    prsid = None
    analysisid = None
    projectid = None
    title = None
    description = None
    userID = None
    masts = None
    lidars = None
    published = None
    in_progress = None

    if len(user) < 3 or len(user) > 40:
        return {"message":"Duplicate Analysis title's charecter length should always range between 3 to 40."},200

    # global variables for  ltt_reference
    ltt_username = None
    ltt_ref_uploaded_key = None
    ltt_ref_filename = None
    final_rds_new = None
    measure_rds_new = None
    shear_rds_new = None
    comb_shear_new = None
    ltt_depth_analysis_new = None
    windoscope_download_new = None
    shear_download_new = None
    ltt_download_new = None
    winddata_new = None
    tempraw_new = None
    cbox_new = None
    shear_feather_new = None
    measure_feather_new = None
    final_feather_new = None

    txt_key_new = None
    txt_key_url = None

    # global variable for processed_systems_unreg
    processed_systems_timpestamp = None
    processed_systems_systemType = None
    processed_systems_title = None
    processed_systems_sourcefrom = None
    processed_systems_txtKey = None
    processed_systems_txturl = None
    processed_systems_filename = None
    processed_systems_process_status = None
    processed_systems_final_feather = None
    processed_systems_user = None
    processed_systems_measure_feather = None
    processed_systems_shear_feather = None
    processed_systems_comb_shear = None
    processed_systems_Target_height = None
    processed_systems_Anemo_name = None
    processed_systems_ltt_process_status = None
    processed_systems_ltt_imp_adj = None
    processed_systems_ltt_depth_analysis = None
    processed_systems_windoscope_download = None
    processed_systems_shear_download = None
    processed_systems_ltt_download = None
    processed_systems_windoscope_process = None
    processed_systems_winddata = None
    processed_systems_tempraw = None
    processed_systems_tempraw_status = None
    processed_systems_cbox_data = None
    feather_conversion_shear_status = None
    shear_feather = None
    Direction_name = None
    measure_feather = None
    final_feather = None

    # checking if analysis exists or not
    with db.connect() as conn:
        analysis = conn.execute(text(select_analys_query), anlysID=anlysID).fetchall()
        conn.close()

        if len(analysis) == 0:
            return {"message": "analysis does not exists"}
        
        else:
            for row in analysis:
                projectid = row[1]
                title = row[2]
                description = row[3]
                userID = row[4]
                masts = row[5]
                lidars = row[6]

    # checking if given user title is already present
    if user.lower() == title.lower():
        return {"message": "title already exists"}

    # getting maximum analysis id
    with db.connect() as conn:
        newid = conn.execute(select_max_analysis_id_query).fetchone()
        conn.close()
        for row in newid:
            analysisid = row

    # incrementing that analysis by one 
    new_analysis_id = analysisid + 1

    with db.connect() as conn:
        conn.execute(text(duplicate_analysis_insert_query), new_analysis_id=new_analysis_id, projectid=projectid, title=user, description=description, userID=userID, masts=masts, lidars=lidars, timestamp=timestamp, anlysID=anlysID)
        conn.close()
        
    # getting all aws ltt ref files from analysis
    with db.connect() as conn:
        ltt_analysis = conn.execute(text(select_ltt_ref_file_query), anlysID=anlysID).fetchall()
        conn.close()
        
        if ltt_analysis is not None:
        
            if len(ltt_analysis) == 0:
                return {"message": "ltt analysis does not exists"}
        
            else:
        
                for row in ltt_analysis:
                    print(row)
                    ltt_username = row[2]
                    ltt_ref_uploaded_key = row[4]
                    ltt_ref_filename = row[5]
                    ltt_ref_filename_feather = row[6]
                    feather_process = row[7]

        else:
            return {"message": "ltt analysis does not exists"}

    print(ltt_ref_uploaded_key)

    if ltt_ref_uploaded_key in ["NA", None]:
        ltt_ref_uploaded_key_new = ltt_ref_uploaded_key
    
    else:
        ltt_ref_uploaded_key_new = re.sub("\d+", str(new_analysis_id), ltt_ref_uploaded_key)
    
        # ltt_ref_s3 upload
        copy_source = {'Bucket': 'windvista-dev', 'Key': str(ltt_ref_uploaded_key)}
        s3.copy_object(CopySource = copy_source, Bucket = 'windvista-dev', Key = str(ltt_ref_uploaded_key_new))

    if ltt_ref_filename in ['NA', None]:
        ltt_ref_filename_new = ltt_ref_filename
    
    else:
        ltt_ref_filename_new = re.sub("\d+", str(new_analysis_id), ltt_ref_filename)

        # ltt_ref_s3 upload
        copy_source = {'Bucket': 'windvista-dev', 'Key': str(ltt_ref_filename)}
        s3.copy_object(CopySource = copy_source, Bucket = 'windvista-dev', Key = str(ltt_ref_filename_new))
        
    if ltt_ref_filename_feather in ['NA', None]:
        ltt_ref_filename_feather_new = ltt_ref_filename_feather
    
    else:
        ltt_ref_filename_feather_new = re.sub("\d+", str(new_analysis_id), ltt_ref_filename_feather)

        # ltt_ref_s3 upload
        copy_source = {'Bucket': 'windvista-dev', 'Key': str(ltt_ref_filename_feather)}
        s3.copy_object(CopySource = copy_source, Bucket = 'windvista-dev', Key = str(ltt_ref_filename_feather_new))

    # insert all the reuploaded file
    with db.connect() as conn:
        conn.execute(text(insert_ltt_ref_files_query), new_analysis_id=new_analysis_id, ltt_username=ltt_username, timestamp=timestamp, ltt_ref_uploaded_key_new=ltt_ref_uploaded_key_new, ltt_ref_filename_new=ltt_ref_filename_new, ltt_ref_filename_feather_new=ltt_ref_filename_feather_new, feather_process=feather_process)
        conn.close()

    # new_processed id
    with db.connect() as conn:
        result = conn.execute(select_max_prsid_query).fetchone()[0]
        prsid = result

    new_process_id = prsid + 1

    print(new_process_id)

    with db.connect() as conn:
        processed_systems_unreg = conn.execute(text(select_proc_sys_unreg_query), anlysID=anlysID).fetchall()
        print(len(processed_systems_unreg))
        conn.close()
        
        if processed_systems_unreg is not None:
        
            if len(processed_systems_unreg) == 0:
                print("processed_systems_unreg analysis does not exists")
        
            else:
                
                for row in processed_systems_unreg:
                    processed_systems_timpestamp = row[2]
                    processed_systems_systemType = row[3]
                    processed_systems_title = row[4]
                    processed_systems_sourcefrom = row[5]
                    processed_systems_txtKey = row[6]
                    processed_systems_txturl = row[7]
                    processed_systems_filename = row[8]
                    processed_systems_process_status = row[9]
                    processed_systems_user = row[11]
                    processed_systems_comb_shear = row[14]
                    processed_systems_Target_height = row[15]
                    processed_systems_Anemo_name = row[16]
                    processed_systems_ltt_process_status = row[17]
                    processed_systems_ltt_imp_adj = row[18]
                    processed_systems_ltt_depth_analysis = row[19]
                    processed_systems_windoscope_download = row[20]
                    processed_systems_shear_download = row[21]
                    processed_systems_ltt_download = row[22]
                    processed_systems_windoscope_process = row[23]
                    processed_systems_winddata = row[24]
                    processed_systems_tempraw_status = row[25]
                    processed_systems_cbox_data = row[26]
                    shear_feather = row[27]
                    Direction_name = row[28]
                    measure_feather = row[29]
                    final_feather = row[30]

                    if processed_systems_txtKey in ['NA', None]:
                        txt_key_new = processed_systems_txtKey
                    
                    else:
                        txt_key_new = re.sub("\d+", str(new_process_id), processed_systems_txtKey)

                        # ltt_ref_s3 upload
                        copy_source = {'Bucket': 'windvista-dev', 'Key': str(processed_systems_txtKey)}
                        s3.copy_object(CopySource = copy_source, Bucket = 'windvista-dev', Key = str(txt_key_new))
                    
                    if processed_systems_txturl in ['NA', None]:
                        txt_key_url = processed_systems_txturl
                    
                    else:
                        print(processed_systems_txturl)
                        new_name = processed_systems_txturl.replace("https://windvista-dev.s3.amazonaws.com/",'')
                        txt_key_url = re.sub("\d+", str(new_process_id), new_name)
                        # txt_key_url= f"https://windvista-dev.s3.amazonaws.com/{abx}"

                        # ltt_ref_s3 upload
                        copy_source = {'Bucket': 'windvista-dev', 'Key': str(new_name)}
                        s3.copy_object(CopySource = copy_source, Bucket = 'windvista-dev', Key = str(txt_key_url))

                    if processed_systems_comb_shear in ["NA", None]:
                        comb_shear_new = processed_systems_comb_shear
                    
                    else:
                        comb_shear_new = re.sub("\d+", str(new_process_id), processed_systems_comb_shear)
                    
                        # ltt_ref_s3 upload
                        copy_source = {'Bucket': 'windvista-dev', 'Key': str(processed_systems_comb_shear)}
                        s3.copy_object(CopySource = copy_source, Bucket = 'windvista-dev', Key = str(comb_shear_new))

                    if processed_systems_ltt_depth_analysis in ["NA", None]:
                        ltt_depth_analysis_new = processed_systems_ltt_depth_analysis
                    
                    else:
                        ltt_depth_analysis_new = re.sub("\d+", str(new_process_id), processed_systems_ltt_depth_analysis)

                        # ltt_ref_s3 upload
                        copy_source = {'Bucket': 'windvista-dev', 'Key': str(processed_systems_ltt_depth_analysis)}
                        s3.copy_object(CopySource = copy_source, Bucket = 'windvista-dev', Key = str(ltt_depth_analysis_new))
                    
                    if processed_systems_windoscope_download in ["NA", None]:
                        windoscope_download_new = processed_systems_windoscope_download
                    
                    else:
                        windoscope_download_new = re.sub("\d+", str(new_process_id), processed_systems_windoscope_download)

                        # ltt_ref_s3 upload
                        copy_source = {'Bucket': 'windvista-dev', 'Key': str(processed_systems_windoscope_download)}
                        s3.copy_object(CopySource = copy_source, Bucket = 'windvista-dev', Key = str(windoscope_download_new))

                    if processed_systems_shear_download in ["NA", None]:
                        shear_download_new = processed_systems_shear_download
                    
                    else:
                        shear_download_new = re.sub("\d+", str(new_process_id), processed_systems_shear_download)
                    
                        # ltt_ref_s3 upload
                        copy_source = {'Bucket': 'windvista-dev', 'Key': str(processed_systems_shear_download)}
                        s3.copy_object(CopySource = copy_source, Bucket = 'windvista-dev', Key = str(shear_download_new))

                    if processed_systems_ltt_download in ["NA", None]:
                        ltt_download_new = processed_systems_ltt_download
                    
                    else:
                        ltt_download_new = re.sub("\d+", str(new_process_id), processed_systems_ltt_download)
                    
                        # ltt_ref_s3 upload
                        copy_source = {'Bucket': 'windvista-dev', 'Key': str(processed_systems_ltt_download)}
                        s3.copy_object(CopySource = copy_source, Bucket = 'windvista-dev', Key = str(ltt_download_new))

                    if processed_systems_winddata in ["NA", None]:
                        winddata_new = processed_systems_winddata
                    
                    else:
                        winddata_new = re.sub("\d+", str(new_process_id), processed_systems_winddata)

                        # ltt_ref_s3 upload
                        copy_source = {'Bucket': 'windvista-dev', 'Key': str(processed_systems_winddata)}
                        s3.copy_object(CopySource = copy_source, Bucket = 'windvista-dev', Key = str(winddata_new))

                    if processed_systems_cbox_data in ["NA", None]:
                        cbox_new = processed_systems_cbox_data
                    
                    else:
                        cbox_new = re.sub("\d+", str(new_process_id), processed_systems_cbox_data)

                        # ltt_ref_s3 upload
                        copy_source = {'Bucket': 'windvista-dev', 'Key': str(processed_systems_cbox_data)}
                        s3.copy_object(CopySource = copy_source, Bucket = 'windvista-dev', Key = str(cbox_new))

                    try:
                        later_part = processed_systems_cbox_data.split("/")
                        later_part = later_part[-1]
                        if bool(list(s3R.Bucket('windvista-dev').objects.filter(Prefix=str(processed_systems_cbox_data).replace(later_part, "shear_ts_master_analysis.rds")))):
                            cbox_new = re.sub("\d+", str(new_process_id), processed_systems_cbox_data).replace(later_part, "shear_ts_analysis.rds")
                            copy_source = {'Bucket': 'windvista-dev', 'Key': str(processed_systems_cbox_data).replace(later_part, "shear_ts_analysis.rds")}
                            s3.copy_object(CopySource = copy_source, Bucket = 'windvista-dev', Key = str(cbox_new))
                        
                        if bool(list(s3R.Bucket('windvista-dev').objects.filter(Prefix=str(processed_systems_cbox_data).replace(later_part, "shear_ts_master_analysis.rds")))):
                            cbox_new = re.sub("\d+", str(new_process_id), processed_systems_cbox_data).replace(later_part, "shear_ts_master_analysis.rds")
                            copy_source = {'Bucket': 'windvista-dev', 'Key': str(processed_systems_cbox_data).replace(later_part, "shear_ts_master_analysis.rds")}
                            s3.copy_object(CopySource = copy_source, Bucket = 'windvista-dev', Key = str(cbox_new))
                    
                    except:
                        pass
                    
                    if shear_feather in ["NA", None]:
                        shear_feather_new = shear_feather
                    
                    else:
                        shear_feather_new = re.sub("\d+", str(new_process_id), shear_feather)

                        # ltt_ref_s3 upload
                        copy_source = {'Bucket': 'windvista-dev', 'Key': str(shear_feather)}
                        s3.copy_object(CopySource = copy_source, Bucket = 'windvista-dev', Key = str(shear_feather_new))
                    
                    if measure_feather in ["NA", None]:
                        measure_feather_new = measure_feather
                    
                    else:
                        measure_feather_new = re.sub("\d+", str(new_process_id), measure_feather)

                        # ltt_ref_s3 upload
                        copy_source = {'Bucket': 'windvista-dev', 'Key': str(measure_feather)}
                        s3.copy_object(CopySource = copy_source, Bucket = 'windvista-dev', Key = str(measure_feather_new))

                    if final_feather in ["NA", None]:
                        final_feather_new = final_feather
                    
                    else:
                        final_feather_new = re.sub("\d+", str(new_process_id), final_feather)

                        # ltt_ref_s3 upload
                        copy_source = {'Bucket': 'windvista-dev', 'Key': str(final_feather)}
                        s3.copy_object(CopySource = copy_source, Bucket = 'windvista-dev', Key = str(final_feather_new))

                    with db.connect() as conn:
                        conn.execute(text(processed_system_unreg),new_analysis_id=new_analysis_id, processed_systems_timpestamp=processed_systems_timpestamp,processed_systems_systemType=processed_systems_systemType, processed_systems_title=processed_systems_title, processed_systems_sourcefrom=processed_systems_sourcefrom, 
                        processed_systems_txtKey=txt_key_new, processed_systems_txturl=txt_key_url, processed_systems_filename=processed_systems_filename, processed_systems_process_status=processed_systems_process_status, processed_systems_user=processed_systems_user, 
                        processed_systems_comb_shear=comb_shear_new, processed_systems_Target_height=processed_systems_Target_height, processed_systems_Anemo_name=processed_systems_Anemo_name, processed_systems_ltt_process_status=processed_systems_ltt_process_status, 
                        processed_systems_ltt_imp_adj=processed_systems_ltt_imp_adj, processed_systems_ltt_depth_analysis=ltt_depth_analysis_new, processed_systems_windoscope_download=windoscope_download_new, processed_systems_shear_download=shear_download_new, processed_systems_ltt_download=ltt_download_new, 
                        processed_systems_windoscope_process=processed_systems_windoscope_process, processed_systems_winddata=winddata_new, processed_systems_tempraw_status=processed_systems_tempraw_status, processed_systems_cbox_data=cbox_new,
                        shear_feather=shear_feather_new,Direction_name=Direction_name,measure_feather=measure_feather_new,final_feather=final_feather_new)
                        conn.close()
                    
                    new_process_id = new_process_id + 1
        else:
            print("processed_systems_unreg analysis does not exists")

    return {"analysis_id": new_analysis_id}









#################################
##
## DUPLICATING PROJECT FUNCTION
##
#################################

@worker1.task(name='duplicate_project')
def duplicate_project(user, timestamp, projectid, title):
    
    with db.connect() as conn:
        result = conn.execute(text(select_row_to_duplicate), project_id=projectid).fetchone()
    if result is None:
        return {"message":"invalid project id"},200

    project_id = result[0]
    location = result[3]
    description = result[4]
    masts = result[6]
    lidars = result[7]
    inprogress = result[8]
    published = 0
    status = result[10]
    archived_timestamp = timestamp
    
    print(status)
    with db.connect() as conn:
        userID = conn.execute(text(user_id_username_query), user=user).fetchone()
    userid = userID[0]

    with db.connect() as conn:
        conn.execute(text(insert_wv_project), ts=timestamp, tl=title, loc=location, desc=description, uid=userid, mt=masts, ld=lidars, ip=inprogress, pub=published, status=status,archived_timestamp=archived_timestamp)
    try:
        with db.connect() as conn:
            pid = conn.execute(text(select_projectid_duplicate_project_query), ts=timestamp).fetchone()[0]
    except:
        {"message":"duplicated project not found"},200

    with db.connect() as conn:
        conn.execute(text(update_project_duplicate), prj_duplicate=projectid, project_id=pid)
    #duplicating each analysis from previous project to new project
    with db.connect() as conn:
        print(project_id)
        analysis_ids = conn.execute(text(select_all_analysis_ids_duplicate_project), prjid=project_id).fetchall()

    print(analysis_ids)
    for i in range(len(analysis_ids)):
        analysisid = analysis_ids[i][0]
        returned = duplicate_analysis_for_DuplicatingAProject(analysisid, timestamp, userid, pid, user)
        
        
    return {"message":"project duplicated","project_id":pid}
