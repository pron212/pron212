from datetime import timedelta
from celery import Celery
from dotenv import load_dotenv
from pymongo import MongoClient
import urllib.parse
import os
from os import environ

load_dotenv()


broker_url = f'amqp://{environ.get("RabbitmqUsername")}:{environ.get("RabbitmqPassword")}@{environ.get("RabbitmqHost")}:{environ.get("RabbitmqPort")}/{environ.get("RabbitmqVirtualhost2_worker2")}'
backend_url = f'mongodb+srv://{environ.get("MongodbUsername")}:{environ.get("MongodbPassword")}@{environ.get("MongodbHost")}/{environ.get("MongodbBackendTasks")}?retryWrites=true&w=majority'


worker2 = Celery('task2', backend=backend_url , broker=broker_url, include=['services.worker_services.worker2_services'])