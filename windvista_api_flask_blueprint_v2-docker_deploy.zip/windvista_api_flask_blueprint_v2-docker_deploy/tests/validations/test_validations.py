# from unittest import mock,main,TestCase
import pytest
import os
import json
import sys
from services.validations import *


def get_data_json(file_path):
    with open(rf"{os.path.abspath(file_path)}",'r',encoding='utf8') as m:
        data=m.read()
    return(json.loads(data))

outputs = get_data_json("tests/assertions/output_data.json")
inputs = get_data_json("tests/assertions/input_data.json")
messages = get_data_json("tests/assertions/messages.json")


@pytest.fixture(params=inputs["read_data"])
def readdata(request):
    return TestInstances(request.param)

@pytest.fixture(params=inputs["missing_columns"])
def missing(request):
    return TestInstances(request.param)

@pytest.fixture(params=inputs["dmsconvert"])
def dms(request):
    return TestInstances(request.param)

class TestInstances:      
    def __init__(self, instances=[0, 0, 0, 0]):
        self.instances = instances


def test_read_data(readdata):
    assert str(read_data(rf"{readdata.instances[0]}")) == outputs["read_data"][readdata.instances[1]]

def test_missing_columns(missing):
    assert missing_columns(missing.instances[0],missing.instances[1],missing.instances[2],missing.instances[3]=="True","test") == messages["missing_columns"][missing.instances[4]]

def test_dmsconvert(dms):
    print(dms.instances)
    assert str(dmsconvert(dms.instances[0],dms.instances[1],dms.instances[2])) == outputs["dmsconvert"][dms.instances[3]]    

# if __name__ == '__main__':
#     main()    
    
