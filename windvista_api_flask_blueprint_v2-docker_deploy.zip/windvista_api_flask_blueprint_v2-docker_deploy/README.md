# WindVista
## Maintained by Supreeth, Jai, Prasad, Vineet, Aman
### running workers in local ->   celery -A workers.worker1 worker -l info -P gevent -n worker1.%h
### running workers in local ->   celery -A workers.worker1 flower -l info -P gevent -n worker1.%h
### running unittests (library unittest) -> py -m  unittest -v  tests.validations.test_validations
### running unittests (library pytest) -> python -m pytest -v tests
### for cleaning .pyc and cache file -> pyclean . -v
