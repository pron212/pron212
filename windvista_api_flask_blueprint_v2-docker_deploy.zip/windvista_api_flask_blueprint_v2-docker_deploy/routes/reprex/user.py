#test for cookies
from flask_restful import Resource
from middleware.get_info import get_info
from middleware.islogin import requires_auth

class User(Resource):
    @requires_auth
    @get_info
    def get(self, email):
        return {"message": f"{email}"}, 200