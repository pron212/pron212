from db.connect import redis_client
from flask_restful import Resource
from middleware.get_info import get_info
from middleware.islogin import *
from routes import *
import sys
from os import environ

class Health(Resource):
    @requires_auth
    @get_info
    def get(self, email):
        try:

            info_s3_client = boto3.client('s3')
            info_s3_resource = boto3.resource('s3')
            info_db = db.connect()
            info_redis = redis_client.info()
            if None in [info_db,info_redis,info_s3_client,info_s3_resource]:
                return {"msg": "Unhealthy"}, 200
            else:
                return {"Session Status": f"{[k for k,v in sys.modules.items()]}","Redis Status": f"{redis_client.ping()}",
                "Redis Info": f"{info_redis}",
                "DB":f"{db}",
                "DB Status": f"{info_db}",
                "S3 File Location Status":f"{[a.key for a in info_s3_resource.Bucket(environ.get('AWS_S3_BUCKET')).objects.filter(Prefix=email)]}"}
        except Exception as e:
            print(e)
            return {"Session Status":"exception occured"},200
