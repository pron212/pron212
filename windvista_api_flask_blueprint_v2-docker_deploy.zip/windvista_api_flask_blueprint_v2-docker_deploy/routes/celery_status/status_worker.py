import email
from sqlite3 import Timestamp
from flask_restful import Resource
from workers.worker1 import worker1
from workers.worker2 import worker2
from flask import request
from services.systems_services import *
from celery.result import AsyncResult
from routes.system import *


class GetStatus(Resource):  
    def get(self):
        task_id = request.args.get("task_id")
        worker_index = request.args.get("worker_index")
        curr_worker = None

        if task_id is None:
            return {"message":"Task id is expected!"},200
        elif worker_index is None:
            return {"message":"Worker Index is expected!"}, 200
        
        # Selecting the Worker #
        if worker_index == "1":
            curr_worker = worker1
        if worker_index == "2":
            curr_worker = worker2
        
   
        res = AsyncResult(task_id,app=curr_worker)

        if res.status == "SUCCESS":
            return res.get()

        return {"response":"task is in process"}
