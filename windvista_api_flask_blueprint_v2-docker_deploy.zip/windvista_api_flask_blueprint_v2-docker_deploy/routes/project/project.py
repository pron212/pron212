from flask_restful import Resource, reqparse
from flask import request
from sqlalchemy import text
from db.queries import *
from db.connect import init_connection_engine    
import json
from middleware.islogin import requires_auth
from middleware.get_info import get_info
from services.project_service import new_project, \
    show_project_archive,edit_project, uarchive_project, share_project_email, all_shared_project, View_shared , user_authentication, unshare_project

from services.worker_services.worker1_services import duplicate_project
from services.worker_services.worker2_services import show_project

db = init_connection_engine()


get_parser = reqparse.RequestParser()
get_parser.add_argument('archive', type=str, required=True, help="archive required")
get_parser.add_argument('team', type=str, required=True, help="team required")
get_parser.add_argument('share', type=str, required=True, help="share required")


# for new project
post_parser = reqparse.RequestParser()
post_parser.add_argument('title', type=str, required=True, help="title required")
post_parser.add_argument('timestamp', type=str, required=True, help="timestamp required")
post_parser.add_argument('location', type=str, required=True, help="location required")
post_parser.add_argument('description', type=str, required=True, help="description required")
post_parser.add_argument('mast', type=int, required=True, help="mast required")
post_parser.add_argument('lidar', type=int, required=True, help="lidar required")
post_parser.add_argument('project_id', type=int, required=True, help="project_id required")
post_parser.add_argument('duplicate', type=str, required=True, help="duplicate required")


# unarchive parser
update_parser = reqparse.RequestParser()
update_parser.add_argument('projectID', type=str, required=True, help="projectID required")
update_parser.add_argument('timestamp', type=str, required=True, help="timestamp required")
update_parser.add_argument('title', type=str, required=True, help="title required")
update_parser.add_argument('location', type=str, required=True, help="location required")
update_parser.add_argument('description', type=str, required=True, help="description required")
update_parser.add_argument('edit', type=str, required=True, help="edit required")
update_parser.add_argument('archive', type=str, required=True, help="archive required")
update_parser.add_argument('share', type=str, required=True, help="share required")


#######################
##
## PROJECT CLASS
##
#######################


class Project(Resource):

    # show_project
    @requires_auth
    @get_info
    def get(self, email):
        
        args = get_parser.parse_args()
        
        if args['archive'].lower() == "true":
            return show_project_archive(email)
        
        if args['team'].lower() == "true":
            return share_project_email(email)
        
        if args['share'].lower() == "true":
            return View_shared(mainUser=email)
        
        return {"task_id":f"{show_project.delay(email)}"} 

    #===================================================================================================================

    # edit porject
    @requires_auth
    @get_info
    def put(self, email):

        unshare = request.args.get('unshare')
        args = update_parser.parse_args()
        obj = user_authentication(args['projectID'],email)
        flag = obj.project_id()

        #authorization
        
        if type(flag) is tuple and flag[1] == 404:
            return {"message":"please enter correct project id"}, 404
        
        if flag == False:
            return {"message":"unauthorized call"},200
        
        #________________________________________________

        if args['edit'].lower() == "true":
            return edit_project(email, args['title'], args['description'], args['location'], args['projectID'])
        
        if args['archive'].lower() == "true":
            return uarchive_project(args['projectID'], args['timestamp'])
        
        if args['share'].lower() == "true":
            data = request.args.get('sharedUser')
            return all_shared_project(sharedUser=data, project_id=args['projectID'], timestamp = args['timestamp'], email = email)
        
        if unshare.lower() == "true":
            unshareto = request.args.get('unshareto')
            return unshare_project(unshareto, email, args['projectID'])

    #===================================================================================================================    

    # new_project
    @requires_auth
    @get_info
    def post(self, email):

        args = post_parser.parse_args()
        obj = user_authentication(args['project_id'],email)
        flag = obj.duplicate_auth()
        print(flag)

        if args['duplicate'].lower() == "true":
            
            #authorization
        
            if type(flag) is tuple and flag[1] == 404:
                return {"message":"please enter correct project id"}, 404
            
            if flag == False:
                return {"message":"unauthorized call"},200
            
            #____________________________________________________

            return {"task_id":f"{duplicate_project.delay(email, args['timestamp'],args['project_id'], args['title'])}"}
        else:
            return new_project(email, args['timestamp'], args['title'], args['location'], args['description'], args['mast'], args['lidar'])
