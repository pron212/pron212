from flask_restful import Resource, reqparse
from db.queries import *
from middleware.islogin import requires_auth
from routes import *
from services.systems_services import *
from services.systems_services2 import *
from services.worker_services.worker1_services import ltt_text_file_preprocess_preload
from services.worker_services.worker2_services import final_download_file
from middleware.get_info import get_info
from services.authorization import *
import zipfile


# ltt analysis , ltt download results, ltt download results status, 
ltt_get_parser = reqparse.RequestParser()
ltt_get_parser.add_argument('process_id', type=str, required=True, help="process_id required")
ltt_get_parser.add_argument('download', type=str, required=True, help="download required")

ltt_update_parser = reqparse.RequestParser()
ltt_update_parser.add_argument('process_id', type=str, required=True, help="process_id required")
ltt_update_parser.add_argument('timestamp', type=str, required=True, help="timestamp required")

shear_get_parser = reqparse.RequestParser()
shear_get_parser.add_argument('process_id', type=str, required=True, help="process_id required")
shear_get_parser.add_argument('download', type=str, required=True, help="download required")

shear_update_parser = reqparse.RequestParser()
shear_update_parser.add_argument('process_id', type=str, required=True, help="process_id required")
shear_update_parser.add_argument('timestamp', type=str, required=True, help="timestamp required")

final_get_parser = reqparse.RequestParser()
final_get_parser.add_argument('process_id', type=str, required=True, help="process_id required")

windoscope_get_parser = reqparse.RequestParser()
windoscope_get_parser.add_argument('process_id', type=str, required=True, help="process_id required")
windoscope_get_parser.add_argument('download', type=str, required=True, help="download required")

windoscope_update_parser = reqparse.RequestParser()
windoscope_update_parser.add_argument('process_id', type=str, required=True, help="process_id required")
windoscope_update_parser.add_argument('timestamp', type=str, required=True, help="timestamp required")


#db ltt ref file status
systems_get_parser = reqparse.RequestParser()
systems_get_parser.add_argument('anlysID', type=str, required=True, help="anlysID required")
systems_get_parser.add_argument('binary', type=str, required=True, help="binary required")


#system_ws_wd_sensors
systems_post_parser = reqparse.RequestParser()
systems_post_parser.add_argument('anlysID', type=str, required=True, help="anlysID required")
systems_post_parser.add_argument('timestamp', type=str, required=True, help="timestamp required")
systems_post_parser.add_argument('systemType', type=str, required=True, help="systemType required")
systems_post_parser.add_argument('title', type=str, required=True, help="title required")
systems_post_parser.add_argument('sourcefrom', type=str, required=True, help="sourcefrom required")
systems_post_parser.add_argument('filename', type=str, required=True, help="filename required")
systems_post_parser.add_argument('Target_height', type=str, required=True, help="Target_height required")
systems_post_parser.add_argument('Anemo_name', type=str, required=True, help="Anemo_name required")
systems_post_parser.add_argument('Direction_name', type=str, required=True, help="Direction_name required")
systems_post_parser.add_argument('add', type=str, required=True, help="add required")
systems_post_parser.add_argument('binary', type=str, required=True, help="binary required")

report_post_parser = reqparse.RequestParser()
report_post_parser.add_argument('process_id', type=str, required=True, help="process_id required")
report_post_parser.add_argument('anlysID', type=str, required=True, help="anlysID required")
report_post_parser.add_argument('timestamp', type=str, required=True, help="timestamp required")
report_post_parser.add_argument('trigger', type=str, required=True, help="trigger required")

systems_update_parser = reqparse.RequestParser()
systems_update_parser.add_argument('process_id', type=str, required=True, help="process_id required")
systems_update_parser.add_argument('add', type=str, required=True, help="add required")


##############################
##
## LTT CLASS
##
##############################


class Ltt(Resource):

    # prsid_ltt
    @requires_auth
    @get_info
    def put(self, email):
    
        args = ltt_update_parser.parse_args()
        processid = args['process_id']
        obj = Authorization_systems(email, processid)
        prsid_obj = obj.prsidltt_put_get()
        
        #data authorization check
       
        if prsid_obj == 200:
            return {"message":"please enter correct process id"}

        if prsid_obj == 403:
            return {"message":"Forbidden access"}, 403

        if prsid_obj == 401:
            return {"message":"Unauthorized call"}, 401
          
        #___________________________________________________
        
        return prsid_ltt(email, args['timestamp'], args['process_id'])

    
    #==========================================================================================================================================

    # ltt_analysis
    @requires_auth
    @get_info
    def get(self, email):
    
        args = ltt_get_parser.parse_args()
        processid = args['process_id']
        obj2 = Authorization_systems(email, processid)
        prsid_obj = obj2.prsidltt_put_get()
        
        #data authorization check
       
        if prsid_obj == 200:
            return {"message":"please enter correct process id"}

        if prsid_obj == 403:
            return {"message":"Forbidden access"}, 403

        if prsid_obj == 401:
            return {"message":"Unauthorized call"}, 401
          
        #___________________________________________________

        download = None
        
        if args['download'].lower() == "true":
            download = True
        else:
            download = False
        
        if not download:
            return {"ltt analysis":ltt_analysis(args['process_id'])[0], "Db ltt download results":db_ltt_download_result_status(args['process_id'])[0], "Cron_status":db_ltt_download_results(args['process_id'])[0], "S3 status":ltt_report_download_s3_status(args['process_id'])[0]} 
        else:
            return ltt_download_result(args['process_id'])


##############################
##
## SHEAR CLASS
##
##############################


class Shear(Resource):

    @requires_auth
    @get_info
    def get(self, email):
    
        args = shear_get_parser.parse_args()
        processid = args['process_id']
        obj = Authorization_systems2(email, processid)
        prsid_obj = obj.shear_put_get()

        #data authorization check
       
        if prsid_obj == 200:
            return {"message":"please enter correct process id"}

        if prsid_obj == 403:
            return {"message":"Forbidden access"}, 403

        if prsid_obj == 401:
            return {"message":"Unauthorized call"}, 401

        #___________________________________________________   
        
        download = None
        if args['download'].lower() == "true":
            download = True
        else:
            download = False
            
        print(download) 
        if not download:
            return {"shear analysis":shear_analysis(args['process_id'])[0], "Db shear download results":db_shear_download_results_status(args['process_id'])[0], "Cron_status":db_shear_download_results(args['process_id'])[0], "S3 status":shear_report_download_s3_status(args['process_id'])[0]}
        else:
            return shear_download_results(args['process_id'])


    #==========================================================================================================================================


    @requires_auth
    @get_info
    def put(self, email):
    
        args = shear_update_parser.parse_args()
        trigger = request.args.get('trigger')
        processid = args['process_id']
        obj2 = Authorization_systems2(email, processid)
        prsid_obj = obj2.shear_put_get()
        
        #data authorization check
        
        if prsid_obj == 200:
            return {"message":"please enter correct process id"}

        if prsid_obj == 403:
            return {"message":"Forbidden access"}, 403

        if prsid_obj == 401:
            return {"message":"Unauthorized call"}, 401
        
        #____________________________________________________

        if trigger.lower() == "request_shear_report":
            return request_shear_report(process_id=args['process_id'], requested_user=email, requested_time=args['timestamp'])
        return RecentFile(user=email, timestamp=args['timestamp'], process_id=args['process_id'])


##############################
##
## FINAL CLASS
##
##############################


class Final(Resource):

    @requires_auth
    @get_info
    def get(self, email):

        args = final_get_parser.parse_args()
        process_id = args['process_id']
        trigger = request.args.get('trigger')
        timestamp = request.args.get('timestamp')
        processid = process_id
        obj = Authorization_systems3(email, processid)
        prsid_obj = obj.final_put_get()
        print(process_id)
        
        #data authorization check

        if prsid_obj == 200:
            return {"message":"please enter correct process id"}

        if prsid_obj == 403:
            return {"message":"Forbidden access"}, 403

        if prsid_obj == 401:
            return {"message":"Unauthorized call"}, 401

        #___________________________________________
        
        if trigger.lower() == "final_download_status":
            return final_download_status(email, process_id)

        return {"task_id":f"{final_download_file.delay(email, timestamp, process_id)}"}



    #==========================================================================================================================================


    @requires_auth
    @get_info
    def put(self, email):
    
        args = final_get_parser.parse_args()
        timestamp = request.args.get('timestamp')
        processid = args['process_id']
        obj2 = Authorization_systems3(email, processid)
        prsid_obj = obj2.final_put_get()

        #data authorization check
       
        if prsid_obj == 200:
            return {"message":"please enter correct process id"}

        if prsid_obj == 403:
            return {"message":"Forbidden access"}, 403

        if prsid_obj == 401:
            return {"message":"Unauthorized call"}, 401

        #_______________________________________________

        return Final_Approach(args['process_id'])


##############################
##
## WINDOSCOPE CLASS
##
##############################

    
class WindoScope(Resource):

    @requires_auth
    @get_info
    def get(self, email):
    
        args = windoscope_get_parser.parse_args()
        processid = args['process_id']
        obj = Authorization_systems4(email, processid)
        prsid_obj = obj.windoscope_put_get()
    
        #data authorization check
       
        if prsid_obj == 200:
            return {"message":"please enter correct process id"}

        if prsid_obj == 403:
            return {"message":"Forbidden access"}, 403

        if prsid_obj == 401:
            return {"message":"Unauthorized call"}, 401
          
        #__________________________________________

        download = None
        if args['download'].lower() == "true":
            download = True
        else:
            download = False
        
        if not download:
            return {"Db windoscope download results": db_windoscope_download_reslts(args['process_id'])[0] , "measurement_details": measurment_details(args['process_id'])[0], "Cron status":db_windoscope_results(args['process_id'])[0], "S3 status":windoscope_report_download_s3_status(args['process_id'])[0]}
        else:
            return windosocpe_download_results(args['process_id'])

    
    #===========================================================================================================================================
        

    @requires_auth
    @get_info
    def put(self, email):
    
        args = windoscope_update_parser.parse_args()
        processid = args['process_id']
        obj2 = Authorization_systems4(email, processid)
        prsid_obj = obj2.windoscope_put_get()

        #data authorization check
       
        if prsid_obj == 200:
            return {"message":"please enter correct process id"}

        if prsid_obj == 403:
            return {"message":"Forbidden access"}, 403

        if prsid_obj == 401:
            return {"message":"Unauthorized call"}, 401
          
        #_________________________________________

        return RecentWindexgraphFile(user=email, timestamp=args['timestamp'], process_id=args['process_id'])    


##############################
##
## SYSTEMS CLASS
##
##############################


class Systems(Resource):
    @requires_auth
    @get_info
    def get(self, email):
    
        args = systems_get_parser.parse_args()
        analysisid = args['anlysID']
        obj = Authorization_systems5(email, analysisid)
        anlysid_obj = obj.systems_get_post()
    
        trigger = request.args.get("trigger")
        process_id = request.args.get("process_id")

        if trigger == "download_text_file":
            return download_text_file(process_id,email)
            
        #data authorization check
            
        if anlysid_obj == 200:
            return {"message":"please enter correct analysis id"}

        if anlysid_obj == 403:
            return {"message":"Forbidden access"}, 403

        if anlysid_obj == 401:
            return {"message":"Unauthorized call"}, 401
            
        #__________________________________________

        binary = None
        if args['binary'].lower() == "true":
            binary = True
        else:
            binary = False
            
        if binary:
            return db_ltt_ref_file_status(args['anlysID'])
        else:
            return {"show_systems":show_systems(args['anlysID'], email)[0], "Analysis_report_Cron_status": show_system_cron_status(args['anlysID'])[0], "Analysis_report_S3_status":analysis_report_download_s3_status(args['anlysID'])[0], "Excel_summary_Cron_status": Excel_summary_Cron_status(args['anlysID'])[0], "Excel_summary_S3_status":Excel_summary_S3_status(args['anlysID'])[0]}
                

    #===========================================================================================================================================


    # ltt_ref_uploaded_binary
    @requires_auth
    @get_info
    def post(self, email):
    
        args = systems_post_parser.parse_args()
        analysisid = args['anlysID']
        obj2 = Authorization_systems5(email, analysisid)
        anlysid_obj = obj2.systems_get_post()
    
        #data authorization check
            
        if anlysid_obj == 200:
            return {"message":"please enter correct analysis id"}

        if anlysid_obj == 403:
            return {"message":"Forbidden access"}, 403

        if anlysid_obj == 401:
            return {"message":"Unauthorized call"}, 401
            
        #_______________________________________________

        binary = None
        add = None

        if args['binary'].lower() == "true":
            binary = True
        else:
            binary = False
        
        if args['add'].lower() == "true":
            add = True
        else:
            add = False 
        
        if binary:
            files = request.get_json()
            return ltt_ref_uploaded_binary(email, args['timestamp'], args['anlysID'], files)

        if add:
            comb_shear = request.get_data()
            shear_skip = request.args.get('shear_skip')
            return meas_sys_config_unreg(comb_shear=comb_shear,user=email, anlysID=args['anlysID'], title=args['title'], Anemo_name=args['Anemo_name'], Direction_name=args['Direction_name'], timestamp=args['timestamp'], systemType=args['systemType'], sourcefrom=args['sourcefrom'], filename=args['filename'], Target_height=args['Target_height'],shear_skip=shear_skip)
        
    
    #==========================================================================================================================================


    @requires_auth
    @get_info
    def put(self, email):

        args = systems_update_parser.parse_args()
        processid = args['process_id']
        timestamp = request.args.get('timestamp')
        obj = Authorization_systems4(email, processid)
        prsid_obj = obj.windoscope_put_get()

        #======================================= Zip File Extract =======================================#

        if args['add'].lower() == "true":
            dir_name = f"WS_WD_Sensor_{random.randint(1,100)}_{email}"
            data = request.get_data()
            name = f"{random.randint(1,100)}raw.zip"
            
            if not data:
                return {"message": "Zip file is missing"}, 200
            
            try:

                with open(name, 'wb') as filez:
                    filez.write(data)
                
                with zipfile.ZipFile(name, 'r') as zip_ref:
                    zip_ref.extractall(dir_name)

                files = []

                for file in os.listdir(dir_name):
                    if file.endswith(".txt"):
                        files.append(file)

            except:
                return {"message":"uploaded file is not a zip file"}

            if len(files) == 0:
                return {"message": "no txt file found in the zip"}

            filename = f'{dir_name}/{files[0]}'
                    
            return Systems_WS_WD_Sensors(name, dir_name, filename)
        
        else:

            #data authorization check
       
            if prsid_obj == 200:
                return {"message":"please enter correct process id"}

            if prsid_obj == 403:
                return {"message":"Forbidden access"}, 403

            if prsid_obj == 401:
                return {"message":"Unauthorized call"}, 401
            
            #_________________________________________________

            return meas_sys_config_postload(process_id=args['process_id'], user=email, timestamp=timestamp)
        

##############################
##
## REPORTS CLASS
##
##############################

        
class Reports(Resource):

    @requires_auth
    @get_info
    def get(self, email):
    
        args = report_post_parser.parse_args()
        process_id = args['process_id']
        timestamp = args['timestamp']
        anlysID = args['anlysID']
        trigger = args['trigger']
        analysisid = anlysID
        obj = Authorization_systems6(email, analysisid)
        anlysid_obj = obj.reports_get_1()

        if trigger.lower() == "request_summary_excel_report":

            #data authorization check
                
            if anlysid_obj == 200:
                return {"message":"please enter correct analysis id"}

            if anlysid_obj == 403:
                return {"message":"Forbidden access"}, 403

            if anlysid_obj == 401:
                return {"message":"Unauthorized call"}, 401
                
            #__________________________________________________________

            return summary_excel_report(email, timestamp, anlysID)

        ####

        if trigger.lower() == "request_final_report":
            processid = process_id
            obj = Authorization_systems7(email, processid)
            prsid_obj = obj.reports_get_2()

            #data authorization check
            
            if prsid_obj == 200:
                return {"message":"please enter correct process id"}

            if prsid_obj == 403:
                return {"message":"Forbidden access"}, 403

            if prsid_obj == 401:
                return {"message":"Unauthorized call"}, 401

            #________________________________________________________

            return final_report(email, timestamp, process_id)

        ####

        if trigger.lower() == "request_windoscope_report":
            processid = process_id
            obj2 = Authorization_systems7(email, processid)
            prsid_obj = obj2.reports_get_2()

            #data authorization check
            
            if prsid_obj == 200:
                return {"message":"please enter correct process id"}

            if prsid_obj == 403:
                return {"message":"Forbidden access"}, 403

            if prsid_obj == 401:
                return {"message":"Unauthorized call"}, 401

            #____________________________________________________

            return windoscopeReport(email, args['timestamp'], process_id)

        ####

        if trigger.lower() == "request_shear_report":
            processid = process_id
            obj3 = Authorization_systems7(email, processid)
            prsid_obj = obj3.reports_get_2()

            #data authorization check

            if prsid_obj == 200:
                return {"message":"please enter correct process id"}

            if prsid_obj == 403:
                return {"message":"Forbidden access"}, 403

            if prsid_obj == 401:
                return {"message":"Unauthorized call"}, 401

            #_____________________________________________________

            return request_shear_report(process_id=process_id, requested_user=email, requested_time=timestamp)    

        ####

        if trigger.lower()=="request_ltt_report":
            processid = process_id
            obj4 = Authorization_systems7(email, processid)
            prsid_obj = obj4.reports_get_2()

            #data authorization check
            
            if prsid_obj == 200:
                return {"message":"please enter correct process id"}

            if prsid_obj == 403:
                return {"message":"Forbidden access"}, 403

            if prsid_obj == 401:
                return {"message":"Unauthorized call"}, 401

            #_____________________________________________________

            return ltt_report(email, process_id, timestamp)
        
        ####

        if trigger.lower() == "request_analysis_report":
            analysisid = anlysID
            obj2 = Authorization_systems6(email, analysisid)
            anlysid_obj = obj2.reports_get_1()

            #data authorization check
                
            if anlysid_obj == 200:
                return {"message":"please enter correct analysis id"}

            if anlysid_obj == 403:
                return {"message":"Forbidden access"}, 403

            if anlysid_obj == 401:
                return {"message":"Unauthorized call"}, 401
                
            #_____________________________________________________

            return analysis_report(email, timestamp, anlysID)


##############################
##
## GENERATE FILE CLASS
##
##############################


class GenerateFile(Resource):

    @requires_auth
    @get_info
    def post(self, email):
    
        data = request.get_json()

        try:
            trigger = data["trigger"]
            process_id = data["process_id"]
            timestamp = data["timestamp"]
        
        except Exception as error:
            return {"message":f"{error} is required"},400

        if trigger.lower() == "generate_tab_file_preload":
            return generate_tab_file_preload(email, process_id, timestamp)
        
        return data,200


##############################
##
## REPREX CLASS
##
##############################


class Reprex(Resource):

    @requires_auth
    @get_info
    def get(self, email):
        
        trigger = request.args.get('trigger')

        if trigger.lower() == "ltt_ref_uploaded_binary_url":
            primary_key = request.args.get('primary_key')
            mode = request.args.get('mode')
            api_need = request.args.get('api_need')
            token = request.cookies.get("Authorization_heroku").split()[1] 

            if api_need.lower() == "lttref":
                filename = "ltt_ref_uploaded.zip"
            
            if api_need.lower() == "add":     
                filename = "raw_uploaded.zip"
            
            if api_need.lower() == "reupload":     
                filename = "raw_reuploaded.zip"
            
            if api_need.lower() == "shear/combination":     
                filename = "combination.json"        
            
            if api_need.lower() == "raw":     
                filename = "raw.txt"        
            
            return ltt_ref_uploaded_binary_url(user=email,token=token,mode=mode,api_need=api_need,filename=filename,primary_key=primary_key)
            
        # if trigger.lower() == "ltt_ref_file_postload":
        #     return ltt_ref_file_postload(email, primary_key)


###################################
##
## LTT TEXT FILE PREPROCESS CLASS
##
###################################


class ltt_file_preprocess(Resource):

    @requires_auth
    @get_info
    def post(self, email):

        primary_key = request.args.get('primary_key')
        api_need = request.args.get('api_need')
        token = request.cookies.get("Authorization_heroku").split()[1] 

        if primary_key is None:
            return {"message":"Primary key cannot be null"},200
        
        if api_need.lower() == "lttref":
            filename = "ltt_ref_uploaded.zip"
        
        if api_need.lower() == "add":     
            filename = "raw_uploaded.zip"
        
        if api_need.lower() == "reupload":     
            filename = "raw_reuploaded.zip"

        ltt_ref_zip_object_key = f"{email}/temp/{token}/{api_need}/{primary_key}/{filename}"
        
        return {"task_id":f"{ltt_text_file_preprocess_preload.delay(ltt_ref_zip_object_key, email, api_need, primary_key)}"}