from flask_restful import Resource, reqparse
from flask import request
from sqlalchemy import text
from db.queries import *
from routes import *
from db.connect import init_connection_engine
from middleware.islogin import requires_auth
from middleware.get_info import get_info
import pyshorteners
import requests



db = init_connection_engine()




class Report(Resource):

    #sample report
    #@requires_auth
    #@get_info
    def get(self):
        #email = request.args.get('email')
        #args = get_parser.parse_args()
        
        
        
        #uploaded file from here
        '''
        s3 = boto3.client('s3')
        obj = f"sample.docx"
        filename = "2021_udemy_online_report.docx"
        # for feather upload
        response = s3.generate_presigned_post( environ.get("AWS_S3_BUCKET"),obj,Fields=None,Conditions=None,ExpiresIn=3600)
        with open(filename, 'rb') as f:
                files = {'file': (filename, f)}
                http_response = requests.post(response['url'], data=response['fields'], files=files)

        '''


        #downloaded from here        
        report_download_key = "sample.docx"

        new_file_download_name = f"sample_report.docx"
        url = s3.generate_presigned_url(
            ClientMethod='get_object', 
            ExpiresIn=300,
            Params={
                'Bucket':  environ.get("AWS_S3_BUCKET"), 
                'Key': report_download_key,
                'ResponseContentDisposition': 'attachment;filename={}'.format(new_file_download_name),
                'ResponseContentType': 'application/docx',

                }
        )

        short = pyshorteners.Shortener()
        download_url = short.tinyurl.short(url)
        
        
        
        return {"url":download_url},200 
