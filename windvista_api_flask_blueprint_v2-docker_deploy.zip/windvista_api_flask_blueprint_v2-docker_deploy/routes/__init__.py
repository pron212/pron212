from db.connect import init_connection_engine
import boto3
from os import environ
import re


db = init_connection_engine()
s3 = boto3.client(
    's3', 
    aws_access_key_id=environ.get("AWS_ACCESS_KEY_ID") , 
    aws_secret_access_key=environ.get("AWS_SECRET_ACCESS_KEY"), 
    region_name="us-east-1"
    )


# Regex Patterns #
emailPattern = "([a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+)" # Email Regex Pattern #


# Email Vaidation #
def isEmailValid(email):
    match = re.fullmatch(emailPattern, email)
    if not match:
        return False
    return True


# Password Validation #
def isPasswordValid(password):

    if len(password) > 20 :
        return False
    
    return True