from flask_restful import Resource, reqparse
from flask import request, make_response
import requests
from routes import *
from os import environ
from db.connect import redis_client
from datetime import timedelta
from routes.__init__ import *


parser = reqparse.RequestParser()
parser.add_argument('username', type=str, required=True, help="username required")
parser.add_argument('password', type=str, required=True, help="password required")

class Login(Resource):
    def __init__(self):
        self.username = parser.parse_args().get('username', None)
        self.password = parser.parse_args().get('password', None).strip(' ')
        
    def post(self):

        # If E-Mail is not valid #
        if not isEmailValid(self.username):
            return {
                "description" : "Invalid E-Mail"
            }, 200
        
        # If Password is not valid #
        if not isPasswordValid(self.password):
            return {
                "description" : "Password length Should be less than 20"
            }, 200

        data = {
            'client_id': environ.get("client_id"),
            'client_secret': environ.get("client_secret"),
            'username': self.username,
            'password': self.password,
            "grant_type":"password"
        }
        
        response = requests.post(environ.get("url_token"), data = data)
        

        try:
            access_token = response.json()["access_token"]

            headers = {
            'Authorization':f'Bearer {access_token}',
            'Content-Type': 'application/json'
            }

            response = requests.get("https://windcheck-admin.auth0.com/userinfo", headers=headers)
            res = response.json()
            email = res['email']
            
            redis_client.set(access_token, email)
            redis_client.expire(access_token, timedelta(seconds=21600))
            res2 = make_response({"token":access_token},200)
            res2.set_cookie('Authorization_heroku', f'Bearer {access_token}', httponly = True)
            res2.set_cookie('email', f'{email}', httponly = True)
            return res2
        except Exception as e:
            print(e)
            return {"message": "Wrong email or password"}, 200
