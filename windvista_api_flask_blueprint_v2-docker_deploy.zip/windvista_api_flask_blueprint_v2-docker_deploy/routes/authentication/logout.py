from flask_restful import Resource
from flask import request, make_response
from db.connect import redis_client

class Logout(Resource):
    def get(self):
        
        auth = request.cookies.get("Authorization_heroku")
        if not auth:
            return {"code": "authorization_cookie_missing",
                           "description":"Authorization cookie is expected"},401

        try:
            parts = auth.split()
            token = parts[1]
            redis_client.delete(token)
        except Exception as e:
            print(e)

        res = make_response({"message": "Logged out successfully"}, 200)
        res.set_cookie('Authorization_heroku', '', httponly = True)
        res.set_cookie('email', '', httponly = True)
        return res
