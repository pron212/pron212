from flask_restful import Resource
from middleware.get_info import get_info

class Home(Resource):
    @get_info
    def get(self, email):
        print(email)
        print(type(email))
        return {"message": "This is initial route of windvista flask v2 blueprint (dev)"}, 200
