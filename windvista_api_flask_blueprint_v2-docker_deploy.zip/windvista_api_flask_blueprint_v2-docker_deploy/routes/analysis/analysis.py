from flask_restful import Resource, reqparse
from db.queries import *
from middleware.islogin import requires_auth
from routes import *
from services.analysis_service import *
from services.worker_services.worker1_services import duplicate
from middleware.get_info import get_info
from services.authorization import *
from services.analysis_service import *


# show analysis
get_parser = reqparse.RequestParser()
get_parser.add_argument('project_id', type=str, required=True, help="project_id required")
get_parser.add_argument('archive', type=str, required=True, help="archive required")


# new analysis
post_parser = reqparse.RequestParser()
post_parser.add_argument('project_id', type=str, required=True, help="project_id required")
post_parser.add_argument('title', type=str, required=True, help="title required")
post_parser.add_argument('description', type=str, required=True, help="description required")
post_parser.add_argument('timestamp', type=str, required=True, help="timestamp required")
post_parser.add_argument('anlysID', type=str, required=True, help="anlysID required")
post_parser.add_argument('duplicate', type=str, required=True, help="duplicate required")
post_parser.add_argument('analysis_data', type=str, required=True, help="analysis_data required")
post_parser.add_argument('userinput', type=str, required=True, help="userinput required")


#publish analysis
update_parser = reqparse.RequestParser()
update_parser.add_argument('anlysID', type=str, required=True, help="anlysID required")
update_parser.add_argument('timestamp', type=str, required=True, help="timestamp required")
update_parser.add_argument('publish', type=str, required=True, help="publish required")


#######################################
##
## ANALYSIS CLASS
##
#######################################


class Analysis(Resource):

    # show_analysis
    @requires_auth
    @get_info
    def get(self, email):
    
        archive = None
        args = get_parser.parse_args()
        projectid = args['project_id']
        obj = Authorization_analysis(email, projectid)
        prsid_obj = obj.Analysis_get()

        #data authorization check
        
        if prsid_obj == 404:
            return {"message":"project id does not exists please enter a valid project id"}

        if prsid_obj == 403:
            return {"message":"Forbidden access"}, 403

        if prsid_obj == 401:
            {"message":"Unauthorized call"}, 401

        #________________________________________________

        if args['archive'].lower() == "true":
            archive = True
        else:
            archive = False

        if not archive:
            return show_analysis(args['project_id'], email)
        else:
            return show_analysis_archive(args['project_id'])

    
    #=========================================================================================================================================


    # new_analysis 
    @requires_auth
    @get_info
    def post(self, email):
    
        isduplicate = None
        args = post_parser.parse_args()
        analysisid = args['anlysID']
        obj = Authorization_analysis2(email, analysisid)
        anlysid_obj = obj.Analysis_post()

        if args['duplicate'].lower() == "true":
            isduplicate = True
        else:
            isduplicate = False

        if args['analysis_data'].lower() == "true":
            
            #data authorization check

            if anlysid_obj == 404:
                return {"message":"analysis id does not exists please enter correct analysis id"}

            if anlysid_obj == 403:
                return {"message":"Forbidden access"}, 403

            if anlysid_obj == 401:
                return {"message":"Unauthorized call"},401
              
            #__________________________________________________

            return analysis_new_data(args['anlysID'])
            
        if not isduplicate:

            projectid = args['project_id']
            obj2 = Authorization_analysis3(email, projectid)
            prsid_obj = obj2.Analysis_post()

            #data authorization check

            if prsid_obj == 404:
                return {"message":"please enter correct project id"}

            if prsid_obj == 403:
                return {"message":"Forbidden access"}, 403

            if prsid_obj == 401:
                return {"message":"Unauthorized call"},401

            #__________________________________________________

            return new_analysis(project_id=args['project_id'], timestamp=args['timestamp'], title=args['title'], user=email, description=args['description'])
        
        else:

            analysisid = args['anlysID']
            obj3 = Authorization_analysis2(email, analysisid)
            anlysid_obj = obj3.Analysis_post()
        
            #data authorization check

            if anlysid_obj == 200:
                return "please enter correct analysis id"

            if anlysid_obj == 403:
                return {"message":"Forbidden access"}, 403

            if anlysid_obj == 401:
                return {"message":"Unauthorized call"},401
              
            #__________________________________________________

            return {"task_id":f"{duplicate.delay(args['anlysID'], args['timestamp'], args['userinput'])}"}   
            

    #=========================================================================================================================================
            

    # publish analysis
    @requires_auth
    @get_info
    def put(self, email):
    
        ispublish = None
        archive = None
        args = update_parser.parse_args()
        analysisid = args['anlysID']
        obj = Authorization_analysis2(email, analysisid)
        anlysid_obj = obj.Analysis_post()
    
        #data authorization check

        if anlysid_obj == 404:
            return {"message":"analysis id is invalid please enter correct analysis id"}

        if anlysid_obj == 403:
            return {"message":"Forbidden access"}, 403

        if anlysid_obj == 401:
            return {"message":"Unauthorized call"},401
              
        #___________________________________________________

        if args['publish'].lower() == "true":
            ispublish = True
        else:
            ispublish = False

        if ispublish:
            return publish(args['anlysID'])
        else:
            return uarchive_analysis(args['anlysID'], args['timestamp'])