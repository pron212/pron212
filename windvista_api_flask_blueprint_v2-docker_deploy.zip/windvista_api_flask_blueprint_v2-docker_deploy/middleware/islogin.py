from flask import Flask, request, _request_ctx_stack, jsonify
from jose import jwt
from functools import wraps
from dotenv import load_dotenv
from os import environ
import json
import requests
from db.connect import redis_client
load_dotenv()


ALGORITHMS = ["RS256"]


def requires_auth(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        auth = request.cookies.get("Authorization_heroku")
        if not auth:
            return {"code": "authorization_cookies_missing",
                           "description":"Authorization cookies is expected"},401

        parts = auth.split()

        if parts[0].lower() != "bearer":
            return {"code": "invalid_cookies",
                            "description":"Authorization cookies must start with"" Bearer"}, 401
        elif len(parts) == 1:
            return {"code": "invalid_cookies",
                            "description": "Token not found"}, 401
        elif len(parts) > 2:
            return {"code": "invalid_cookies",
                            "description":"Authorization cookies must be"" Bearer token"}, 401

        token = parts[1]
        
        try:
            data = redis_client.get(token)
            email_redis = data.decode('utf-8')
        except:
            return {"code": "invalid_data", "description":"Authorization error"}, 401

        try:
            email_cookies = request.cookies.get("email")
        except:
            return {"code": "invalid_cookies", "description":"Authorization error"}, 401    
      

        if email_cookies!=email_redis:
            return {"message": "unauthorized login attempt"}, 401

        
        return f(*args, **kwargs)

               
    return decorated
