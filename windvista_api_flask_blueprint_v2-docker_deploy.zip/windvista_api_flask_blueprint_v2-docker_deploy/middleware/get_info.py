from db.connect import redis_client
from functools import wraps
import requests
from flask import request


def get_info(f):
    @wraps(f)
    def red(*args, **kwargs):
        email = request.cookies.get("email")
        
        return f(*args, email, **kwargs)
    return red