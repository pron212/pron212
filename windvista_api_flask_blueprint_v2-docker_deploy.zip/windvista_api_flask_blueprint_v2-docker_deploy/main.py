###################################
#
# IMPORTING MODULES/PACKAGES
#
##################################


from flask import Flask
from flask_cors import CORS
from dotenv import load_dotenv
from flask_restful import Api


##################################
#
# INITIALIZING THE APP/FLASK
#
##################################


load_dotenv()

app = Flask(__name__)

api = Api(app)

app.config['JSON_SORT_KEYS'] = False


# cross origin
CORS(app, supports_credentials=True, resources={r"/*": {"origins": ["*", "http://localhost:3000", "http://localhost:5000"]}})
app.config['CORS_HEADERS'] = 'Content-Type'


#####################################
#
# IMPORTING USER-DEFINED FUNCTIONS
#
#####################################


from routes.home import Home
from routes.authentication.login import Login
from routes.authentication.logout import Logout
from routes.analysis.analysis import Analysis
from routes.project.project import Project
from routes.system.systems import Ltt
from routes.system.systems import Shear
from routes.system.systems import Final
from routes.system.systems import WindoScope
from routes.system.systems import Reports
from routes.system.systems import GenerateFile
from routes.system.systems import Systems
from routes.system.systems import Reprex
from routes.system.systems import ltt_file_preprocess
#celery
from routes.celery_status.status_worker import GetStatus
#Reprex Preprocessing 
from reprex.get_data import *
#test for cookies
from routes.reprex.user import User
from routes.reprex.health import Health
#sample report api's
from routes.report.sample import Report


####################################
#
# CALLING THE ENDPOINTS
#
####################################


api.add_resource(Home, "/")

#auth api's
api.add_resource(Login, "/login")
api.add_resource(Logout, "/logout")

#project api's
api.add_resource(Project, "/project")

#analysis api's
api.add_resource(Analysis, "/analysis")

#systems's api's
api.add_resource(Ltt, "/systems/ltt")
api.add_resource(Shear, "/systems/shear")
api.add_resource(Final, "/systems/final")
api.add_resource(WindoScope, "/systems/windoscope")
api.add_resource(Reports, "/systems/reports")
api.add_resource(GenerateFile, "/systems/generatefile")
api.add_resource(Systems, "/systems")
api.add_resource(ltt_file_preprocess, "/systems/preprocess")

#celery get task details by task id api's
api.add_resource(GetStatus, "/celery")

#Reprex Data Preprocessing Api's
api.add_resource(Data_Preprocessing, "/reprex/preprocess")

#test for cookies api's
api.add_resource(User, "/user")
api.add_resource(Health, "/health")

#sample report api's
api.add_resource(Report, "/report")
api.add_resource(Reprex, "/reprex")


#######################################
#
# RUNNING THE SERVER
#
#######################################


if __name__ == "__main__":
    app.run(port = 5000)
