from flask_restful import Resource
from middleware.islogin import requires_auth
from middleware.get_info import get_info
from services.authorization import *
from reprex.process_data import *
from werkzeug.utils import secure_filename


###################################
##
## TEXT FILE PREPROCESS CLASS
##
###################################


class Data_Preprocessing(Resource):

    @requires_auth
    @get_info
    def post(self, email):
        
        data = request.files['file']
        data.save(secure_filename(data.filename))

        return txt_file_preprocessing(email, data.filename)