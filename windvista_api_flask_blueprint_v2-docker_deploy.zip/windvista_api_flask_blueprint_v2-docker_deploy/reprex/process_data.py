from flask import request
from janitor import clean_names
import pandas as pd
import csv
import re

#####################################
##
## DATA PREPROCESSING
##
#####################################


def txt_file_preprocessing(user, data):

    print(user)

    file_path = data

    with open(file_path, "r") as file:
        tsv_file = csv.reader(file, delimiter="\t")
        y = 0
        for line in tsv_file:
            y += 1
            if 'Date/Time' in line:
                break
    
    meta_data = pd.read_csv(file_path, sep="\t", skiprows=y - 1, encoding='ISO-8859-1')
    input_data = meta_data.clean_names().remove_empty()
    print("\nOverall Data : \n\n", input_data)

    df = pd.DataFrame(input_data)

    df.replace({9999:'NaN'}, inplace=True)
    print("\n9999 Conversion To NaN : \n\n", df)

    print("\n\n Columns Name : \n\n")
    for col in df.columns:
        print(col)

    String = df.columns.values

    sn = [re.sub("(?<=\d)_(a|b|c|d|e|n|s|ne|nw|se|sw|e|w|nne|nnw|sse|ssw|ene|ese|wsw|wnw)_(?=mean)","_",x) for x in String]
    Tbl_names = dict((i, sn.count(i)) for i in sn)
    print("\n\n Reprex Columns : \n\n", Tbl_names)

    newdict = dict()

    for (key, value) in Tbl_names.items():

        if value == 3:
            newdict[key] = value
            return {"message":"Average Column Exists No Need To Find Mean!!"}

    print("\nAverage Column : \n", newdict)

    return{"ok":"data preprocessing done"}, 200
