const BASE_URL = process.env.REACT_APP_BACKEND ? process.env.REACT_APP_BACKEND : "http://localhost:8080/app";

export default BASE_URL;