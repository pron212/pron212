class DocumentDTO {
    constructor(documentName, documentValue, isVerified) {
        this.documentName = documentName;
        this.documentValue = documentValue;
        this.isVerified = isVerified;
    }
}

export default DocumentDTO;