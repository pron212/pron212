class DocumentStatus {
    constructor(docId, isVerified) {
        this.docId = docId;
        this.isVerified = isVerified;
    }
}

export default DocumentStatus;