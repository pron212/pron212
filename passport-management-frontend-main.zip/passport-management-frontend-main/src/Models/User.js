class User {
    constructor(email, password, userRole){
        this.email = email;
        this.password = password;
        this.userRole = userRole;
    }
}

export default User;