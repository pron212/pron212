import Applicant from "./Applicant";

export default Applicant;