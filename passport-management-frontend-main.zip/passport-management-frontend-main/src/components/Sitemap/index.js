import Sitemap from "./Sitemap";

export default Sitemap;