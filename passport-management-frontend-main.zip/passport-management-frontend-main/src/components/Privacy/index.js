import Privacy from "./Privacy";

export default Privacy;