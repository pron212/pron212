import Faqs from "./Faqs";

export default Faqs;