import PassportApplication from "./PassportApplication";

export default PassportApplication;