import Passport from "./Passport";

export default Passport;