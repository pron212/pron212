import BossCard from "./BossCard";

export default BossCard;