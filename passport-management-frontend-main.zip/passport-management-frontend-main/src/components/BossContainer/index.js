import BossContainer from "./BossContainer";

export default BossContainer;